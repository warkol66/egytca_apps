-- phpMyAdmin SQL Dump
-- version 3.4.11.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 22, 2012 at 08:06 AM
-- Server version: 5.0.96
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `viasisbz_vialidad`
--

-- --------------------------------------------------------

--
-- Table structure for table `actionLogs_label`
--

CREATE TABLE IF NOT EXISTS `actionLogs_label` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id Label',
  `action` varchar(100) NOT NULL COMMENT 'action en que se loguea el dato',
  `label` varchar(100) NOT NULL COMMENT 'mensaje del log',
  `language` varchar(100) default NULL COMMENT 'idioma de la etiqueta',
  `forward` varchar(100) default NULL COMMENT 'tipo de accion de la etiqueta',
  PRIMARY KEY  (`id`,`action`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Etiquetas de los logs' AUTO_INCREMENT=178 ;

--
-- Dumping data for table `actionLogs_label`
--

INSERT INTO `actionLogs_label` (`id`, `action`, `label`, `language`, `forward`) VALUES
(21, 'CommonDoLogin', 'Usuario inició sesión satisfactoriamente', 'esp', 'successUser'),
(22, 'CommonDoLogin', 'Primer ingreso del usuario', 'esp', 'successUserFirstLogin'),
(23, 'CommonDoLogin', 'Error', 'esp', 'failure'),
(24, 'CommonDoLogin', 'No se pudo ingresar, faltaron datos', 'esp', 'failureMissingData'),
(25, 'CommonDoLogin', 'Usuario inició sesión satisfactoriamente', 'esp', 'successAffiliateUsers'),
(26, 'CommonDoLogin', 'Error en ingreso del usuario', 'esp', 'failureRedirectUserLogin'),
(27, 'CommonPasswordRecoverySendConfirmationRequest', 'Se envió confirmación para recuperar contraseña', 'esp', 'success'),
(28, 'CommonPasswordRecoverySendConfirmationRequest', 'No se pudo enviar  confirmación para recuperar contraseña', 'esp', 'failure'),
(29, 'CommonDoLogout', 'usuario terminó la sesión', 'esp', 'success'),
(30, 'CommonActionLogsDoPurge', 'Se eliminaron registros históricos', 'esp', 'success'),
(31, 'AffiliatesUsersDoLogin', 'Usuario ingresó al sistema', 'esp', 'success'),
(32, 'AffiliatesUsersDoLogin', 'El Usuario no pudo ingresar al sistema', 'esp', 'failure-unified'),
(33, 'AffiliatesUsersDoLogin', 'El Usuario no pudo ingresar al sistema', 'esp', 'failure'),
(34, 'AffiliatesUsersDoLogin', 'Usuario ingresó al sistema por primera vez', 'esp', 'successFirstLogin'),
(35, 'AffiliatesUsersDoLogout', 'Usuario salió del sistema', 'esp', 'success-unified'),
(36, 'AffiliatesUsersDoLogout', 'Usuario salió del sistema', 'esp', 'success'),
(37, 'AffiliatesUsersPasswordDoChange', 'Usuario cambió la contraseña', 'esp', 'success'),
(38, 'AffiliatesUsersPasswordDoChange', 'Usuario cambió la contraseña', 'esp', 'changePassword'),
(39, 'AffiliatesUsersPasswordDoChange', 'No se pudo cambiar la contraseña del usuario', 'esp', 'failure'),
(40, 'AffiliatesUsersPasswordRecoveryDoRequest', 'Usuario solicitó recuperación de la contraseña', 'esp', 'success'),
(41, 'AffiliatesUsersPasswordRecoveryDoRequest', 'No se pudo procesar la recuperación de la contraseña', 'esp', 'failure'),
(50, 'BackupCreate', 'Respaldo creado en el servidor con éxito', 'esp', 'success'),
(51, 'BackupCreate', 'Error al crear respaldo en el servidor', 'esp', 'failure'),
(52, 'BackupRestore', 'Respaldo restaurado desde el servidor con éxito', 'esp', 'success'),
(53, 'BackupRestore', 'Error restaurando respaldo desde el servidor', 'esp', 'failure'),
(54, 'BackupDoDelete', 'Elimando archivo de respaldo', 'esp', 'success'),
(55, 'BackupDoDelete', 'No se pudo eliminar archivo de respaldo', 'esp', 'failure'),
(56, 'BackupSendByEmail', 'Archivo de respaldo enviado por correo electrónico', 'esp', 'success'),
(57, 'BackupSendByEmail', 'No se pudo enviar el archivo de respaldo', 'esp', 'failure'),
(60, 'SecurityDoEditPermissions', 'Se modificaron los permisos', 'esp', 'success'),
(61, 'SecurityDoEditPermissions', 'No se pudo guardar el cambio de permisos', 'esp', 'failure'),
(155, 'UsersDoLogin', 'Inicio sesión de usuario exitoso', 'esp', 'success'),
(156, 'UsersDoLogin', 'Inicio sesión de usuario erroneo', 'esp', 'failure'),
(157, 'UsersDoLogin', 'Inicio de sesión por primera vez', 'esp', 'successFirstLogin'),
(158, 'UsersPasswordRecoveryDoRequest', 'Solicitud de recuperación de contraseña exitosa', 'esp', 'success'),
(159, 'UsersPasswordRecoveryDoRequest', 'No se pudo procesar la solicitud', 'esp', 'failure'),
(160, 'UsersDoLogout', 'Fin de sesión exitoso', 'esp', 'success'),
(161, 'UsersPasswordDoChange', 'Cambio de contraseña exitoso', 'esp', 'success'),
(162, 'UsersPasswordDoChange', 'Cambio de contraseña exitoso', 'esp', 'changePassword'),
(163, 'UsersPasswordDoChange', 'No se pudo modificar la contraseña', 'esp', 'failure'),
(164, 'UsersDoDelete', 'Eliminación de usuario exitosa', 'esp', 'success'),
(165, 'UsersDoDelete', 'Eliminación de usuario fallida', 'esp', 'failure'),
(166, 'UsersDoActivate', 'Activación de usuario exitosa', 'esp', 'success'),
(167, 'UsersDoActivate', 'Activación de usuario fallida', 'esp', 'failure'),
(168, 'UsersGroupsDoEdit', 'Edición de grupo de usuarios exitosa', 'esp', 'success'),
(169, 'UsersGroupsDoEdit', 'Nombre de grupo de usuarios en blanco', 'esp', 'blankName'),
(170, 'UsersGroupsDoAddCategoryToGroup', 'Agregado de categoría a grupo exitoso', 'esp', 'success'),
(171, 'UsersGroupsDoRemoveCatFromGroup', 'Eliminación de categoría a grupo exitoso', 'esp', 'success'),
(172, 'UsersGroupsDoDelete', 'Grupo de usuarios eliminado exitosamente', 'esp', 'success'),
(173, 'UsersGroupsDoDelete', 'Eliminación de grupo de usuarios fallida', 'esp', 'failure'),
(174, 'UsersLevelsDoEdit', 'Edición de nivel de usuarios exitosa', 'esp', 'success'),
(175, 'UsersLevelsDoEdit', 'Nombre de nivel de usuario en blanco', 'esp', 'blankName'),
(176, 'UsersLevelsDoDelete', 'Eliminación de nivel de usuario exitosa', 'esp', 'success'),
(177, 'UsersLevelsDoDelete', 'Eliminación de nivel de usuario fallida', 'esp', 'failure');

-- --------------------------------------------------------

--
-- Table structure for table `actionLogs_log`
--

CREATE TABLE IF NOT EXISTS `actionLogs_log` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id log',
  `userObjectType` varchar(50) NOT NULL COMMENT 'Tipo de usuario',
  `userObjectId` int(11) NOT NULL COMMENT 'Id del usuario',
  `datetime` datetime NOT NULL COMMENT 'Fecha en que se logueo el dato',
  `action` varchar(100) NOT NULL COMMENT 'action en que se logueo el dato',
  `message` varchar(255) default NULL COMMENT 'Mensaje resultado de la accion',
  `forward` varchar(100) default NULL COMMENT 'tipo de accion de la etiqueta',
  PRIMARY KEY  (`id`),
  KEY `actionLogs_log_FI_1` (`action`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='logs de acciones del sistema' AUTO_INCREMENT=384 ;

--
-- Dumping data for table `actionLogs_log`
--

INSERT INTO `actionLogs_log` (`id`, `userObjectType`, `userObjectId`, `datetime`, `action`, `message`, `forward`) VALUES
(1, 'user', 2, '2011-10-03 11:40:17', 'UsersDoLogout', 'username: admin', 'success'),
(2, 'user', 1, '2011-10-04 16:12:54', 'CommonDoLogin', 'username: supervisor', 'success'),
(3, 'user', 1, '2011-10-10 13:59:05', 'CommonDoLogin', 'username: supervisor', 'success'),
(4, 'user', 1, '2011-10-12 16:02:13', 'CommonDoLogin', 'username: supervisor', 'success'),
(5, 'user', 1, '2011-10-13 13:27:09', 'CommonDoLogin', 'username: supervisor', 'success'),
(6, 'user', 1, '2011-10-18 17:06:47', 'CommonDoLogin', 'username: supervisor', 'success'),
(7, 'user', 1, '2011-10-18 17:16:13', 'CommonDoLogout', 'username: supervisor', 'success'),
(8, 'user', 1, '2011-10-18 18:34:20', 'CommonDoLogin', 'username: supervisor', 'success'),
(9, 'user', 1, '2011-10-18 19:46:50', 'CommonDoLogin', 'username: supervisor', 'success'),
(10, 'user', 1, '2011-10-20 14:27:37', 'CommonDoLogin', 'username: supervisor', 'success'),
(11, 'user', 1, '2011-10-24 21:11:38', 'CommonDoLogout', 'username: supervisor', 'success'),
(12, 'user', 1, '2011-10-24 21:11:42', 'CommonDoLogin', 'username: supervisor', 'success'),
(13, 'user', 1, '2011-10-26 13:56:38', 'CommonDoLogin', 'username: supervisor', 'success'),
(14, 'user', 1, '2011-10-26 15:53:59', 'CommonDoLogin', 'username: supervisor', 'success'),
(15, 'user', 1, '2011-10-31 18:38:03', 'CommonDoLogin', 'username: supervisor', 'success'),
(16, 'user', 1, '2011-11-02 13:18:46', 'CommonDoLogin', 'username: supervisor', 'success'),
(17, 'user', 1, '2011-11-02 13:59:04', 'VialidadContractsDoEdit', 'Contrato 1, acción: crear', 'success'),
(18, 'user', 1, '2011-11-02 14:30:38', 'VialidadConstructionsDoEdit', 'Obra 1, acción: crear', 'success'),
(19, 'user', 1, '2011-11-02 18:59:55', 'CommonDoLogin', 'username: supervisor', 'success'),
(20, 'user', 1, '2011-11-07 12:20:47', 'CommonDoLogin', 'username: supervisor', 'success'),
(21, 'user', 1, '2011-11-08 16:30:35', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(22, 'user', 1, '2011-11-10 10:34:28', 'CommonDoLogin', 'username: supervisor', 'success'),
(23, 'user', 1, '2011-11-10 11:26:02', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(24, 'user', 1, '2011-11-10 11:26:19', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(25, 'user', 1, '2011-11-10 11:28:01', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(26, '', 0, '2011-11-10 11:51:41', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(27, 'user', 1, '2011-11-10 12:04:55', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(28, 'user', 1, '2011-11-10 12:05:35', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(29, 'user', 1, '2011-11-10 12:07:29', 'VialidadSuppliersDoEdit', 'Los areneros, acción: crear', 'success'),
(30, '', 0, '2011-11-10 12:12:51', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(31, '', 0, '2011-11-10 12:14:17', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(32, '', 0, '2011-11-10 12:14:43', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(33, 'user', 1, '2011-11-10 12:17:47', 'CommonDoLogin', 'username: supervisor', 'success'),
(34, 'user', 1, '2011-11-10 13:40:53', 'CommonDoLogin', 'username: supervisor', 'success'),
(35, 'user', 1, '2011-11-10 15:59:46', 'UsersDoEdit', 'gmorell, acción: crear', 'success-add'),
(36, 'user', 3, '2011-11-11 11:33:00', 'CommonDoLogin', 'username: gmorell', 'success'),
(37, 'user', 1, '2011-11-14 09:30:29', 'CommonDoLogin', 'username: supervisor', 'success'),
(38, 'user', 1, '2011-11-15 15:09:56', 'CommonDoLogin', 'username: supervisor', 'success'),
(39, 'user', 3, '2011-11-18 12:03:23', 'CommonDoLogin', 'username: gmorell', 'success'),
(40, 'user', 1, '2011-11-18 13:11:57', 'CommonDoLogin', 'username: supervisor', 'success'),
(41, 'user', 1, '2011-11-21 13:16:17', 'CommonDoLogin', 'username: supervisor', 'success'),
(42, 'user', 1, '2011-11-24 13:27:59', 'CommonDoLogin', 'username: supervisor', 'success'),
(43, 'user', 1, '2011-11-24 17:02:51', 'CommonDoLogin', 'username: supervisor', 'success'),
(44, 'user', 1, '2011-11-24 17:50:37', 'CommonDoLogin', 'username: supervisor', 'success'),
(45, 'user', 2, '2011-11-24 17:54:32', 'CommonDoLogin', 'username: admin', 'success'),
(46, 'user', 2, '2011-11-24 18:06:20', 'CommonDoLogout', 'username: admin', 'success'),
(47, 'user', 1, '2011-11-25 14:16:46', 'CommonDoLogin', 'username: supervisor', 'success'),
(48, 'user', 1, '2011-11-25 14:17:28', 'CommonDoLogin', 'username: supervisor', 'success'),
(49, 'user', 2, '2011-11-29 13:12:19', 'UsersDoLogin', 'username: admin', 'success'),
(50, 'user', 2, '2011-11-29 13:12:57', 'UsersDoLogin', 'username: admin', 'success'),
(51, 'user', 2, '2011-11-29 13:14:33', 'UsersDoLogin', 'username: admin', 'success'),
(52, 'user', 1, '2011-11-29 13:15:18', 'CommonDoLogin', 'username: supervisor', 'success'),
(53, 'user', 1, '2011-11-29 15:59:56', 'CommonDoLogin', 'username: supervisor', 'success'),
(54, 'user', 1, '2011-11-29 16:08:50', 'CommonDoLogout', 'username: supervisor', 'success'),
(55, 'user', 1, '2011-11-29 16:08:58', 'CommonDoLogin', 'username: supervisor', 'success'),
(56, 'user', 2, '2011-11-29 17:16:49', 'UsersDoLogin', 'username: admin', 'success'),
(57, 'user', 2, '2011-11-29 17:17:38', 'CommonDoLogout', 'username: admin', 'success'),
(58, 'user', 2, '2011-11-29 17:17:59', 'CommonDoLogout', 'username: admin', 'success'),
(59, 'user', 2, '2011-11-29 17:26:40', 'UsersDoLogin', 'username: admin', 'success'),
(60, 'user', 2, '2011-11-29 17:27:35', 'CommonDoLogout', 'username: admin', 'success'),
(61, 'user', 2, '2011-12-01 14:41:49', 'UsersDoLogin', 'username: admin', 'success'),
(62, 'user', 2, '2011-12-01 16:09:30', 'UsersDoLogin', 'username: admin', 'success'),
(63, 'user', 2, '2011-12-01 16:11:28', 'CommonDoLogout', 'username: admin', 'success'),
(64, 'user', 2, '2011-12-01 16:13:15', 'UsersDoLogin', 'username: admin', 'success'),
(65, 'user', 2, '2011-12-01 16:26:54', 'CommonDoLogout', 'username: admin', 'success'),
(66, 'user', 2, '2011-12-01 16:39:44', 'CommonDoLogout', 'username: admin', 'success'),
(67, 'user', 1, '2011-12-06 17:45:43', 'VialidadCertificatesDoEdit', ', acción: crear', 'success'),
(68, 'user', 1, '2011-12-06 17:46:25', 'VialidadCertificatesDoEdit', ', acción: crear', 'success'),
(69, 'user', 1, '2011-12-06 17:46:42', 'VialidadCertificatesDoEdit', ', acción: crear', 'success'),
(70, 'user', 1, '2011-12-06 18:14:55', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(71, 'user', 1, '2011-12-07 12:58:03', 'CommonDoLogin', 'username: supervisor', 'success'),
(72, 'user', 1, '2011-12-07 13:37:29', 'CommonDoLogin', 'username: supervisor', 'success'),
(73, 'user', 1, '2011-12-07 14:38:01', 'CommonDoLogin', 'username: supervisor', 'success'),
(74, 'user', 1, '2011-12-07 14:43:41', 'UsersDoEdit', 'dgroisman, acción: crear', 'success-add'),
(75, 'user', 1, '2011-12-13 13:08:19', 'CommonDoLogin', 'username: supervisor', 'success'),
(76, 'user', 1, '2011-12-14 15:27:56', 'SecurityDoEditPermissions', 'vialidad, action: edit permissions', 'success'),
(77, 'user', 1, '2011-12-14 15:37:47', 'SecurityDoEditPermissions', 'vialidad, action: edit permissions', 'success'),
(78, 'user', 1, '2011-12-14 15:43:15', 'SecurityDoEditPermissions', 'vialidad, action: edit permissions', 'success'),
(79, 'user', 1, '2011-12-23 15:43:04', 'CommonDoLogin', 'username: supervisor', 'success'),
(80, 'user', 1, '2011-12-23 16:25:34', 'CommonDoLogout', 'username: supervisor', 'success'),
(81, 'affiliate', 4, '2011-12-23 16:25:42', 'CommonDoLogin', 'affiliateUsername: daniel', 'success'),
(82, 'affiliate', 4, '2011-12-23 16:27:45', 'CommonDoLogout', 'username: daniel', 'success'),
(83, 'user', 1, '2011-12-23 16:27:53', 'CommonDoLogin', 'username: supervisor', 'success'),
(84, 'user', 1, '2011-12-26 16:12:15', 'VialidadConstructionsDoEdit', 'Obra 1 para el contrato 1, acción: crear', 'success'),
(85, 'user', 1, '2011-12-26 19:19:04', 'VialidadSuppliersDoEdit', ', acción: crear', 'success'),
(86, 'user', 1, '2011-12-27 14:38:10', 'CommonDoLogin', 'username: supervisor', 'success'),
(87, 'user', 1, '2011-12-27 14:48:38', 'VialidadSuppliersDoEdit', 'Aceros la estrella, acción: crear', 'success'),
(88, 'user', 1, '2011-12-27 14:52:49', 'VialidadSuppliersDoEdit', 'Acerotecnia, acción: crear', 'success'),
(89, 'user', 1, '2011-12-28 13:48:22', 'CommonDoLogin', 'username: supervisor', 'success'),
(90, 'user', 1, '2011-12-28 18:19:22', 'CommonDoLogin', 'username: supervisor', 'success'),
(91, 'user', 1, '2011-12-28 18:56:57', 'VialidadSuppliersDoEdit', 'Puentes colgantes SA, acción: crear', 'success'),
(92, 'user', 1, '2011-12-28 21:49:04', 'SecurityDoEditPermissions', 'users, action: edit permissions', 'success'),
(93, 'user', 1, '2011-12-29 16:56:50', 'CommonDoLogin', 'username: supervisor', 'success'),
(94, 'user', 1, '2011-12-29 17:17:16', 'VialidadSuppliersDoEdit', ', acción: crear', 'success'),
(95, 'user', 1, '2012-01-04 16:12:12', 'CommonDoLogin', 'username: supervisor', 'success'),
(96, 'user', 1, '2012-01-04 16:34:59', 'CommonDoLogin', 'username: supervisor', 'success'),
(97, 'user', 1, '2012-01-04 17:53:07', 'VialidadContractsDoEdit', 'Contrato 2, acción: crear', 'success'),
(98, 'user', 1, '2012-01-04 17:53:45', 'VialidadConstructionsDoEdit', 'Costanera, acción: crear', 'success'),
(99, 'user', 1, '2012-01-05 12:54:28', 'CommonDoLogin', 'username: supervisor', 'success'),
(100, 'user', 1, '2012-01-05 18:14:07', 'CommonDoLogin', 'username: supervisor', 'success'),
(101, 'user', 1, '2012-01-06 13:21:10', 'CommonDoLogin', 'username: supervisor', 'success'),
(102, 'user', 1, '2012-01-06 13:58:22', 'CommonDoLogin', 'username: supervisor', 'success'),
(103, 'user', 1, '2012-01-09 15:55:54', 'CommonDoLogout', 'username: supervisor', 'success'),
(104, 'user', 1, '2012-01-09 16:58:54', 'CommonDoLogin', 'username: supervisor', 'success'),
(105, 'user', 1, '2012-01-11 13:36:39', 'CommonDoLogin', 'username: supervisor', 'success'),
(106, 'user', 1, '2012-01-12 13:05:59', 'CommonDoLogin', 'username: supervisor', 'success'),
(107, 'user', 1, '2012-01-13 13:15:47', 'CommonDoLogin', 'username: supervisor', 'success'),
(108, 'user', 1, '2012-01-13 18:36:31', 'CommonDoLogin', 'username: supervisor', 'success'),
(109, 'user', 1, '2012-01-25 13:16:15', 'CommonDoLogin', 'username: supervisor', 'success'),
(110, 'user', 1, '2012-01-25 13:18:28', 'VialidadCertificatesDoEdit', ', acción: crear', 'success'),
(111, 'user', 1, '2012-01-25 13:22:27', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(112, 'user', 1, '2012-02-24 11:53:57', 'CommonDoLogin', 'username: supervisor', 'success'),
(113, 'user', 1, '2012-02-29 14:45:31', 'CommonDoLogin', 'username: supervisor', 'success'),
(114, 'user', 1, '2012-02-29 14:52:35', 'VialidadFineDoEditX', 's, acción: crear', 'success'),
(115, 'user', 1, '2012-03-13 17:01:47', 'CommonDoLogin', 'username: supervisor', 'success'),
(116, 'user', 1, '2012-03-13 17:04:32', 'CommonDoLogin', 'username: supervisor', 'success'),
(117, 'user', 1, '2012-03-13 17:05:10', 'CommonDoLogout', 'username: supervisor', 'success'),
(118, 'user', 1, '2012-03-13 17:05:25', 'CommonDoLogin', 'username: supervisor', 'success'),
(119, 'user', 1, '2012-03-13 17:08:28', 'CommonDoLogout', 'username: supervisor', 'success'),
(120, 'user', 1, '2012-03-13 17:15:25', 'CommonDoLogin', 'username: supervisor', 'success'),
(121, 'user', 1, '2012-03-14 17:45:27', 'CommonDoLogin', 'username: supervisor', 'success'),
(122, 'user', 1, '2012-03-19 10:43:33', 'CommonDoLogin', 'username: supervisor', 'success'),
(123, 'user', 1, '2012-03-19 10:43:42', 'CommonDoLogin', 'username: supervisor', 'success'),
(124, 'user', 1, '2012-03-19 10:51:58', 'CommonDoLogout', 'username: supervisor', 'success'),
(125, 'user', 1, '2012-03-21 20:15:41', 'CommonDoLogin', 'username: supervisor', 'success'),
(126, 'user', 1, '2012-03-22 13:45:30', 'CommonDoLogin', 'username: supervisor', 'success'),
(127, 'user', 1, '2012-03-22 13:56:27', 'VialidadConstructionsDoEdit', 'Ruta Nº12, tramo Ninfa - General Bruguez, acción: crear', 'success'),
(128, 'user', 1, '2012-03-22 14:40:40', 'VialidadConstructionsDoEdit', 'Camino de acceso al puerto Trociuk, acción: crear', 'success'),
(129, 'user', 1, '2012-03-23 12:58:34', 'CommonDoLogin', 'username: supervisor', 'success'),
(130, 'user', 1, '2012-03-23 13:39:06', 'CommonDoLogin', 'username: supervisor', 'success'),
(131, 'user', 1, '2012-03-23 13:39:35', 'VialidadConstructionsDoEdit', 'Mejoramiento de puente rio Uruguay, acción: crear', 'success'),
(132, 'user', 1, '2012-03-23 13:41:49', 'VialidadFineDoEditX', 'Retraso entrega de planos, acción: crear', 'success'),
(133, 'user', 1, '2012-03-23 13:56:02', 'VialidadContractsDoEdit', 'Contrato Puente Uruguay BID 1822-3435, acción: crear', 'success'),
(134, 'user', 1, '2012-03-23 14:15:42', 'VialidadConstructionsDoEdit', 'Puente la noria, acción: crear', 'success'),
(135, 'user', 1, '2012-03-26 17:06:42', 'CommonDoLogin', 'username: supervisor', 'success'),
(136, 'user', 1, '2012-03-27 10:32:08', 'CommonDoLogin', 'username: supervisor', 'success'),
(137, 'user', 1, '2012-03-27 12:50:14', 'CommonDoLogin', 'username: supervisor', 'success'),
(138, 'user', 1, '2012-03-27 13:58:30', 'CommonDoLogin', 'username: supervisor', 'success'),
(139, 'user', 1, '2012-03-27 13:59:08', 'CommonDoLogout', 'username: supervisor', 'success'),
(140, 'user', 1, '2012-03-28 12:41:32', 'CommonDoLogin', 'username: supervisor', 'success'),
(141, 'user', 1, '2012-03-28 13:40:07', 'CommonDoLogin', 'username: supervisor', 'success'),
(142, 'user', 1, '2012-04-04 15:42:10', 'CommonDoLogin', 'username: supervisor', 'success'),
(143, 'user', 1, '2012-04-16 13:57:52', 'CommonDoLogin', 'username: supervisor', 'success'),
(144, 'user', 1, '2012-04-16 17:20:18', 'CommonDoLogin', 'username: supervisor', 'success'),
(145, 'user', 1, '2012-05-18 02:26:15', 'CommonDoLogin', 'username: supervisor', 'success'),
(146, 'user', 1, '2012-05-18 11:34:14', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(147, 'user', 1, '2012-05-18 11:36:09', 'VialidadCertificatesDoEdit', ', acción: crear', 'success'),
(148, 'user', 1, '2012-05-18 11:39:29', 'VialidadCertificatesDoEdit', ', acción: crear', 'success'),
(149, 'user', 1, '2012-05-18 11:41:43', 'VialidadConstructionsDoEdit', 'Obra para reunión del 18-5, acción: crear', 'success'),
(150, 'user', 1, '2012-05-18 11:46:41', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(151, 'user', 1, '2012-05-18 11:47:29', 'VialidadCertificatesDoEdit', ', acción: crear', 'success'),
(152, 'user', 1, '2012-05-18 11:54:52', 'VialidadContractsDoEdit', 'Contrato 34, acción: crear', 'success'),
(153, 'user', 1, '2012-05-18 11:57:24', 'VialidadConstructionsDoEdit', 'Obra 1 del contrato de roggio, acción: crear', 'success'),
(154, 'user', 1, '2012-05-18 11:59:41', 'VialidadDailyWorkDoEditX', 'movimiento de carteles, acción: crear', 'success'),
(155, 'user', 1, '2012-05-18 11:59:52', 'VialidadFineDoEditX', 'retraso, acción: crear', 'success'),
(156, 'user', 1, '2012-05-18 12:02:21', 'CommonDoLogin', 'username: supervisor', 'success'),
(157, 'user', 1, '2012-05-18 12:23:00', 'CommonDoLogin', 'username: supervisor', 'success'),
(158, 'user', 1, '2012-05-18 12:23:09', 'CommonDoLogin', 'username: supervisor', 'success'),
(159, 'user', 1, '2012-05-18 12:38:32', 'VialidadContractsDoEdit', 'Contrato general por obras en la costanera, acción: crear', 'success'),
(160, 'user', 1, '2012-05-18 12:40:13', 'VialidadConstructionsDoEdit', 'rambla norte, acción: crear', 'success'),
(161, 'user', 1, '2012-05-18 13:25:14', 'CommonDoLogout', 'username: supervisor', 'success'),
(162, 'user', 1, '2012-05-18 13:25:23', 'CommonDoLogin', 'username: supervisor', 'success'),
(163, 'user', 1, '2012-05-28 17:35:33', 'CommonDoLogin', 'username: supervisor', 'success'),
(164, 'user', 1, '2012-05-30 11:48:10', 'CommonDoLogin', 'username: supervisor', 'success'),
(165, 'user', 1, '2012-05-30 16:59:04', 'CommonDoLogin', 'username: supervisor', 'success'),
(166, 'user', 1, '2012-05-30 16:59:51', 'CommonDoLogout', 'username: supervisor', 'success'),
(167, 'user', 1, '2012-05-31 12:52:08', 'CommonDoLogin', 'username: supervisor', 'success'),
(168, 'user', 1, '2012-05-31 12:54:28', 'CommonDoLogin', 'username: supervisor', 'success'),
(169, 'user', 1, '2012-05-31 19:14:48', 'CommonDoLogin', 'username: supervisor', 'success'),
(170, 'user', 1, '2012-05-31 19:17:42', 'CommonDoLogout', 'username: supervisor', 'success'),
(171, 'user', 1, '2012-05-31 20:27:05', 'CommonDoLogin', 'username: supervisor', 'success'),
(172, 'user', 1, '2012-05-31 20:27:24', 'CommonDoLogout', 'username: supervisor', 'success'),
(173, 'user', 1, '2012-05-31 22:34:54', 'CommonDoLogin', 'username: supervisor', 'success'),
(174, 'user', 1, '2012-05-31 22:35:42', 'CommonDoLogout', 'username: supervisor', 'success'),
(175, 'user', 1, '2012-06-01 19:46:07', 'CommonDoLogin', 'username: supervisor', 'success'),
(176, 'user', 1, '2012-06-04 15:23:12', 'CommonDoLogin', 'username: supervisor', 'success'),
(177, 'user', 1, '2012-06-04 17:44:51', 'CommonDoLogin', 'username: supervisor', 'success'),
(178, 'user', 1, '2012-06-04 22:06:17', 'CommonDoLogin', 'username: Supervisor', 'success'),
(179, 'user', 1, '2012-06-04 22:07:42', 'CommonDoLogout', 'username: supervisor', 'success'),
(180, 'user', 1, '2012-06-04 23:03:18', 'CommonDoLogin', 'username: supervisor', 'success'),
(181, 'user', 1, '2012-06-04 23:11:22', 'VialidadContractsDoEdit', 'Restauración, Conservación y Puesta en Valor del Teatro de Villarrica, acción: crear', 'success'),
(182, 'user', 1, '2012-06-04 23:13:55', 'CommonDoLogout', 'username: supervisor', 'success'),
(183, 'user', 1, '2012-06-05 11:56:45', 'CommonDoLogin', 'username: supervisor', 'success'),
(184, 'user', 1, '2012-06-05 12:19:02', 'CommonDoLogin', 'username: supervisor', 'success'),
(185, 'user', 1, '2012-06-05 13:03:12', 'CommonDoLogin', 'username: supervisor', 'success'),
(186, 'user', 1, '2012-06-05 13:28:43', 'CommonDoLogout', 'username: supervisor', 'success'),
(187, 'user', 1, '2012-06-05 13:57:55', 'CommonDoLogin', 'username: supervisor', 'success'),
(188, 'user', 1, '2012-06-05 14:20:29', 'CommonDoLogin', 'username: supervisor', 'success'),
(189, 'user', 1, '2012-06-05 14:58:38', 'CommonDoLogin', 'username: supervisor', 'success'),
(190, 'user', 1, '2012-06-05 16:07:38', 'CommonDoLogout', 'username: supervisor', 'success'),
(191, 'user', 1, '2012-06-05 16:58:48', 'CommonDoLogin', 'username: supervisor', 'success'),
(192, 'user', 1, '2012-06-05 17:11:13', 'CommonDoLogin', 'username: supervisor', 'success'),
(193, 'user', 1, '2012-06-05 17:53:11', 'CommonDoLogout', 'username: supervisor', 'success'),
(194, 'user', 1, '2012-06-05 18:47:15', 'CommonDoLogin', 'username: supervisor', 'success'),
(195, 'user', 1, '2012-06-05 18:53:30', 'CommonDoLogout', 'username: supervisor', 'success'),
(196, 'user', 1, '2012-06-05 19:01:45', 'CommonDoLogin', 'username: supervisor', 'success'),
(197, 'user', 1, '2012-06-05 19:09:40', 'CommonDoLogout', 'username: supervisor', 'success'),
(198, 'user', 1, '2012-06-06 15:45:31', 'CommonDoLogin', 'username: supervisor', 'success'),
(199, 'user', 1, '2012-06-06 15:53:27', 'CommonDoLogout', 'username: supervisor', 'success'),
(200, 'user', 1, '2012-06-06 17:23:35', 'CommonDoLogin', 'username: supervisor', 'success'),
(201, 'user', 1, '2012-06-06 17:24:06', 'CommonDoLogin', 'username: supervisor', 'success'),
(202, 'user', 1, '2012-06-06 17:25:04', 'CommonDoLogin', 'username: supervisor', 'success'),
(203, 'user', 1, '2012-06-06 17:27:40', 'CommonDoLogout', 'username: supervisor', 'success'),
(204, 'user', 1, '2012-06-07 12:32:24', 'CommonDoLogin', 'username: supervisor', 'success'),
(205, 'user', 1, '2012-06-07 15:07:13', 'CommonDoLogout', 'username: supervisor', 'success'),
(206, 'user', 1, '2012-06-08 13:25:54', 'CommonDoLogin', 'username: supervisor', 'success'),
(207, 'user', 1, '2012-06-08 16:41:50', 'CommonDoLogout', 'username: supervisor', 'success'),
(208, 'user', 1, '2012-06-08 20:20:11', 'CommonDoLogin', 'username: supervisor', 'success'),
(209, 'user', 1, '2012-06-09 18:21:32', 'CommonDoLogin', 'username: supervisor', 'success'),
(210, 'user', 1, '2012-06-09 18:22:39', 'CommonDoLogout', 'username: supervisor', 'success'),
(211, 'user', 1, '2012-06-11 11:09:03', 'CommonDoLogin', 'username: supervisor', 'success'),
(212, 'user', 1, '2012-06-11 11:09:13', 'CommonDoLogout', 'username: supervisor', 'success'),
(213, 'user', 1, '2012-06-11 13:57:38', 'CommonDoLogin', 'username: supervisor', 'success'),
(214, 'user', 1, '2012-06-11 13:58:09', 'CommonDoLogin', 'username: supervisor', 'success'),
(215, 'user', 1, '2012-06-11 15:52:38', 'CommonDoLogout', 'username: supervisor', 'success'),
(216, 'user', 1, '2012-06-11 19:26:15', 'CommonDoLogin', 'username: supervisor', 'success'),
(217, 'user', 1, '2012-06-13 14:17:13', 'CommonDoLogin', 'username: supervisor', 'success'),
(218, 'user', 1, '2012-06-13 15:54:17', 'CommonDoLogout', 'username: supervisor', 'success'),
(219, 'user', 1, '2012-06-13 18:05:39', 'CommonDoLogin', 'username: supervisor', 'success'),
(220, 'user', 1, '2012-06-14 18:11:36', 'CommonDoLogin', 'username: supervisor', 'success'),
(221, 'user', 1, '2012-06-14 18:11:59', 'CommonDoLogout', 'username: supervisor', 'success'),
(222, 'user', 1, '2012-06-14 20:29:50', 'CommonDoLogout', 'username: supervisor', 'success'),
(223, 'user', 1, '2012-06-17 22:25:06', 'CommonDoLogin', 'username: supervisor', 'success'),
(224, 'user', 1, '2012-06-17 22:50:32', 'CommonDoLogout', 'username: supervisor', 'success'),
(225, 'user', 1, '2012-06-18 18:16:32', 'CommonDoLogin', 'username: supervisor', 'success'),
(226, 'user', 1, '2012-06-18 18:53:05', 'CommonDoLogout', 'username: supervisor', 'success'),
(227, 'user', 1, '2012-06-19 13:36:42', 'CommonDoLogin', 'username: supervisor', 'success'),
(228, 'user', 1, '2012-06-19 13:36:44', 'CommonDoLogin', 'username: supervisor', 'success'),
(229, 'user', 1, '2012-06-19 16:59:37', 'CommonDoLogin', 'username: supervisor', 'success'),
(230, 'user', 1, '2012-06-19 17:00:31', 'CommonDoLogout', 'username: supervisor', 'success'),
(231, 'user', 1, '2012-06-19 18:46:33', 'CommonDoLogin', 'username: supervisor', 'success'),
(232, 'user', 1, '2012-06-19 18:46:52', 'CommonDoLogout', 'username: supervisor', 'success'),
(233, 'user', 1, '2012-06-20 11:03:07', 'CommonDoLogin', 'username: supervisor', 'success'),
(234, 'user', 1, '2012-06-20 11:03:54', 'CommonDoLogout', 'username: supervisor', 'success'),
(235, 'user', 1, '2012-06-20 13:08:14', 'CommonDoLogin', 'username: supervisor', 'success'),
(236, 'user', 1, '2012-06-20 13:09:55', 'CommonDoLogout', 'username: supervisor', 'success'),
(237, 'user', 1, '2012-06-20 17:32:18', 'CommonDoLogin', 'username: supervisor', 'success'),
(238, 'user', 1, '2012-06-20 18:55:26', 'CommonDoLogin', 'username: supervisor', 'success'),
(239, 'user', 1, '2012-06-20 19:37:14', 'CommonDoLogout', 'username: supervisor', 'success'),
(240, 'user', 1, '2012-06-21 11:06:27', 'CommonDoLogin', 'username: supervisor', 'success'),
(241, 'user', 1, '2012-06-21 11:10:12', 'CommonDoLogout', 'username: supervisor', 'success'),
(242, 'user', 1, '2012-06-21 12:12:35', 'CommonDoLogin', 'username: supervisor', 'success'),
(243, 'user', 1, '2012-06-21 13:42:23', 'CommonDoLogout', 'username: supervisor', 'success'),
(244, 'user', 1, '2012-06-21 13:46:11', 'CommonDoLogin', 'username: supervisor', 'success'),
(245, 'user', 1, '2012-06-21 14:44:57', 'VialidadOtherDoEditX', '100 Computadoras, acción: crear', 'success'),
(246, 'user', 1, '2012-06-21 15:35:28', 'CommonDoLogin', 'username: supervisor', 'success'),
(247, 'user', 1, '2012-06-21 15:36:46', 'CommonDoLogout', 'username: supervisor', 'success'),
(248, 'user', 1, '2012-06-21 15:38:52', 'CommonDoLogin', 'username: supervisor', 'success'),
(249, 'user', 1, '2012-06-21 18:09:52', 'CommonDoLogin', 'username: supervisor', 'success'),
(250, 'user', 1, '2012-06-21 18:10:37', 'BackupCreate', 'Backup created: vialidad_20120621_151037.zip', 'success'),
(251, 'user', 1, '2012-06-21 19:59:01', 'CommonDoLogin', 'username: supervisor', 'success'),
(252, 'user', 1, '2012-06-21 20:01:12', 'CommonDoLogin', 'username: supervisor', 'success'),
(253, 'user', 1, '2012-06-22 11:03:43', 'CommonDoLogin', 'username: supervisor', 'success'),
(254, 'user', 1, '2012-06-22 11:05:08', 'CommonDoLogout', 'username: supervisor', 'success'),
(255, 'user', 1, '2012-06-22 14:44:00', 'CommonDoLogin', 'username: supervisor', 'success'),
(256, 'user', 1, '2012-06-25 15:05:27', 'CommonDoLogin', 'username: supervisor', 'success'),
(257, 'user', 1, '2012-06-25 15:06:00', 'CommonDoLogout', 'username: supervisor', 'success'),
(258, 'user', 1, '2012-06-25 18:28:08', 'CommonDoLogin', 'username: supervisor', 'success'),
(259, 'user', 1, '2012-06-25 22:12:47', 'CommonDoLogin', 'username: supervisor', 'success'),
(260, 'user', 1, '2012-06-26 13:28:41', 'CommonDoLogin', 'username: supervisor', 'success'),
(261, 'user', 1, '2012-06-26 18:24:00', 'CommonDoLogin', 'username: supervisor', 'success'),
(262, 'user', 1, '2012-06-26 18:57:37', 'CommonDoLogout', 'username: supervisor', 'success'),
(263, 'user', 1, '2012-06-27 11:56:32', 'CommonDoLogin', 'username: supervisor', 'success'),
(264, 'user', 1, '2012-06-27 17:07:01', 'CommonDoLogin', 'username: supervisor', 'success'),
(265, 'user', 1, '2012-06-27 17:12:56', 'CommonDoLogout', 'username: supervisor', 'success'),
(266, 'user', 1, '2012-06-27 17:14:02', 'CommonDoLogin', 'username: supervisor', 'success'),
(267, 'user', 1, '2012-06-27 17:37:00', 'CommonDoLogout', 'username: supervisor', 'success'),
(268, 'user', 1, '2012-06-27 17:58:51', 'CommonDoLogin', 'username: supervisor', 'success'),
(269, 'user', 1, '2012-06-27 18:58:15', 'CommonDoLogin', 'username: supervisor', 'success'),
(270, 'user', 1, '2012-06-27 19:35:11', 'VialidadConstructionsDoEdit', 'qwsqw, acción: crear', 'success'),
(271, 'user', 1, '2012-06-28 11:35:51', 'CommonDoLogin', 'username: supervisor', 'success'),
(272, 'user', 1, '2012-06-28 11:47:54', 'VialidadDepartmentsDoDelete', 'Central, acción: eliminar', 'success'),
(273, 'user', 1, '2012-06-28 11:50:33', 'CommonDoLogout', 'username: supervisor', 'success'),
(274, 'user', 1, '2012-06-29 14:19:37', 'CommonDoLogin', 'username: supervisor', 'success'),
(275, 'user', 1, '2012-07-02 13:55:25', 'CommonDoLogin', 'username: supervisor', 'success'),
(276, 'user', 1, '2012-07-02 14:00:57', 'BackupCreate', 'Backup created: vialidad_20120702_110057.zip', 'success'),
(277, 'user', 1, '2012-07-04 17:42:24', 'CommonDoLogin', 'username: supervisor', 'success'),
(278, 'user', 1, '2012-07-04 17:48:20', 'VialidadConstructionsDoEdit', 'sqw, acción: crear', 'success'),
(279, 'user', 1, '2012-07-04 18:48:17', 'CommonDoLogout', 'username: supervisor', 'success'),
(280, 'user', 1, '2012-07-05 13:16:14', 'CommonDoLogin', 'username: supervisor', 'success'),
(281, 'user', 1, '2012-07-05 13:46:56', 'CommonDoLogin', 'username: supervisor', 'success'),
(282, 'user', 1, '2012-07-05 14:25:02', 'CommonDoLogout', 'username: supervisor', 'success'),
(283, 'user', 1, '2012-07-06 11:16:18', 'CommonDoLogin', 'username: supervisor', 'success'),
(284, 'user', 1, '2012-07-06 15:02:47', 'CommonDoLogin', 'username: supervisor', 'success'),
(285, 'user', 1, '2012-07-06 15:32:09', 'CommonDoLogin', 'username: supervisor', 'success'),
(286, 'user', 1, '2012-07-06 15:49:19', 'CommonDoLogin', 'username: supervisor', 'success'),
(287, 'user', 1, '2012-07-06 16:23:17', 'CommonDoLogin', 'username: supervisor', 'success'),
(288, 'user', 1, '2012-07-06 16:41:59', 'VialidadContractsDoEdit', 'sdsad, acción: crear', 'success'),
(289, 'user', 1, '2012-07-06 16:52:13', 'CommonDoLogout', 'username: supervisor', 'success'),
(290, 'user', 1, '2012-07-06 18:25:40', 'CommonDoLogin', 'username: supervisor', 'success'),
(291, 'user', 1, '2012-07-06 18:26:02', 'CommonDoLogin', 'username: supervisor', 'success'),
(292, 'user', 1, '2012-07-06 19:14:51', 'VialidadConstructionsDoEdit', 'sad, acción: crear', 'success'),
(293, 'user', 1, '2012-07-06 19:18:09', 'VialidadConstructionsDoEdit', 'asdas, acción: crear', 'success'),
(294, 'user', 1, '2012-07-09 12:33:26', 'CommonDoLogin', 'username: supervisor', 'success'),
(295, 'user', 1, '2012-07-11 13:44:06', 'CommonDoLogin', 'username: supervisor', 'success'),
(296, 'user', 1, '2012-07-11 17:00:56', 'CommonDoLogout', 'username: supervisor', 'success'),
(297, 'user', 1, '2012-07-11 17:01:02', 'CommonDoLogin', 'username: supervisor', 'success'),
(298, 'user', 1, '2012-07-11 17:06:18', 'CommonDoLogin', 'username: supervisor', 'success'),
(299, 'user', 1, '2012-07-11 17:08:58', 'VialidadConstructionsDoEdit', 'sada, acción: crear', 'success'),
(300, 'user', 1, '2012-07-11 17:23:13', 'CommonDoLogin', 'username: supervisor', 'success'),
(301, 'user', 1, '2012-07-11 17:45:20', 'CommonDoLogin', 'username: supervisor', 'success'),
(302, 'user', 1, '2012-07-11 18:06:11', 'VialidadDailyWorkDoEditX', 'Terraplenado, acción: crear', 'success'),
(303, 'user', 1, '2012-07-11 18:10:31', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(304, 'user', 1, '2012-07-11 18:12:09', 'VialidadDailyWorkDoEditX', 'Desmonte, acción: crear', 'success'),
(305, 'user', 1, '2012-07-11 18:12:48', 'VialidadAdjustmentDoEditX', 'Remocion de escombros, acción: crear', 'success'),
(306, 'user', 1, '2012-07-11 18:13:10', 'VialidadOtherDoEditX', 'Contratacion de personal, acción: crear', 'success'),
(307, 'user', 1, '2012-07-11 18:35:10', 'VialidadConstructionsDoEdit', 'fsd, acción: crear', 'success'),
(308, 'user', 1, '2012-07-11 18:53:31', 'VialidadConstructionsDoEdit', 'Prueba de Items, acción: crear', 'success'),
(309, 'user', 1, '2012-07-12 12:45:04', 'CommonDoLogin', 'username: supervisor', 'success'),
(310, 'user', 1, '2012-07-12 13:18:37', 'CommonDoLogin', 'username: supervisor', 'success'),
(311, 'user', 1, '2012-07-12 13:34:24', 'VialidadContractsDoEdit', ', acción: crear', 'success'),
(312, 'user', 1, '2012-07-12 13:59:04', 'CommonDoLogin', 'username: supervisor', 'success'),
(313, 'user', 1, '2012-07-12 13:59:17', 'CommonDoLogout', 'username: supervisor', 'success'),
(314, 'user', 1, '2012-07-12 14:06:36', 'CommonDoLogin', 'username: supervisor', 'success'),
(315, 'user', 1, '2012-07-12 14:30:39', 'VialidadContractsDoEdit', 'aA, acción: crear', 'success'),
(316, 'user', 1, '2012-07-12 14:31:19', 'VialidadConstructionsDoEdit', 'SA, acción: crear', 'success'),
(317, 'user', 1, '2012-07-12 15:13:15', 'VialidadContractsDoEdit', 'fisacalizacion1, acción: crear', 'success'),
(318, 'user', 1, '2012-07-12 15:19:49', 'VialidadConstructionsDoEdit', ', acción: crear', 'success'),
(319, 'user', 1, '2012-07-12 15:56:39', 'CommonDoLogin', 'username: supervisor', 'success'),
(320, 'user', 1, '2012-07-13 14:40:37', 'CommonDoLogin', 'username: supervisor', 'success'),
(321, 'user', 1, '2012-07-13 14:54:28', 'CommonDoLogin', 'username: supervisor', 'success'),
(322, 'user', 1, '2012-07-13 18:16:29', 'CommonDoLogin', 'username: supervisor', 'success'),
(323, 'user', 1, '2012-07-16 12:27:00', 'CommonDoLogin', 'username: supervisor', 'success'),
(324, 'user', 1, '2012-07-16 12:28:06', 'VialidadConstructionsDoEdit', 'ghg, acción: crear', 'success'),
(325, 'user', 1, '2012-07-16 18:12:48', 'CommonDoLogin', 'username: supervisor', 'success'),
(326, 'user', 1, '2012-07-16 20:08:27', 'CommonDoLogin', 'username: supervisor', 'success'),
(327, 'user', 1, '2012-07-16 20:09:45', 'CommonDoLogin', 'username: supervisor', 'success'),
(328, 'user', 1, '2012-07-17 13:59:08', 'CommonDoLogin', 'username: supervisor', 'success'),
(329, 'user', 1, '2012-07-18 20:51:10', 'CommonDoLogin', 'username: supervisor', 'success'),
(330, 'user', 1, '2012-07-23 15:21:04', 'CommonDoLogin', 'username: supervisor', 'success'),
(331, 'user', 1, '2012-07-23 16:42:21', 'CommonDoLogin', 'username: supervisor', 'success'),
(332, 'user', 1, '2012-07-27 16:34:51', 'CommonDoLogin', 'username: supervisor', 'success'),
(333, 'user', 1, '2012-07-30 13:25:45', 'CommonDoLogin', 'username: supervisor', 'success'),
(334, 'user', 1, '2012-07-30 13:25:56', 'CommonDoLogout', 'username: supervisor', 'success'),
(335, 'user', 1, '2012-07-30 13:32:11', 'CommonDoLogin', 'username: supervisor', 'success'),
(336, 'user', 1, '2012-07-30 13:33:05', 'CommonDoLogout', 'username: supervisor', 'success'),
(337, 'user', 1, '2012-07-30 13:33:26', 'CommonDoLogin', 'username: supervisor', 'success'),
(338, 'user', 1, '2012-07-30 13:34:44', 'CommonDoLogout', 'username: supervisor', 'success'),
(339, 'user', 1, '2012-08-07 15:14:19', 'CommonDoLogin', 'username: supervisor', 'success'),
(340, 'user', 1, '2012-08-14 17:33:49', 'CommonDoLogin', 'username: supervisor', 'success'),
(341, 'user', 1, '2012-08-22 17:51:50', 'CommonDoLogin', 'username: supervisor', 'success'),
(342, 'user', 1, '2012-09-04 11:19:12', 'CommonDoLogin', 'username: supervisor', 'success'),
(343, 'user', 1, '2012-09-09 22:10:28', 'CommonDoLogin', 'username: supervisor', 'success'),
(344, 'user', 1, '2012-09-09 22:12:26', 'CommonDoLogout', 'username: supervisor', 'success'),
(345, 'user', 1, '2012-09-11 12:59:37', 'CommonDoLogin', 'username: supervisor', 'success'),
(346, 'user', 1, '2012-09-11 14:15:13', 'CommonDoLogin', 'username: supervisor', 'success'),
(347, 'user', 1, '2012-09-12 12:42:16', 'CommonDoLogin', 'username: supervisor', 'success'),
(348, 'user', 1, '2012-09-12 18:28:37', 'CommonDoLogin', 'username: supervisor', 'success'),
(349, 'user', 1, '2012-09-12 19:14:57', 'VialidadConstructionsDoEdit', ', acción: crear', 'success'),
(350, 'user', 1, '2012-09-19 13:44:55', 'CommonDoLogin', 'username: supervisor', 'success'),
(351, 'user', 1, '2012-09-19 14:26:06', 'CommonDoLogin', 'username: supervisor', 'success'),
(352, 'user', 1, '2012-09-19 18:08:14', 'CommonDoLogin', 'username: supervisor', 'success'),
(353, 'user', 1, '2012-09-19 18:20:05', 'VialidadContractsDoEdit', 'hghfg, acción: crear', 'success'),
(354, 'user', 1, '2012-09-19 18:34:49', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(355, 'user', 1, '2012-09-19 18:36:32', 'VialidadOtherDoEditX', 'Compra de 5 Computadoras, acción: crear', 'success'),
(356, 'user', 1, '2012-09-19 18:37:05', 'VialidadOtherDoEditX', 'Compra de 5 Computadoras, acción: crear', 'success'),
(357, 'user', 1, '2012-09-19 19:08:28', 'CommonDoLogout', 'username: supervisor', 'success'),
(358, 'user', 1, '2012-09-25 17:14:35', 'CommonDoLogin', 'username: supervisor', 'success'),
(359, 'user', 1, '2012-09-25 17:15:17', 'VialidadContractsDoEdit', 'dsfsdfsd, acción: crear', 'success'),
(360, 'user', 1, '2012-10-03 17:59:20', 'CommonDoLogin', 'username: supervisor', 'success'),
(361, 'user', 1, '2012-10-03 19:17:15', 'CommonDoLogout', 'username: supervisor', 'success'),
(362, 'user', 1, '2012-10-04 13:37:26', 'CommonDoLogin', 'username: supervisor', 'success'),
(363, 'user', 1, '2012-10-05 11:41:27', 'CommonDoLogin', 'username: supervisor', 'success'),
(364, 'user', 1, '2012-10-08 13:07:21', 'CommonDoLogin', 'username: supervisor', 'success'),
(365, 'user', 1, '2012-10-08 17:13:43', 'CommonDoLogin', 'username: supervisor', 'success'),
(366, 'user', 1, '2012-10-08 17:14:36', 'CommonDoLogout', 'username: supervisor', 'success'),
(367, 'user', 1, '2012-10-08 17:32:58', 'CommonDoLogin', 'username: supervisor', 'success'),
(368, 'user', 1, '2012-10-09 11:28:22', 'CommonDoLogin', 'username: supervisor', 'success'),
(369, 'user', 1, '2012-10-09 11:32:31', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(370, 'user', 1, '2012-10-09 11:34:35', 'VialidadCertificatesDoEdit', ', acción: crear', 'success'),
(371, 'user', 1, '2012-10-09 11:35:18', 'VialidadCertificatesDoEdit', ', acción: crear', 'success'),
(372, 'user', 1, '2012-10-11 17:09:09', 'CommonDoLogin', 'username: supervisor', 'success'),
(373, 'user', 1, '2012-10-11 17:33:23', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(374, 'user', 1, '2012-10-11 17:35:44', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(375, 'user', 1, '2012-10-11 17:39:03', 'VialidadCertificatesDoEdit', ', acción: crear', 'success'),
(376, 'user', 1, '2012-10-11 17:40:12', 'VialidadCertificatesDoEdit', ', acción: crear', 'success'),
(377, 'user', 1, '2012-10-15 13:52:07', 'CommonDoLogin', 'username: supervisor', 'success'),
(378, 'user', 1, '2012-10-17 17:02:45', 'CommonDoLogin', 'username: supervisor', 'success'),
(379, 'user', 1, '2012-10-17 17:03:28', 'CommonDoLogin', 'username: supervisor', 'success'),
(380, 'user', 1, '2012-10-17 17:33:55', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(381, 'user', 1, '2012-10-18 17:05:23', 'CommonDoLogin', 'username: supervisor', 'success'),
(382, 'user', 1, '2012-10-18 17:32:28', 'VialidadMeasurementRecordsDoEdit', ', acción: crear', 'success'),
(383, 'user', 1, '2012-10-18 17:34:13', 'CommonDoLogin', 'username: supervisor', 'success');

-- --------------------------------------------------------

--
-- Table structure for table `affiliates_affiliate`
--

CREATE TABLE IF NOT EXISTS `affiliates_affiliate` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id afiliado',
  `name` varchar(255) NOT NULL COMMENT 'nombre afiliado',
  `ownerId` int(11) default NULL COMMENT 'Id del usuario administrador del afiliado',
  `internalNumber` varchar(12) default NULL COMMENT 'Id interno',
  `address` varchar(255) default NULL COMMENT 'Direccion afiliado',
  `phone` varchar(50) default NULL COMMENT 'Telefono afiliado',
  `email` varchar(50) default NULL COMMENT 'Email afiliado',
  `contact` varchar(50) default NULL COMMENT 'Nombre de persona de contacto',
  `contactEmail` varchar(100) default NULL COMMENT 'Email de persona de contacto',
  `web` varchar(255) default NULL COMMENT 'Direccion web del afiliado',
  `memo` text COMMENT 'Informacion adicional del afiliado',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `class_key` int(11) default NULL,
  `contact1` varchar(100) default NULL COMMENT 'Nombre de persona de contacto 1',
  `position1` varchar(75) default NULL COMMENT 'Cargo de persona de contacto 1',
  `phone1` varchar(75) default NULL COMMENT 'Telefono de persona de contacto 1',
  `contactEmail1` varchar(100) default NULL COMMENT 'Email de persona de contacto 1',
  `contact2` varchar(100) default NULL COMMENT 'Nombre de persona de contacto 2',
  `position2` varchar(75) default NULL COMMENT 'Cargo de persona de contacto 2',
  `phone2` varchar(75) default NULL COMMENT 'Telefono de persona de contacto 2',
  `contactEmail2` varchar(100) default NULL COMMENT 'Email de persona de contacto 2',
  `contact3` varchar(100) default NULL COMMENT 'Nombre de persona de contacto 3',
  `position3` varchar(75) default NULL COMMENT 'Cargo de persona de contacto 3',
  `phone3` varchar(75) default NULL COMMENT 'Telefono de persona de contacto 3',
  `contactEmail3` varchar(100) default NULL COMMENT 'Email de persona de contacto 3',
  `consortium` tinyint(1) default NULL COMMENT 'Consorcio',
  PRIMARY KEY  (`id`),
  KEY `affiliates_affiliate_FI_1` (`ownerId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Afiliados' AUTO_INCREMENT=12 ;

--
-- Dumping data for table `affiliates_affiliate`
--

INSERT INTO `affiliates_affiliate` (`id`, `name`, `ownerId`, `internalNumber`, `address`, `phone`, `email`, `contact`, `contactEmail`, `web`, `memo`, `created_at`, `updated_at`, `class_key`, `contact1`, `position1`, `phone1`, `contactEmail1`, `contact2`, `position2`, `phone2`, `contactEmail2`, `contact3`, `position3`, `phone3`, `contactEmail3`, `consortium`) VALUES
(1, 'contratista 1', 1, '231312323132', 'Mcal Lopez 1900', '3423432', 'klklkl@hotmail.com', 'Juan Carlos', NULL, NULL, 'Muy buenas referencias comerciales', '2011-11-02 13:24:04', '2012-07-27 17:08:51', 1, 'Juan Carlos', 'Responsable Técnico', NULL, NULL, 'Pepe', 'Responsable comercial', '31214040', 'ddddddaaaaaaaaaaaaaaaafffff', NULL, NULL, NULL, NULL, NULL),
(2, 'verificadora1', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2011-11-02 13:34:38', '2011-11-02 13:34:38', 1, 'Jose', 'Responsable', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'Contratista pirulo', 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2011-12-23 19:36:09', '2011-12-23 19:36:09', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'Fiscalizadora pirulito', 6, '123456789123', 'juncal 3737', '3432432432', NULL, NULL, NULL, NULL, NULL, '2011-12-23 20:01:35', '2011-12-23 20:02:59', 1, 'pepe', 'Encargado', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'Empresa contratista number 2', 9, '12345678', 'Oliva y La Paz', '1234567', NULL, 'Pepe', NULL, NULL, NULL, '2012-01-04 16:44:07', '2012-01-04 16:44:07', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'Fiscalizadora Prueba sin usuario', 10, '123', 'll', '123', 'email@fibertel.com', 'pepe', 'personadecontacto@pp.com.py', NULL, NULL, '2012-01-04 17:32:31', '2012-01-04 18:50:59', 1, 'contacto 1 ', 'gerente', '2334', 'ppe@p.com.py', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 'Contratista Jose María', 11, '3456212', 'Oliva y Estrella', '455454', 'jmgaspa@gmail.com', 'María', 'maria@gmail.com', 'www.josemaria.com', 'información adicional', '2012-05-18 11:50:43', '2012-05-18 11:50:43', 1, 'contacto 1', 'Despacho de mercadería', '45545454', 'contacto1@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 'fiscalizadora de obras sociedad anónima', 12, '654987', 'Mariscal López', '5544', 'info@lafisca.com.ar', 'Aracelly', 'aracelly@gmail.com', 'www.lafisca.com', 'info adicional', '2012-05-18 11:53:34', '2012-05-18 11:53:34', 1, 'contacto 1', 'despacho de mercaderia', '5858588', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'Contratista número 1', 13, '232323', 'Oliva y Estrella', '3434 34344', 'info@contratista1.com', 'Jose Maria', 'josemaria@gmail.com', 'www.contratista1.com', 'informacion adicional que se quiera cargar', '2012-05-18 12:33:31', '2012-05-18 12:33:31', 1, 'contacto 1', 'encargado de obra', '3434 4444', 'contacto1@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 'Fiscalizadora 1', 14, '4444444', 'Mariscal López 2233', '4534545', 'fisca1@gmail.com', 'Luciana Polischuk', 'luciana@gmail.com', 'www.fisca1.com', 'informacion adicional que se quiera cargar', '2012-05-18 12:36:15', '2012-05-18 12:36:15', 1, 'Bersano Jose', 'Director', '223322', 'bersano@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 'Prueba', 15, '123456-8', 'Oliva esquina Alberdi', '123456', 'prueba@mopc.gov.py', 'juan perez', 'juan@prueba.com.py', 'www.prueba.com.py', 'prueba', '2012-05-31 13:09:18', '2012-05-31 13:09:18', 1, 'jose gonzalez', 'gerente', '321654', 'jose@prueba.com.py', 'andres perez', 'administrador', '5564252', 'andres@prueba.com.py', 'carlos gonzalez', 'superintendente', '589585', 'carlos@prueba.com.py', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `affiliates_branch`
--

CREATE TABLE IF NOT EXISTS `affiliates_branch` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id de la sucursal',
  `affiliateId` int(11) NOT NULL COMMENT 'Id del afiliado',
  `number` int(11) NOT NULL COMMENT 'Numero de la sucursal',
  `code` varchar(20) default NULL COMMENT 'Codigo de la sucursal',
  `name` varchar(255) default NULL COMMENT 'Nombre de la sucursal',
  `phone` varchar(100) default NULL COMMENT 'Telefono de la sucursal',
  `contact` varchar(50) default NULL COMMENT 'Nombre de persona de contacto',
  `contactEmail` varchar(100) default NULL COMMENT 'Email de persona de contacto',
  `memo` text COMMENT 'Informacion adicional de la sucursal',
  PRIMARY KEY  (`id`),
  KEY `affiliates_branch_FI_1` (`affiliateId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Sucursales de Afiliados' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `affiliates_consortium`
--

CREATE TABLE IF NOT EXISTS `affiliates_consortium` (
  `affiliate_1` int(11) NOT NULL,
  `affiliate_2` int(11) NOT NULL,
  PRIMARY KEY  (`affiliate_1`,`affiliate_2`),
  KEY `FI_iliate_2` (`affiliate_2`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Affiliates que componen el Consorcio';

--
-- Dumping data for table `affiliates_consortium`
--

INSERT INTO `affiliates_consortium` (`affiliate_1`, `affiliate_2`) VALUES
(1, 1),
(1, 3),
(1, 11),
(9, 10);

-- --------------------------------------------------------

--
-- Table structure for table `affiliates_group`
--

CREATE TABLE IF NOT EXISTS `affiliates_group` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Group ID',
  `name` varchar(255) NOT NULL COMMENT 'Group Name',
  `created` datetime NOT NULL COMMENT 'Creation date for',
  `updated` datetime NOT NULL COMMENT 'Last update date',
  `bitLevel` int(11) default NULL COMMENT 'Nivel',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `affiliates_group_U_1` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Groups' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `affiliates_level`
--

CREATE TABLE IF NOT EXISTS `affiliates_level` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Level ID',
  `name` varchar(255) NOT NULL COMMENT 'Level Name',
  `bitLevel` int(11) default NULL COMMENT 'Bit del nivel',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `affiliates_level_U_1` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Levels' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `affiliates_level`
--

INSERT INTO `affiliates_level` (`id`, `name`, `bitLevel`) VALUES
(1, 'Usuario Contratista', 1),
(2, 'Usuario Verificadora', 2);

-- --------------------------------------------------------

--
-- Table structure for table `affiliates_user`
--

CREATE TABLE IF NOT EXISTS `affiliates_user` (
  `id` int(11) NOT NULL auto_increment COMMENT 'User Id',
  `affiliateId` int(11) NOT NULL COMMENT 'Id afiliado',
  `username` varchar(255) NOT NULL COMMENT 'username',
  `password` varchar(255) NOT NULL COMMENT 'password',
  `passwordUpdated` date default NULL COMMENT 'Fecha de actualizacion de la clave',
  `levelId` int(11) default NULL COMMENT 'User Level',
  `lastLogin` datetime default NULL COMMENT 'Fecha del ultimo login del usuario',
  `timezone` varchar(25) default NULL COMMENT 'Timezone GMT del usuario',
  `name` varchar(255) default NULL COMMENT 'name',
  `surname` varchar(255) default NULL COMMENT 'surname',
  `mailAddress` varchar(255) default NULL COMMENT 'Email',
  `mailAddressAlt` varchar(90) default NULL COMMENT 'Direccion electronica alternativa',
  `recoveryHash` varchar(255) default NULL COMMENT 'Hash enviado para la recuperacion de clave',
  `recoveryHashCreatedOn` datetime default NULL COMMENT 'Momento de la solicitud para la recuperacion de clave',
  `deleted_at` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `affiliates_user_U_1` (`username`),
  KEY `affiliates_user_FI_1` (`levelId`),
  KEY `affiliates_user_FI_2` (`affiliateId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Usuarios de afiliado' AUTO_INCREMENT=17 ;

--
-- Dumping data for table `affiliates_user`
--

INSERT INTO `affiliates_user` (`id`, `affiliateId`, `username`, `password`, `passwordUpdated`, `levelId`, `lastLogin`, `timezone`, `name`, `surname`, `mailAddress`, `mailAddressAlt`, `recoveryHash`, `recoveryHashCreatedOn`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, 'contratista3', 'fbc478ac36ea7b8e140495a9846f8c12', '2011-11-02', 1, NULL, NULL, 'Ladrillo 2', 'Hueco', 'sdonofrio@gmail.com', NULL, NULL, NULL, NULL, '2011-11-02 13:24:04', '2011-12-28 18:32:25'),
(2, 2, 'verificador1', 'fbc478ac36ea7b8e140495a9846f8c12', '2011-11-02', 2, NULL, NULL, 'Nombre', 'Apellido', 'sdonofrio@gmail.com', NULL, NULL, NULL, NULL, '2011-11-02 13:34:38', '2011-12-23 16:04:16'),
(3, 1, 'contratista2', 'efe9f8d50aa632efc0b2d3751f98da0d', '2011-12-23', 1, NULL, NULL, 'El contratista', 'El ladrillito', 'contratista@elladrillito.com.py', NULL, NULL, NULL, NULL, '2011-12-23 15:53:21', '2011-12-23 15:53:21'),
(4, 1, 'daniel', 'efe9f8d50aa632efc0b2d3751f98da0d', '2011-12-23', 1, '2011-12-23 16:25:42', NULL, 'Daniel', 'Grois', 'davidgroisman@gmail.com', NULL, NULL, NULL, NULL, '2011-12-23 16:14:36', '2011-12-23 16:27:25'),
(5, 3, '', 'efe9f8d50aa632efc0b2d3751f98da0d', '2011-12-23', 1, NULL, NULL, NULL, NULL, 'davidgroisman@gmail.com', NULL, NULL, NULL, NULL, '2011-12-23 19:36:09', '2011-12-23 19:36:09'),
(6, 4, 'valeria', 'efe9f8d50aa632efc0b2d3751f98da0d', '2011-12-23', 2, NULL, NULL, 'valeria Dora', 'Gros', 'valerita@gros.com.ar', NULL, NULL, NULL, NULL, '2011-12-23 20:01:35', '2011-12-23 20:01:35'),
(7, 4, 'contratista 2', 'efe9f8d50aa632efc0b2d3751f98da0d', '2011-12-28', 1, NULL, NULL, 'David', 'Groisman', 'davidgroisman@gmail.com', NULL, NULL, NULL, NULL, '2011-12-28 18:29:13', '2011-12-28 18:29:13'),
(8, 1, 'mario', 'f7001cd106ce07150f01c46df65de07c', '2011-12-28', 1, NULL, NULL, 'Mario', 'Brother', 'mario@brother.com.py', NULL, NULL, NULL, NULL, '2011-12-28 18:30:03', '2011-12-28 18:30:03'),
(9, 5, 'usuariocontratista', 'efe9f8d50aa632efc0b2d3751f98da0d', '2012-01-04', 1, NULL, NULL, 'Usuario 1', 'Apellido del usuario', 'pepeusuario@fibertel.com.py', NULL, NULL, NULL, NULL, '2012-01-04 16:44:07', '2012-01-04 16:44:07'),
(10, 6, 'prueba de usuario', 'efe9f8d50aa632efc0b2d3751f98da0d', '2012-01-04', 2, NULL, NULL, 'Juan', 'Zarabia', 'juan@zarabia.com.py', NULL, NULL, NULL, NULL, '2012-01-04 17:32:31', '2012-01-04 17:32:31'),
(11, 7, 'jmaria', 'fbc478ac36ea7b8e140495a9846f8c12', '2012-05-18', 1, NULL, NULL, 'Jose María', 'Gasparin', 'jmgaspa@gmail.com', NULL, NULL, NULL, NULL, '2012-05-18 11:50:43', '2012-05-18 11:50:43'),
(12, 8, 'fisca1', 'fbc478ac36ea7b8e140495a9846f8c12', '2012-05-18', 2, NULL, NULL, 'Manuel', 'Torrente', 'torrente@gmail.com', NULL, NULL, NULL, NULL, '2012-05-18 11:53:34', '2012-05-18 11:53:34'),
(13, 9, 'contra1', 'c332de8af1f0db112f7a0d4e6df7b996', '2012-05-18', 1, NULL, NULL, 'Manuel', 'Garrido', 'manuelgarrido@gmail.com', NULL, NULL, NULL, NULL, '2012-05-18 12:33:31', '2012-05-18 12:33:31'),
(14, 10, 'fisca11', 'c332de8af1f0db112f7a0d4e6df7b996', '2012-05-18', 2, NULL, NULL, 'Jose', 'Bersano', 'bersano@gmail.com', NULL, NULL, NULL, NULL, '2012-05-18 12:36:15', '2012-05-18 12:36:15'),
(15, 11, 'supervisor', 'd40a4afe38b91cf04bdecc71bf4db659', '2012-05-31', 1, NULL, NULL, 'supervisor', 'supervisor', 'supervisor@prueba.com.py', NULL, NULL, NULL, NULL, '2012-05-31 13:09:18', '2012-05-31 13:09:18'),
(16, 3, 'gm', '3fdb786ad210057a47f8ed1dad927c62', '2012-06-06', 2, NULL, NULL, NULL, NULL, 'gvmd@gmail.com', NULL, NULL, NULL, NULL, '2012-06-06 15:51:43', '2012-06-06 15:51:43');

-- --------------------------------------------------------

--
-- Table structure for table `affiliates_userGroup`
--

CREATE TABLE IF NOT EXISTS `affiliates_userGroup` (
  `userId` int(11) NOT NULL COMMENT 'Group ID',
  `groupId` int(11) NOT NULL COMMENT 'Group ID',
  PRIMARY KEY  (`userId`,`groupId`),
  KEY `affiliates_userGroup_FI_2` (`groupId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Users / Groups';

-- --------------------------------------------------------

--
-- Table structure for table `common_alertSubscription`
--

CREATE TABLE IF NOT EXISTS `common_alertSubscription` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) default NULL COMMENT 'Nombre de la suscripcion',
  `entityName` varchar(50) default NULL COMMENT 'Nombre unico de la entidad asociada.',
  `entityDateFieldUniqueName` varchar(100) default NULL COMMENT 'Nombre unico del campo fecha',
  `entityBooleanFieldUniqueName` varchar(100) default NULL COMMENT 'Nombre unico del campo a evaluar por verdadero o falso.',
  `anticipationDays` int(11) default NULL COMMENT 'Cantidad de dias de anticipacion. Se usa para evaluar campos tipo fecha.',
  `entityNameFieldUniqueName` varchar(100) default NULL COMMENT 'Campo a imprimir en representacion del nombre de cada instancia de la entidad',
  `extraRecipients` text COMMENT 'Destinatarios extra',
  PRIMARY KEY  (`id`),
  KEY `common_alertSubscription_FI_1` (`entityName`),
  KEY `common_alertSubscription_FI_2` (`entityNameFieldUniqueName`),
  KEY `common_alertSubscription_FI_3` (`entityDateFieldUniqueName`),
  KEY `common_alertSubscription_FI_4` (`entityBooleanFieldUniqueName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Suscripciones de alerta' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `common_alertSubscriptionUser`
--

CREATE TABLE IF NOT EXISTS `common_alertSubscriptionUser` (
  `alertSubscriptionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  PRIMARY KEY  (`alertSubscriptionId`,`userId`),
  KEY `common_alertSubscriptionUser_FI_2` (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Relacion AlertSubscription - User';

-- --------------------------------------------------------

--
-- Table structure for table `common_internalMail`
--

CREATE TABLE IF NOT EXISTS `common_internalMail` (
  `id` int(11) NOT NULL auto_increment,
  `subject` varchar(255) default NULL COMMENT 'Asunto',
  `body` text COMMENT 'Cuerpo del mensaje',
  `recipientId` int(11) default NULL COMMENT 'Receptor del mensaje',
  `recipientType` varchar(50) default NULL COMMENT 'Tipo de receptor del mensaje',
  `readOn` datetime default NULL COMMENT 'Momento en que el mensaje fue leido',
  `fromId` int(11) default NULL COMMENT 'Remitente',
  `fromType` varchar(50) default NULL COMMENT 'Tipo de remitente',
  `to` longblob COMMENT 'Destinatarios',
  `replyId` int(11) default NULL COMMENT 'Id del mensaje al que responde',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `deleted_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `common_internalMail_FI_1` (`replyId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Mensajes internos' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `common_menuItem`
--

CREATE TABLE IF NOT EXISTS `common_menuItem` (
  `id` int(11) NOT NULL auto_increment,
  `action` varchar(100) default NULL COMMENT 'Nombre de la accion a ejecutar',
  `url` varchar(255) default NULL COMMENT 'Direccion del enlace',
  `order` int(11) default NULL COMMENT 'Indice de ordenamiento',
  `parentId` int(11) default NULL COMMENT 'Id item padre',
  `newWindow` tinyint(1) NOT NULL default '0' COMMENT 'Abrir el enlace en nueva ventana',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Items de los menues dinamicos' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `common_menuItemInfo`
--

CREATE TABLE IF NOT EXISTS `common_menuItemInfo` (
  `id` int(11) NOT NULL auto_increment,
  `menuItemId` int(11) NOT NULL,
  `name` varchar(100) NOT NULL COMMENT 'Nombre a mostrar en el item',
  `title` varchar(255) default NULL COMMENT 'Titulo a mostrar en el item',
  `description` text COMMENT 'Descripcion del item',
  `language` varchar(100) NOT NULL COMMENT 'Idioma',
  PRIMARY KEY  (`id`),
  KEY `common_menuItemInfo_FI_1` (`menuItemId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Items de los menues dinamicos' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `common_scheduleSubscription`
--

CREATE TABLE IF NOT EXISTS `common_scheduleSubscription` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) default NULL COMMENT 'Nombre de la suscripcion',
  `entityName` varchar(50) default NULL COMMENT 'Nombre unico de la entidad asociada.',
  `entityDateFieldUniqueName` varchar(100) default NULL COMMENT 'Nombre unico del campo fecha',
  `entityBooleanFieldUniqueName` varchar(100) default NULL COMMENT 'Nombre unico del campo a evaluar por verdadero o falso.',
  `anticipationDays` int(11) default NULL COMMENT 'Cantidad de dias de anticipacion. Se usa para evaluar campos tipo fecha.',
  `entityNameFieldUniqueName` varchar(100) default NULL COMMENT 'Campo a imprimir en representacion del nombre de cada instancia de la entidad',
  `extraRecipients` text COMMENT 'Destinatarios extra',
  PRIMARY KEY  (`id`),
  KEY `common_scheduleSubscription_FI_1` (`entityName`),
  KEY `common_scheduleSubscription_FI_2` (`entityNameFieldUniqueName`),
  KEY `common_scheduleSubscription_FI_3` (`entityDateFieldUniqueName`),
  KEY `common_scheduleSubscription_FI_4` (`entityBooleanFieldUniqueName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Suscripciones de schedulea' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `common_scheduleSubscriptionUser`
--

CREATE TABLE IF NOT EXISTS `common_scheduleSubscriptionUser` (
  `scheduleSubscriptionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  PRIMARY KEY  (`scheduleSubscriptionId`,`userId`),
  KEY `common_scheduleSubscriptionUser_FI_2` (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Relacion ScheduleSubscription - User';

-- --------------------------------------------------------

--
-- Table structure for table `documents_document`
--

CREATE TABLE IF NOT EXISTS `documents_document` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id documento',
  `title` varchar(255) default NULL COMMENT 'El titulo del archivo',
  `realFilename` varchar(255) default NULL COMMENT 'El nombre real del archivo',
  `date` date default NULL COMMENT 'Fecha',
  `categoryId` int(11) default NULL COMMENT 'Numero de tipo de archivo',
  `description` varchar(255) default NULL COMMENT 'Descripcion del archivo',
  `document_date` date default NULL COMMENT 'Fecha del documento',
  `password` varchar(32) default NULL COMMENT 'Clave del archivo',
  `author` varchar(255) default NULL COMMENT 'Autor(es)',
  `keyWords` varchar(255) default NULL COMMENT 'Palabras clave',
  `number` varchar(10) default NULL COMMENT 'Numero de Publicacion',
  `size` int(11) default NULL COMMENT 'Tamano de archivo',
  `fullTextContent` text COMMENT 'Contenido del archivo',
  PRIMARY KEY  (`id`),
  FULLTEXT KEY `fullTextContent` (`title`,`realFilename`,`description`,`author`,`keyWords`,`fullTextContent`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Documentos del sistema' AUTO_INCREMENT=10 ;

--
-- Dumping data for table `documents_document`
--

INSERT INTO `documents_document` (`id`, `title`, `realFilename`, `date`, `categoryId`, `description`, `document_date`, `password`, `author`, `keyWords`, `number`, `size`, `fullTextContent`) VALUES
(1, '', 'auto_blackberry.png', '2011-11-02', NULL, '', '2011-11-02', NULL, NULL, NULL, NULL, 8782, NULL),
(3, 'Parametricas', 'EJEMPLO DE COEFICIENTES PARAMETRICOS DE UN PUENTE.xls', '2011-11-10', NULL, '', '2011-11-10', NULL, NULL, NULL, NULL, 355328, 'Array'),
(4, 'Respaldo de precio 03 11 11', 'DIARIO031111.pdf', '2011-11-18', NULL, 'copia de cotizacion arena', '2011-11-18', NULL, NULL, NULL, NULL, 389579, ''),
(5, 'qwe', 'Diagram1.png', '2011-12-01', NULL, 'asd', '2011-12-01', NULL, NULL, NULL, NULL, 27593, NULL),
(7, 'Prueba para visualización', 'Doc40.doc', '2011-12-28', NULL, '', '2011-12-28', NULL, NULL, NULL, NULL, 381952, 'Debajo de todo, al final de la página\n'),
(8, 'nnnnn', 'usuariostablero.xls', '2012-07-23', NULL, 'fsdfsd', '2012-07-23', NULL, NULL, NULL, NULL, 56832, 'Array'),
(9, '', 'sugerencias certificacion.doc', '2012-09-25', NULL, '', '2012-09-25', NULL, NULL, NULL, NULL, 37376, 'DEPENDENCIA: UE-GEMANS\nNombre: Luis Fernando Rodríguez Cáceres\nSugerencia:\nEn el modulo administración de obras es más importante que aparezca la “ orden de inicio” / “orden de proceder” además de la fecha de  firma del contrato, debido a que el plazo se computa desde la orden de inicio\nAdaptar al sistema de contrato GMAN para la etapa de mantenimiento que se paga por niveles de servicio, no por precios unitarios.\nDEPENDENCIA: D.O.P.\nNombre: Arq. Rubén Acuña\nSugerencia:\nEditar actos de medición, agregar una columna  mas donde aparezca la diferencia en exceso o faltante de la cantidad inicial presupuestada.\nDEPENDENCIA: Direcciones de caminos vecinales\nNombre: Oscar Noguera Recalde\nSugerencia:\nQue las consultorías concurran en las direcciones para tomar insitu las particularidades  y cargar como práctica con sus peculiaridades  y entrenar a los operadores  y enseñar la resolución de los problemas.\nDEPENDENCIA: Dirección de planificación Vial\nNombre : Víctor Olmedo\nSugerencia:\nPara la certificación de obras visualizar certificados acumulados hasta la fecha, de avance físico / financiero del mes programado.\nHasta  el avance físico/ financiero del mes ejecutado.\nHasta el avance físico /financiero  acumulado programado.\nHasta el avance físico /financiero acumulado ejecutado.\nDEPENDENCIA: UEP 1822-DV\nNombre: Hugo Miranda.\nSugerencia:\nEn el registro de un contrato  incluir: plazo modificar empresas integrantes, fiscalización-integrantes, orden de inicio-vigencia- unidad ejecutora.\nPara dar de alta el ítem, simplificar toma de planimétria . Ej: desplegar ítems y solo cargar incidencia.\nQue pase en contrato a ejecución donde se da de alta un contrato y al tiempo ya se requiere ajustar con índices antiguos ( anteriores al alta )\nAl crear un certificado debe solicitar el nombre de la obra.\nDEPENDENCIA: UEP1822/OL-PR, BID\nNombre: Ignacio Correa.\nSugerencia:\nVer ajustes de precio por variación de cantidades largas ( orden de variación – continua modificado)\nVer pagos de certificado resúmenes y certificados ajustados.\nSocialización del trabajo del tablero de control con contraseña\nVer pautas de seguros.\nDEPENDENCIA: DTO. de Administración Vial.\nNombre: Mario E. Galeano\nSugerencia:\nRealizar reuniones periódicas con cada dirección ( vialidad caminos vecinales, obras públicas) para que cada una presente.\nDEPENDENCIA: UEP\nNombre: Rubén del Puerto\nSugerencia:\nConvendría mayor presencia de los consultores de los consultores para agilizar el avance del servicio.\nDEPENDENCIA: DTO de Ejecución – Dirección de caminos Vecinales.\nNombre: Osvaldo López.\nSugerencia:\nAdecuar la forma de presentación del Certificado Electrónico al tipo de planillas requeridas por la supervisión, dado que existe responsabilidad legal del funcionario del M.O.P.C  respecto a la validación  o no del certificado presentado.\n');

-- --------------------------------------------------------

--
-- Table structure for table `documents_relatedEntity`
--

CREATE TABLE IF NOT EXISTS `documents_relatedEntity` (
  `documentId` int(11) NOT NULL COMMENT 'Id del documento',
  `entityType` varchar(32) NOT NULL COMMENT 'Nombre de la entidad',
  `entityId` int(11) NOT NULL COMMENT 'Id de la entidad asociada',
  PRIMARY KEY  (`documentId`,`entityType`,`entityId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `documents_relatedEntity`
--

INSERT INTO `documents_relatedEntity` (`documentId`, `entityType`, `entityId`) VALUES
(8, 'Contract', 1),
(9, 'Contract', 12);

-- --------------------------------------------------------

--
-- Table structure for table `modules_dependency`
--

CREATE TABLE IF NOT EXISTS `modules_dependency` (
  `moduleName` varchar(50) NOT NULL COMMENT 'Modulo',
  `dependence` varchar(50) NOT NULL COMMENT 'Modulos de los cuales depende',
  PRIMARY KEY  (`moduleName`,`dependence`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Dependencia de modulos ';

-- --------------------------------------------------------

--
-- Table structure for table `modules_entity`
--

CREATE TABLE IF NOT EXISTS `modules_entity` (
  `moduleName` varchar(50) NOT NULL COMMENT 'nombre del modulo',
  `name` varchar(50) NOT NULL COMMENT 'Nombre de la entidad',
  `phpName` varchar(50) default NULL COMMENT 'Nombre de la Clase',
  `description` varchar(255) default NULL COMMENT 'Descripcion de la entidad',
  `softDelete` tinyint(1) default NULL COMMENT 'Indica si usa softdelete',
  `relation` tinyint(1) default NULL COMMENT 'Indica si es una entidad principal o una relacion de dos entidades',
  `saveLog` tinyint(1) default NULL COMMENT 'Indica si guarda log de cambios',
  `nestedset` tinyint(1) default NULL COMMENT 'Indica si es una entidad nestedset',
  `scopeFieldUniqueName` varchar(100) default NULL COMMENT 'Indica el campo que es usado como scope en el nestedset',
  `behaviors` longblob COMMENT 'Indica los behaviors que tiene la entidad',
  PRIMARY KEY  (`name`),
  KEY `modules_entity_FI_1` (`moduleName`),
  KEY `modules_entity_FI_2` (`scopeFieldUniqueName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Entidades de modulos ';

-- --------------------------------------------------------

--
-- Table structure for table `modules_entityField`
--

CREATE TABLE IF NOT EXISTS `modules_entityField` (
  `uniqueName` varchar(100) NOT NULL COMMENT 'Nombre unico del campo',
  `entityName` varchar(50) NOT NULL COMMENT 'Nombre de la entidad',
  `name` varchar(50) NOT NULL COMMENT 'Nombre del campo (max 50 caracteres)',
  `description` varchar(255) default NULL COMMENT 'Descripcion del campo (comment)',
  `isRequired` tinyint(1) default NULL COMMENT 'Indica si es obligatorio',
  `defaultValue` varchar(255) default NULL COMMENT 'Valor por defecto',
  `isPrimaryKey` tinyint(1) default NULL COMMENT 'Indica si clave primaria',
  `isAutoIncrement` tinyint(1) default NULL COMMENT 'Indica si el campo es autoincremental',
  `order` int(11) NOT NULL COMMENT 'Orden',
  `type` int(11) NOT NULL COMMENT 'Tipo de campo',
  `unique` tinyint(1) default NULL COMMENT 'Indica si es unica',
  `size` int(11) default NULL COMMENT 'Size del campo',
  `aggregateExpression` varchar(255) default NULL COMMENT 'Detalles de la expresion agregada',
  `label` varchar(255) default NULL COMMENT 'Etiqueta para el formulario',
  `formFieldType` int(11) default NULL COMMENT 'Tipo de campo para formulario',
  `formFieldSize` int(11) default NULL COMMENT 'Size del campo en formulario',
  `formFieldLines` int(11) default NULL COMMENT 'Size del campo en formulario lineas',
  `formFieldUseCalendar` tinyint(1) default NULL COMMENT 'Si utiliza o no el calendario en formulario',
  `foreignKeyTable` varchar(50) default NULL COMMENT 'Entidad con la que enlaza la clave remota',
  `foreignKeyRemote` varchar(100) default NULL COMMENT 'Nombre del campo en la tabla remota',
  `onDelete` varchar(30) default NULL COMMENT 'Comportamiento onDelete',
  `automatic` tinyint(1) default NULL COMMENT 'Indica si es una columna autogenerada por un behavior',
  PRIMARY KEY  (`uniqueName`),
  KEY `modules_entityField_FI_1` (`entityName`),
  KEY `modules_entityField_FI_2` (`foreignKeyTable`),
  KEY `modules_entityField_FI_3` (`foreignKeyRemote`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Campos de las entidades de modulos';

-- --------------------------------------------------------

--
-- Table structure for table `modules_entityFieldValidation`
--

CREATE TABLE IF NOT EXISTS `modules_entityFieldValidation` (
  `entityFieldUniqueName` varchar(100) NOT NULL COMMENT 'Nombre unico del campo',
  `name` varchar(50) NOT NULL COMMENT 'Nombre del validador',
  `value` varchar(50) default NULL COMMENT 'Valor del validador',
  `message` varchar(255) default NULL COMMENT 'Mensaje',
  PRIMARY KEY  (`entityFieldUniqueName`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Validaciones de los campos de las entidades de modulos ';

-- --------------------------------------------------------

--
-- Table structure for table `modules_label`
--

CREATE TABLE IF NOT EXISTS `modules_label` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id module label',
  `name` varchar(255) NOT NULL COMMENT 'nombre del modulo',
  `label` varchar(255) default NULL COMMENT 'Etiqueta',
  `description` varchar(255) default NULL COMMENT 'Descripcion del modulo',
  `language` varchar(100) default NULL COMMENT 'idioma de la etiqueta',
  PRIMARY KEY  (`id`,`name`),
  KEY `modules_label_FI_1` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Etiquetas de modulos ' AUTO_INCREMENT=20 ;

--
-- Dumping data for table `modules_label`
--

INSERT INTO `modules_label` (`id`, `name`, `label`, `description`, `language`) VALUES
(4, 'common', 'General', 'Aplicaciones comunes al sistema', 'esp'),
(8, 'vialidad', 'Vialidad', 'Módulo con funcionalidades propial del Ministerio de Obras Públicas y Comunicaciones', 'esp'),
(10, 'affiliates', 'Contratistas', 'Administración de Empresas Asociadas', 'esp'),
(12, 'backup', 'Respaldos', 'Administración de respaldos', 'esp'),
(14, 'security', 'Seguridad', 'Administración de permisos', 'esp'),
(19, 'users', 'Usuarios', 'Módulo de Administración de Usuarios', 'esp');

-- --------------------------------------------------------

--
-- Table structure for table `modules_module`
--

CREATE TABLE IF NOT EXISTS `modules_module` (
  `name` varchar(255) NOT NULL COMMENT 'nombre del modulo',
  `active` tinyint(1) NOT NULL default '0' COMMENT 'Estado del modulo',
  `alwaysActive` tinyint(1) NOT NULL default '0' COMMENT 'Modulo siempre activo',
  `hasCategories` tinyint(1) NOT NULL default '0' COMMENT 'El Modulo tiene categorias relacionadas?',
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT=' Registro de modulos';

--
-- Dumping data for table `modules_module`
--

INSERT INTO `modules_module` (`name`, `active`, `alwaysActive`, `hasCategories`) VALUES
('affiliates', 1, 0, 0),
('common', 1, 1, 0),
('vialidad', 1, 0, 0),
('backup', 1, 0, 0),
('security', 1, 0, 0),
('users', 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `multilang_language`
--

CREATE TABLE IF NOT EXISTS `multilang_language` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `code` varchar(30) NOT NULL,
  `locale` varchar(30) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `multilang_language`
--

INSERT INTO `multilang_language` (`id`, `name`, `code`, `locale`) VALUES
(1, 'Español', 'esp', 'es_ES.utf8');

-- --------------------------------------------------------

--
-- Table structure for table `multilang_text`
--

CREATE TABLE IF NOT EXISTS `multilang_text` (
  `id` int(11) NOT NULL,
  `moduleName` varchar(255) NOT NULL,
  `languageCode` varchar(30) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY  (`id`,`moduleName`,`languageCode`),
  KEY `multilang_text_FI_1` (`languageCode`),
  KEY `multilang_text_FI_2` (`moduleName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `multilang_text`
--

INSERT INTO `multilang_text` (`id`, `moduleName`, `languageCode`, `text`) VALUES
(1, 'common', 'esp', 'Editar'),
(2, 'common', 'esp', 'Eliminar'),
(3, 'common', 'esp', 'Aceptar'),
(4, 'common', 'esp', 'Buscar'),
(5, 'common', 'esp', 'Inicio'),
(6, 'common', 'esp', 'Anterior'),
(7, 'common', 'esp', 'Página'),
(8, 'common', 'esp', 'de'),
(9, 'common', 'esp', 'Siguiente'),
(10, 'common', 'esp', 'Última'),
(11, 'common', 'esp', 'Español'),
(12, 'common', 'esp', 'Si'),
(13, 'common', 'esp', 'No'),
(14, 'common', 'esp', 'Close'),
(15, 'common', 'esp', 'acción: editar'),
(16, 'common', 'esp', 'acción: crear'),
(17, 'common', 'esp', 'acción: eliminar'),
(18, 'common', 'esp', 'Módulo'),
(19, 'common', 'esp', 'Usuarios'),
(20, 'common', 'esp', 'Configuración'),
(21, 'common', 'esp', 'Global'),
(22, 'common', 'esp', 'E-mail'),
(23, 'common', 'esp', 'Exportaciones'),
(24, 'common', 'esp', 'Idioma'),
(25, 'common', 'esp', 'Novedades'),
(26, 'common', 'esp', 'Calendario'),
(27, 'common', 'esp', 'Banners'),
(28, 'common', 'esp', 'Contenido'),
(29, 'common', 'esp', 'Documentos'),
(30, 'common', 'esp', 'Categorías'),
(31, 'common', 'esp', 'Formularios'),
(32, 'common', 'esp', 'Respaldos'),
(33, 'common', 'esp', 'General'),
(34, 'common', 'esp', 'Instalación'),
(35, 'common', 'esp', 'Registro'),
(36, 'common', 'esp', 'Seguridad'),
(37, 'common', 'esp', 'Histórico'),
(38, 'common', 'esp', 'Proveedores'),
(39, 'common', 'esp', 'Módulos'),
(40, 'common', 'esp', 'Exportación'),
(41, 'common', 'esp', 'Newsletters'),
(42, 'common', 'esp', 'Segmentación'),
(43, 'common', 'esp', 'Encuestas'),
(44, 'common', 'esp', 'Catálogo'),
(45, 'common', 'esp', 'Órdenes'),
(46, 'common', 'esp', 'Proyectos'),
(47, 'common', 'esp', 'Objetivos'),
(48, 'common', 'esp', 'Procesos'),
(49, 'common', 'esp', 'Indicadores'),
(50, 'common', 'esp', 'Actividades'),
(51, 'common', 'esp', 'Hitos'),
(52, 'common', 'esp', 'Tablero de Gestión'),
(53, 'common', 'esp', 'Regiones'),
(54, 'common', 'esp', 'Cargos'),
(55, 'common', 'esp', 'Desempeño de cargo'),
(56, 'common', 'esp', 'Asuntos Públicos'),
(57, 'common', 'esp', 'Prensa'),
(58, 'common', 'esp', 'Funcionarios'),
(1, 'system', 'esp', 'Sistema'),
(2, 'system', 'esp', 'Parámetros'),
(3, 'system', 'esp', 'Modo captura de errores'),
(4, 'system', 'esp', 'Modo en desarrollo'),
(5, 'system', 'esp', 'Captura salida de mails'),
(6, 'system', 'esp', 'En mantenimiento'),
(7, 'system', 'esp', 'Mensaje en mantenimiento'),
(8, 'system', 'esp', 'Login unificado'),
(9, 'system', 'esp', 'Zona horaria de aplicación'),
(10, 'system', 'esp', 'Formato de fecha'),
(11, 'system', 'esp', 'Separador de miles'),
(12, 'system', 'esp', 'Separador de decimales'),
(13, 'system', 'esp', 'Cantidad de decimales'),
(14, 'system', 'esp', 'Nombre corto del sitio'),
(15, 'system', 'esp', 'Descripción del sitio'),
(16, 'system', 'esp', 'Nombre corto del sitio'),
(17, 'system', 'esp', 'email administrador'),
(18, 'system', 'esp', 'Destinatario errores'),
(19, 'system', 'esp', 'Remitente del sistema'),
(20, 'system', 'esp', 'Prefijo para tabla'),
(21, 'system', 'esp', 'Novedades para usuarios'),
(22, 'system', 'esp', 'Novedades para Afiliados'),
(23, 'system', 'esp', 'Reporte de errores'),
(24, 'system', 'esp', 'No verificar permisos de acciones'),
(25, 'system', 'esp', 'No verifica login en acciones'),
(26, 'system', 'esp', 'Líneas por página'),
(27, 'system', 'esp', 'Idioma'),
(28, 'system', 'esp', 'Opciones de archivos'),
(29, 'system', 'esp', 'Directorios raíz'),
(30, 'system', 'esp', 'Directorio 1'),
(31, 'system', 'esp', 'Título'),
(32, 'system', 'esp', 'Ruta'),
(33, 'system', 'esp', 'Directorio 2'),
(34, 'system', 'esp', 'Directorio 3'),
(1, 'common', 'sys', 'Edit'),
(2, 'common', 'sys', 'Delete'),
(3, 'common', 'sys', 'Accept'),
(4, 'common', 'sys', 'Search'),
(5, 'common', 'sys', 'First'),
(6, 'common', 'sys', 'Prev.'),
(7, 'common', 'sys', 'Page'),
(8, 'common', 'sys', 'of'),
(9, 'common', 'sys', 'Next'),
(10, 'common', 'sys', 'Last'),
(11, 'common', 'sys', 'English'),
(12, 'common', 'sys', 'Yes'),
(13, 'common', 'sys', 'No'),
(14, 'common', 'sys', 'Close'),
(15, 'common', 'sys', 'action: edit'),
(16, 'common', 'sys', 'action: create'),
(17, 'common', 'sys', 'action: delete'),
(18, 'common', 'sys', 'module'),
(19, 'common', 'sys', 'users'),
(20, 'common', 'sys', 'common'),
(21, 'common', 'sys', 'system'),
(22, 'common', 'sys', 'email'),
(23, 'common', 'sys', 'import'),
(24, 'common', 'sys', 'multilang'),
(25, 'common', 'sys', 'news'),
(26, 'common', 'sys', 'calendar'),
(27, 'common', 'sys', 'banners'),
(28, 'common', 'sys', 'content'),
(29, 'common', 'sys', 'documents'),
(30, 'common', 'sys', 'categories'),
(31, 'common', 'sys', 'forms'),
(32, 'common', 'sys', 'backup'),
(33, 'common', 'sys', 'common'),
(34, 'common', 'sys', 'install'),
(35, 'common', 'sys', 'registration'),
(36, 'common', 'sys', 'security'),
(37, 'common', 'sys', 'actionLogs'),
(38, 'common', 'sys', 'affiliates'),
(39, 'common', 'sys', 'modules'),
(40, 'common', 'sys', 'import'),
(41, 'common', 'sys', 'newsletters'),
(42, 'common', 'sys', 'segmentation'),
(43, 'common', 'sys', 'surveys'),
(44, 'common', 'sys', 'catalog'),
(45, 'common', 'sys', 'orders'),
(46, 'common', 'sys', 'projects'),
(47, 'common', 'sys', 'objectives'),
(48, 'common', 'sys', 'processes'),
(49, 'common', 'sys', 'indicators'),
(50, 'common', 'sys', 'activities'),
(51, 'common', 'sys', 'milestones'),
(52, 'common', 'sys', 'panel'),
(53, 'common', 'sys', 'regions'),
(54, 'common', 'sys', 'positions'),
(55, 'common', 'sys', 'tenures'),
(56, 'common', 'sys', 'Issues'),
(57, 'common', 'sys', 'Headlines'),
(58, 'common', 'sys', 'Actors'),
(1, 'system', 'sys', 'system'),
(2, 'system', 'sys', 'parameters'),
(3, 'system', 'sys', 'debugMode'),
(4, 'system', 'sys', 'developmentMode'),
(5, 'system', 'sys', 'mailCapture'),
(6, 'system', 'sys', 'underMaintenance'),
(7, 'system', 'sys', 'maintenanceMessage'),
(8, 'system', 'sys', 'affiliateUserLoginUnified'),
(9, 'system', 'sys', 'applicationTimeZoneGMT'),
(10, 'system', 'sys', 'dateFormat'),
(11, 'system', 'sys', 'thousandsSeparator'),
(12, 'system', 'sys', 'decimalSeparator'),
(13, 'system', 'sys', 'numberOfDecimals'),
(14, 'system', 'sys', 'siteName'),
(15, 'system', 'sys', 'siteDescription'),
(16, 'system', 'sys', 'siteShortName'),
(17, 'system', 'sys', 'webmasterMail'),
(18, 'system', 'sys', 'debugMail'),
(19, 'system', 'sys', 'fromEmail'),
(20, 'system', 'sys', 'tablePrefix'),
(21, 'system', 'sys', 'news'),
(22, 'system', 'sys', 'affiliateNews'),
(23, 'system', 'sys', 'errorReporting'),
(24, 'system', 'sys', 'noCheckPermissionActions'),
(25, 'system', 'sys', 'noCheckLoginActions'),
(26, 'system', 'sys', 'rowsPerPage'),
(27, 'system', 'sys', 'language'),
(28, 'system', 'sys', 'fileBrowser'),
(29, 'system', 'sys', 'directories'),
(30, 'system', 'sys', 'dir_1'),
(31, 'system', 'sys', 'title'),
(32, 'system', 'sys', 'path'),
(33, 'system', 'sys', 'dir_2'),
(34, 'system', 'sys', 'dir_3'),
(59, 'common', 'esp', 'Servicios'),
(59, 'common', 'sys', 'Services'),
(1, 'affiliates', 'esp', 'Proveedores'),
(2, 'affiliates', 'esp', 'Usuarios de Proveedores'),
(3, 'affiliates', 'esp', 'Proveedor'),
(4, 'affiliates', 'esp', 'Sucursal'),
(5, 'affiliates', 'esp', 'Sucursales'),
(6, 'affiliates', 'esp', 'Usuario Administrador'),
(7, 'affiliates', 'esp', 'contratistas'),
(8, 'affiliates', 'esp', 'contratista'),
(9, 'affiliates', 'esp', 'sucursal'),
(10, 'affiliates', 'esp', 'sucursales'),
(2, 'affiliates', 'sys', 'Affiliate Users'),
(1, 'affiliates', 'sys', 'Affiliates'),
(3, 'affiliates', 'sys', 'Affiliate'),
(4, 'affiliates', 'sys', 'Branch'),
(5, 'affiliates', 'sys', 'Branches'),
(6, 'affiliates', 'sys', 'Owner');

-- --------------------------------------------------------

--
-- Table structure for table `propel_migration`
--

CREATE TABLE IF NOT EXISTS `propel_migration` (
  `version` int(11) default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `propel_migration`
--

INSERT INTO `propel_migration` (`version`) VALUES
(1347372792);

-- --------------------------------------------------------

--
-- Table structure for table `security_action`
--

CREATE TABLE IF NOT EXISTS `security_action` (
  `action` varchar(100) NOT NULL COMMENT 'Action pagina',
  `module` varchar(100) default NULL COMMENT 'Modulo',
  `section` varchar(100) default NULL COMMENT 'Seccion',
  `access` int(11) default NULL COMMENT 'El acceso a ese action',
  `accessAffiliateUser` int(11) default NULL COMMENT 'El acceso a ese action para los usuarios por afiliados',
  `accessRegistrationUser` int(11) default NULL COMMENT 'El acceso a ese action para los usuarios por registracion',
  `accessClientUser` int(11) default NULL COMMENT 'El acceso a ese action para los usuarios por cliente',
  `active` int(11) default NULL COMMENT 'Si el action esta activo o no',
  `pair` varchar(100) default NULL COMMENT 'Par del Action',
  `noCheckLogin` tinyint(1) default '0' COMMENT 'Si no se chequea login ese action',
  PRIMARY KEY  (`action`),
  KEY `security_action_FI_1` (`module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Actions del sistema';

--
-- Dumping data for table `security_action`
--

INSERT INTO `security_action` (`action`, `module`, `section`, `access`, `accessAffiliateUser`, `accessRegistrationUser`, `accessClientUser`, `active`, `pair`, `noCheckLogin`) VALUES
('commonMenuItemsShow', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonSchedulesSubscriptionsDoAddUserX', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonMenuItemsGetActionInfoX', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonAlertsSubscriptionsDoDeleteUserX', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonAlertsSubscriptionsDoAddUserX', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonAlertsSubscriptionsList', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonNestedSetDoOrderByParentX', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonInternalMailsDoMarkAsReadX', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonInternalMailsViewX', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonAlertsSubscriptionsDoDelete', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonNestedSetOrderByParent', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonSendSchedules', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonWelcome', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonInternalMailsDoDeleteX', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonInternalMailsView', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonInternalMailsList', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonSchedulesSubscriptionsDoDelete', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonAlertsSubscriptionsGetEntityFields', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonGenerateJs', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonSendAlerts', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonSchedulesSubscriptionsList', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonSchedulesSubscriptionsGetEntityFields', 'common', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('commonAlertsSubscriptionsEdit', 'common', '', 1073741823, 1073741823, 0, NULL, 1, 'commonAlertsSubscriptionsDoEdit', 0),
('commonSchedulesSubscriptionsEdit', 'common', '', 1073741823, 1073741823, 0, NULL, 1, 'commonSchedulesSubscriptionsDoEdit', 0),
('commonImage', 'common', '', 0, 0, 0, NULL, 1, '', 1),
('commonPasswordDoRecover', 'common', '', 0, 0, 0, NULL, 1, '', 1),
('commonTemplatePublic', 'common', '', 0, 0, 0, NULL, 1, '', 1),
('commonSetLanguage', 'common', '', 0, 0, 0, NULL, 1, '', 1),
('commonJs', 'common', '', 0, 0, 0, NULL, 1, '', 1),
('commonPasswordRecovery', 'common', '', 0, 0, 0, NULL, 1, '', 1),
('commonMaintenance', 'common', '', 0, 0, 0, NULL, 1, '', 1),
('commonIndex', 'common', '', 0, 0, 0, NULL, 1, '', 1),
('commonPasswordDoSetFromRecovery', 'common', '', 0, 0, 0, NULL, 1, '', 1),
('js', 'common', '', 0, 0, 0, NULL, 1, '', 1),
('commonDoLogout', 'common', '', 0, 0, 0, NULL, 1, '', 1),
('commonPasswordRecoveryDoRequest', 'common', '', 0, 0, 0, NULL, 1, '', 1),
('commonCaptchaGeneration', 'common', '', 0, 0, 0, NULL, 1, '', 1),
('commonLogin', 'common', '', 0, 0, 0, NULL, 1, 'commonDoLogin', 1),
('vialidadMeasurementRecordsDoAddCommentX', 'vialidad', '', 7, 1073741823, 0, NULL, 1, '', 0),
('vialidadContractsViewX', 'vialidad', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('vialidadSuppliersViewX', 'vialidad', '', 1073741823, 0, 0, NULL, 1, '', 0),
('vialidadMeasurementRecordRelationsDoDeleteDocument', 'vialidad', '', 7, 1073741823, 0, NULL, 1, '', 0),
('vialidadSuppliersList', 'vialidad', '', 1073741823, 0, 0, NULL, 1, '', 0),
('vialidadSuppliersDoDelete', 'vialidad', '', 7, 0, 0, NULL, 1, '', 0),
('vialidadCertificatesViewGraphXml', 'vialidad', '', 1073741823, 0, 0, NULL, 1, '', 0),
('vialidadMeasurementRecordRelationsDoAddDocument', 'vialidad', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('vialidadMeasurementRecordRelationsEditFieldX', 'vialidad', '', 7, 1073741823, 0, NULL, 1, '', 0),
('vialidadBulletinDoDelete', 'vialidad', '', 3, 0, 0, NULL, 1, '', 0),
('vialidadMeasurementRecordsList', 'vialidad', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('vialidadCertificatesViewGraph', 'vialidad', '', 1073741823, 0, 0, NULL, 1, '', 0),
('vialidadConstructionItemList', 'vialidad', '', 7, 1073741823, 0, NULL, 1, '', 0),
('vialidadSupplyPriceDoAddDocument', 'vialidad', '', 7, 0, 0, NULL, 1, '', 0),
('vialidadContractsList', 'vialidad', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('vialidadConstructionItemRelationDoEditFieldX', 'vialidad', '', 7, 0, 0, NULL, 1, '', 0),
('vialidadSupplyPriceEdit', 'vialidad', '', 7, 0, 0, NULL, 1, '', 0),
('vialidadSupplyList', 'vialidad', '', 1073741823, 0, 0, NULL, 1, '', 0),
('vialidadConstructionsViewX', 'vialidad', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('vialidadSupplyPriceEditFieldX', 'vialidad', '', 7, 0, 0, NULL, 1, '', 0),
('vialidadConstructionItemDoAddRelationX', 'vialidad', '', 7, 0, 0, NULL, 1, '', 0),
('vialidadConstructionItemDoRemoveRelationX', 'vialidad', '', 7, 0, 0, NULL, 1, '', 0),
('vialidadBulletinList', 'vialidad', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('vialidadCertificatesList', 'vialidad', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('vialidadConstructionsList', 'vialidad', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('vialidadSupplyPriceDoDeleteDocument', 'vialidad', '', 7, 0, 0, NULL, 1, '', 0),
('vialidadSupplyPriceEditModifiedPrice', 'vialidad', '', 7, 0, 0, NULL, 1, '', 0),
('vialidadConstructionsAddItemFromOtherX', 'vialidad', '', 7, 0, 0, NULL, 1, '', 0),
('vialidadConstructionItemEdit', 'vialidad', '', 7, 0, 0, NULL, 1, '', 0),
('vialidadBulletinEdit', 'vialidad', '', 7, 0, 0, NULL, 1, '', 0),
('vialidadContractsEdit', 'vialidad', '', 7, 0, 0, NULL, 1, '', 0),
('vialidadConstructionsEdit', 'vialidad', '', 7, 0, 0, NULL, 1, '', 0),
('vialidadMeasurementRecordsEdit', 'vialidad', '', 7, 0, 0, NULL, 1, '', 0),
('vialidadSuppliersEdit', 'vialidad', '', 7, 0, 0, NULL, 1, '', 0),
('vialidadCertificatesEdit', 'vialidad', '', 7, 0, 0, NULL, 1, '', 0),
('vialidadConstructionsAutocompleteListX', 'vialidad', '', 0, 0, 0, NULL, 1, '', 1),
('vialidadCertificatesGetTotalPriceX', 'vialidad', '', 0, 0, 0, NULL, 1, '', 1),
('vialidadContractsAutocompleteListX', 'vialidad', '', 0, 0, 0, NULL, 1, '', 1),
('vialidadSuppliersAutocompleteListX', 'vialidad', '', 0, 0, 0, NULL, 1, '', 1),
('vialidadMeasurementRecordsAutocompleteListX', 'vialidad', '', 0, 0, 0, NULL, 1, '', 1),
('vialidadSupplyAutocompleteListX', 'vialidad', '', 0, 0, 0, NULL, 1, '', 1),
('vialidadSupplyPriceCalculateAveragePriceX', 'vialidad', '', 0, 0, 0, NULL, 1, '', 1),
('vialidadMeasurementRecordRelationsGetTotalPriceX', 'vialidad', '', 0, 0, 0, NULL, 1, '', 1),
('vialidadConstructionItemAutocompleteListX', 'vialidad', '', 0, 0, 0, NULL, 1, '', 1),
('affiliatesUsersAutocompleteListX', 'affiliates', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('affiliatesUsersList', 'affiliates', '', 7, 1073741823, 0, NULL, 1, '', 0),
('affiliatesUsersValidationUsernameX', 'affiliates', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('affiliatesUsersWelcome', 'affiliates', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('affiliatesViewX', 'affiliates', '', 1073741823, 1073741823, 0, NULL, 1, '', 0),
('affiliatesUsersPasswordChange', 'affiliates', '', 7, 0, 0, NULL, 1, 'affiliatesUsersPasswordDoChange', 0),
('affiliatesUsersDoLogout', 'affiliates', '', 0, 0, 0, NULL, 1, '', 1),
('affiliatesUsersPasswordDoRecover', 'affiliates', '', 0, 0, 0, NULL, 1, '', 1),
('affiliatesUsersPasswordDoSetFromRecovery', 'affiliates', '', 0, 0, 0, NULL, 1, '', 1),
('affiliatesUsersPasswordRecovery', 'affiliates', '', 0, 0, 0, NULL, 1, '', 1),
('affiliatesUsersPasswordRecoveryDoRequest', 'affiliates', '', 0, 0, 0, NULL, 1, '', 1),
('affiliatesUsersLogin', 'affiliates', '', 0, 0, 0, NULL, 1, 'affiliatesUsersDoLogin', 1),
('securityNoPermission', 'security', '', 0, 0, 0, NULL, 1, '', 1),
('usersValidationPasswordX', 'users', '', 1073741823, 0, 0, NULL, 1, '', 0),
('usersValidationUsernameX', 'users', '', 1073741823, 0, 0, NULL, 1, '', 0),
('usersWelcome', 'users', '', 1073741823, 0, 0, NULL, 1, '', 0),
('usersPasswordChange', 'users', '', 1073741823, 0, 0, NULL, 1, '', 0),
('usersLoginMaintenance', 'users', '', 0, 0, 0, NULL, 1, '', 1),
('usersDoLogout', 'users', '', 0, 0, 0, NULL, 1, '', 1),
('usersPasswordDoRecover', 'users', '', 0, 0, 0, NULL, 1, '', 1),
('usersPasswordDoChangeForRecovery', 'users', '', 0, 0, 0, NULL, 1, '', 1),
('usersAutocompleteListX', 'users', '', 0, 0, 0, NULL, 1, '', 1),
('usersPasswordRecoveryDoRequest', 'users', '', 0, 0, 0, NULL, 1, '', 1),
('usersPasswordRecovery', 'users', '', 0, 0, 0, NULL, 1, '', 1),
('usersPasswordRecoveryConfirmation', 'users', '', 0, 0, 0, NULL, 1, '', 1),
('usersLogin', 'users', '', 0, 0, 0, NULL, 1, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `security_actionLabel`
--

CREATE TABLE IF NOT EXISTS `security_actionLabel` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id label security',
  `action` varchar(100) NOT NULL COMMENT 'Action pagina',
  `language` varchar(100) default NULL COMMENT 'Idioma de la etiqueta',
  `label` varchar(100) default NULL COMMENT 'Etiqueta',
  `description` varchar(255) default NULL COMMENT 'Descripcion',
  PRIMARY KEY  (`id`,`action`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='etiquetas de actions de seguridad' AUTO_INCREMENT=547 ;

--
-- Dumping data for table `security_actionLabel`
--

INSERT INTO `security_actionLabel` (`id`, `action`, `language`, `label`, `description`) VALUES
(49, 'Js', 'esp', 'Entregar archivos de javascript', 'Entregar archivos de javascript'),
(98, 'Js', 'esp', 'Entregar archivos de javascript', 'Entregar archivos de javascript'),
(99, 'CommonActionLogsPurge', 'esp', 'Eliminar registros históricos', 'Eliminar registros históricos'),
(100, 'CommonAlertsSubscriptionsEdit', 'esp', 'Editar suscripción de alertas', 'Editar suscripción de alertas'),
(101, 'CommonConfigEdit', 'esp', 'Modificar estructura de configuración', 'Modificar estructura de configuración'),
(102, 'CommonConfigSet', 'esp', 'Modificar valores de configuración', 'Modificar valores de configuración'),
(103, 'CommonLogin', 'esp', 'Ingreso de usuarios al sistema', 'Ingreso de usuarios al sistema'),
(104, 'CommonInternalMailsEdit', 'esp', 'Editar correos internos', 'Editar correos internos'),
(105, 'CommonMenuItemsEdit', 'esp', 'Editar elementos del menú', 'Editar elementos del menú'),
(106, 'CommonPasswordRecovery', 'esp', 'Recuper contraseña', 'Recuper contraseña'),
(107, 'CommonSchedulesSubscriptionsEdit', 'esp', 'Editar suscripción programada', 'Editar suscripción programada'),
(108, 'CommonActionLogsList', 'esp', 'Ver listado de histórico de operaciones', 'Ver listado de histórico de operaciones'),
(109, 'CommonAlertsSubscriptionsDoAddUserX', 'esp', 'Agregar usuario a suscripción de alerta', 'Agregar usuario a suscripción de alerta'),
(110, 'CommonAlertsSubscriptionsDoDelete', 'esp', 'Eliminar suscripción de alerta', 'Eliminar suscripción de alerta'),
(111, 'CommonAlertsSubscriptionsDoDeleteUserX', 'esp', 'Eliminar usuario de suscripción de alerta', ''),
(112, 'CommonAlertsSubscriptionsGetEntityFields', 'esp', 'Obtener campos para fijar alertas', ''),
(113, 'CommonAlertsSubscriptionsList', 'esp', 'Lista de suscripciones de alertas disponibles', 'Lista de suscripciones de alertas disponibles'),
(114, 'CommonCaptchaGeneration', 'esp', 'Generar imagen de seguridad', 'Generar imagen de seguridad'),
(115, 'CommonConfigView', 'esp', 'Ver valores de configuración', 'Ver valores de configuración'),
(116, 'CommonDoLogout', 'esp', 'Salida dle sistema', 'Salida dle sistema'),
(117, 'CommonGenerateJs', 'esp', 'Generar archivo JavaScript', 'Generar archivo JavaScript'),
(118, 'CommonIndex', 'esp', 'Redireccionamiento al indice', 'Redireccionamiento al indice'),
(119, 'CommonInternalMailsDoDeleteX', 'esp', 'Eliminar correo interno', 'Eliminar correo interno'),
(120, 'CommonInternalMailsDoMarkAsReadX', 'esp', 'Marcar mail interno como leido', 'Marcar mail interno como leido'),
(121, 'CommonInternalMailsList', 'esp', 'Lista de mensajes de correo internos', 'Lista de mensajes de correo internos'),
(122, 'CommonInternalMailsView', 'esp', 'Ver mensaje de correo interno', 'Ver mensaje de correo interno'),
(123, 'CommonInternalMailsViewX', 'esp', 'Ver mensaje de correo interno', 'Ver mensaje de correo interno'),
(124, 'CommonJs', 'esp', 'Genera archivo de JavaScript', 'Genera archivo de JavaScript'),
(125, 'CommonMaintenance', 'esp', 'Redireccionamiento de Sistema en Mantenimiento', 'Redireccionamiento de Sistema en Mantenimiento'),
(126, 'CommonMenuItemsActionsAutocompleteListX', 'esp', 'Ayuda para autocompletar con acciones existentes', 'Ayuda para autocompletar con acciones existentes'),
(127, 'CommonMenuItemsDoDeleteX', 'esp', 'Eliminar item del menú', 'Eliminar item del menú'),
(128, 'CommonMenuItemsDoEditOrderX', 'esp', 'Cambiar el orden de items del menú', 'Cambiar el orden de items del menú'),
(129, 'CommonMenuItemsGetActionInfoX', 'esp', 'Obtener información para generación de menu', 'Obtener información para generación de menu'),
(130, 'CommonMenuItemsList', 'esp', 'Listado de elementos dle menu', 'Listado de elementos dle menu'),
(131, 'CommonMenuItemsShow', 'esp', 'Mostrar menu', 'Mostrar menu'),
(132, 'CommonNestedSetDoOrderByParentX', 'esp', 'Ordenar por padre', ''),
(133, 'CommonNestedSetOrderByParent', 'esp', 'Ordenar por padre', ''),
(134, 'CommonPasswordDoChangeForRecovery', 'esp', 'Cambiar contraseña desde recuperación', 'Cambiar contraseña desde recuperación'),
(135, 'CommonPasswordRecoveryConfirmation', 'esp', 'Confirmarrecuperación de contraseña', 'Confirmarrecuperación de contraseña'),
(136, 'CommonPasswordRecoverySendConfirmationRequest', 'esp', 'Enviar confirmación de recuperaciónd e contraseña', 'Enviar confirmación de recuperaciónd e contraseña'),
(137, 'CommonSchedulesSubscriptionsDoAddUserX', 'esp', 'Agregar usuario a suscripción', ''),
(138, 'CommonSchedulesSubscriptionsDoDelete', 'esp', 'Eliminar suscripción', ''),
(139, 'CommonSchedulesSubscriptionsDoDeleteUserX', 'esp', 'Eliminar usuario de suscripción', ''),
(140, 'CommonSchedulesSubscriptionsGetEntityFields', 'esp', 'Obtener campos para suscripción de agenda', ''),
(141, 'CommonSchedulesSubscriptionsList', 'esp', 'Listar alertas de suscripción', ''),
(142, 'CommonSendAlerts', 'esp', 'Envío de alertas', ''),
(143, 'CommonSendSchedules', 'esp', 'Envia vencimientos', ''),
(144, 'CommonSetLanguage', 'esp', 'Condifura el idioma de la aplicación', 'Condifura el idioma de la aplicación'),
(145, 'CommonTemplatePublic', 'esp', 'Muestra un external público', 'Muestra un external público'),
(146, 'CommonWelcome', 'esp', 'Acción de bienvenida del usuario', 'Acción de bienvenida del usuario'),
(147, 'Js', 'esp', 'Entregar archivos de javascript', 'Entregar archivos de javascript'),
(274, 'VialidadConstructionItemEdit', 'esp', 'Editar un item de construcción', 'Permite crear/modificar un item de una construcción'),
(275, 'VialidadBulletinEdit', 'esp', 'Editar Boletín de Precios', 'Edición de los boletines mensuales de precios'),
(276, 'VialidadContractsEdit', 'esp', 'Editar contratos', 'Edición de contratos '),
(277, 'VialidadConstructionsEdit', 'esp', 'Editar Obras', 'Edición de obras de construcción'),
(278, 'VialidadMeasurementRecordsEdit', 'esp', 'Editar Acta de Medición', 'Permite crear/modificar un acta de medición'),
(279, 'VialidadSuppliersEdit', 'esp', 'Editar Proveedores', 'Edición de proveedores de precios del boletín'),
(280, 'VialidadCertificatesEdit', 'esp', 'Editar Certificado', 'Permite editar/modificar un Certificado'),
(281, 'VialidadSupplyDoEditX', 'esp', 'Editar nombre de insumo', 'Edita el nombre de insumo'),
(282, 'VialidadCertificatesDoDelete', 'esp', 'Eliminar certificado', 'Elimina un certificado'),
(283, 'VialidadMeasurementRecordsDoAddCommentX', 'esp', 'Agrega comentarios al acta de medición', 'Agrega comentarios al acta de medición'),
(284, 'VialidadContractsViewX', 'esp', 'Ver Contrato', 'Muestra los datos del contrato'),
(285, 'VialidadSuppliersViewX', 'esp', 'Ver Proveedor', 'Muestra los datos del proveedor'),
(286, 'VialidadMeasurementRecordRelationsDoDeleteDocument', 'esp', 'Elimina documentos respaldatorios de un acta de medición', 'Elimina  documentos respaldatorios de un acta de medición'),
(287, 'VialidadConstructionsAutocompleteListX', 'esp', 'Listado para autocompletar obras', 'Listado de autocompletar obras'),
(288, 'VialidadSuppliersList', 'esp', 'Listado de Proveedores', 'Muestra el listado de proveedores '),
(289, 'VialidadSuppliersDoDelete', 'esp', 'Eliminar Proveedor', 'Eliminar Proveedor de Precios para el Boletín'),
(290, 'VialidadCertificatesViewGraphXml', 'esp', 'Ver graficos de ejecucion por certificados de obra', 'Ver graficos de ejecucion por certificados de obra'),
(291, 'VialidadMeasurementRecordRelationsDoAddDocument', 'esp', 'Agrega un documento respaldatorio para un acta de medición', 'Agrega un documento respaldatorio para un acta de medición'),
(292, 'VialidadMeasurementRecordRelationsEditFieldX', 'esp', 'Modifica un valor de un acta de medición', 'Modifica un valor de un acta de medición'),
(293, 'VialidadBulletinDoDelete', 'esp', 'Eliminar boletín', 'Eliminar boletín de precios'),
(294, 'VialidadMeasurementRecordsList', 'esp', 'Ver actas de medición', 'Muestra el listado de actas de medición'),
(295, 'VialidadMeasurementRecordsDoDelete', 'esp', 'Eliminar acta de medición', 'Elimina acta de medición'),
(296, 'VialidadConstructionItemDoDelete', 'esp', 'Eliminar item de construcción', 'Elimina item de construcción'),
(297, 'VialidadSupplyEditFieldX', 'esp', 'Modificar nombre de insumo', 'Edición de nombres de insumos'),
(298, 'VialidadConstructionsDoDelete', 'esp', 'Eliminar Obra', 'Eliminar Obra de Construcción'),
(299, 'VialidadCertificatesViewGraph', 'esp', 'Ver grafico de certificados', 'Mistra gráfico de ejecución por certificados'),
(300, 'VialidadCertificatesGetTotalPriceX', 'esp', 'Generar le valor total del certificado', 'Genera le valor total del certificado'),
(301, 'VialidadConstructionItemList', 'esp', 'Ver items de construcción', 'Listado de items de construcción'),
(302, 'VialidadSupplyPriceDoAddDocument', 'esp', 'Agregar documento respalatorio a un precio de suministro', 'Agrega documento respalatorio a un precio de suministro'),
(303, 'VialidadContractsList', 'esp', 'Listado de Contratos', 'Muestra el listado de contrados'),
(304, 'VialidadConstructionItemRelationDoEditFieldX', 'esp', 'Modificar los valores de componentes de un item', 'Modifica los valores de componentes de un item'),
(305, 'VialidadContractsAutocompleteListX', 'esp', 'Listar contratos para autocompletar', 'Listado de contratos para autocompletar'),
(306, 'VialidadSuppliersAutocompleteListX', 'esp', 'Autocompletar proveedores', 'Mostrar listado de proveedores'),
(307, 'VialidadSupplyPriceEdit', 'esp', 'Modificar el precio de proveedor para un boletín', 'Modifica el precio de proveedor para un boletín'),
(308, 'VialidadSupplyList', 'esp', 'Listado de Insumos', 'Muestra el listado de Insumos'),
(309, 'VialidadConstructionsViewX', 'esp', 'Ver Obras', 'Mostrar datos de obra de construcción'),
(310, 'VialidadMeasurementRecordsAutocompleteListX', 'esp', 'Listar actas de medición para autocompletar', 'Muestra el listado de actas de medición para autocompletar'),
(311, 'VialidadSupplyAutocompleteListX', 'esp', 'Autocompletar Insumos', 'Muestra el listado de Insumos'),
(312, 'VialidadContractsDoDelete', 'esp', 'Edliminar Contratos', 'Elimina el registro de contrato'),
(313, 'VialidadSupplyDoDelete', 'esp', 'Eliminar Insumo', 'Elimina un insumo'),
(314, 'VialidadSupplyPriceEditFieldX', 'esp', 'Modificación de precios de insumo', 'Modifica precios de insumo'),
(315, 'VialidadConstructionItemDoAddRelationX', 'esp', 'Agregar nuevo insumo a item de construcción', 'Agrega nuevo insumo a item de construcción'),
(316, 'VialidadConstructionItemDoRemoveRelationX', 'esp', 'Eliminar insumo a item de construcción', 'Elimina insumo a item de construcción'),
(317, 'VialidadBulletinList', 'esp', 'Listado de Boletines', 'Muestra el listado de Boletines de Precios'),
(318, 'VialidadCertificatesList', 'esp', 'Listar certificados', 'Muestra el listado de certificados'),
(319, 'VialidadSupplyPriceCalculateAveragePriceX', 'esp', 'Calcular precio promedio de suministro', 'Calcula precio promedio de suministro'),
(320, 'VialidadConstructionsList', 'esp', 'Listado de Obras de Construcción', 'Muestra el listado de obras de construcción'),
(321, 'VialidadSupplyPriceDoDeleteDocument', 'esp', 'Eliminar documento respaldatorio de precio', 'Elimina documento respaldatorio de precio'),
(322, 'VialidadMeasurementRecordRelationsGetTotalPriceX', 'esp', 'Obtener total de acta de medición', 'Obtiene el total de un acta de medición'),
(323, 'VialidadSupplyPriceEditModifiedPrice', 'esp', 'Modificar precio de boletín', 'Modifica precio del boletín'),
(324, 'VialidadConstructionsAddItemFromOtherX', 'esp', 'Copiar items de de una obra a otra', 'Copia items de una obra a otra'),
(325, 'VialidadConstructionItemAutocompleteListX', 'esp', 'Listar items de construcción para autocompletar', 'listado de items de construcción para autocompletar'),
(326, 'AffiliatesEdit', 'esp', 'Editar Empresa', 'Modifica la información de la empresa asociada'),
(327, 'AffiliatesUsersPasswordChange', 'esp', 'Modificar contraseña de usuario', 'Modifica la contraseña de usuario'),
(328, 'AffiliatesUsersLogin', 'esp', 'Ingresar al sistema', 'Ingresa al sistema'),
(329, 'AffiliatesUsersGroupsEdit', 'esp', 'Modificar grupos de usuarios', 'Modifica grupos de usuarios'),
(330, 'AffiliatesVerifiersEdit', 'esp', 'Edición de Verificadoras', 'Edita la ifnromación de las empresas verificadoras'),
(331, 'AffiliatesUsersEdit', 'esp', 'Editar usuarios de empresas asociadas', 'Edita usuarios de empresas asociadas'),
(332, 'AffiliatesBranchesEdit', 'esp', 'Editar oficinas de empresas asociadas', 'Edita oficinas de empresas asociadas'),
(333, 'AffiliatesUsersLevelsEdit', 'esp', 'Editar niveles de usuarios de empresas asociadas', 'Edita niveles de usuarios de empresas asociadas'),
(334, 'AffiliatesContractorsEdit', 'esp', 'Editar información de Contratistas', 'Edita información de Contratistas'),
(335, 'AffiliatesDoDelete', 'esp', 'Elimina empresa asociada', ''),
(336, 'AffiliatesUsersGroupsDoAddCategory', 'esp', 'Agregar categorías a grupos de usuarios', 'Agrega categorías a grupos de usuarios'),
(337, 'AffiliatesUsersPasswordRecoveryDoRequest', 'esp', 'Solicitar recuperación de contraseña', 'Solicita recuperación de contraseña'),
(338, 'AffiliatesUsersPasswordDoRecover', 'esp', '', ''),
(339, 'AffiliatesUsersAutocompleteListX', 'esp', '', ''),
(340, 'AffiliatesBranchesDoDelete', 'esp', '', ''),
(341, 'AffiliatesViewX', 'esp', '', ''),
(342, 'AffiliatesVerifiersViewX', 'esp', '', ''),
(343, 'AffiliatesUsersPasswordDoSetFromRecovery', 'esp', '', ''),
(344, 'AffiliatesUsersList', 'esp', '', ''),
(345, 'AffiliatesUsersGroupsDoRemCategory', 'esp', '', ''),
(346, 'AffiliatesUsersLevelsList', 'esp', '', ''),
(347, 'AffiliatesUsersDoLogout', 'esp', '', ''),
(348, 'AffiliatesUsersGroupsList', 'esp', '', ''),
(349, 'AffiliatesUsersPasswordRecovery', 'esp', '', ''),
(350, 'AffiliatesDoSetOwner', 'esp', '', ''),
(351, 'AffiliatesContractorsList', 'esp', '', ''),
(352, 'AffiliatesList', 'esp', '', ''),
(353, 'AffiliatesUsersValidationUsernameX', 'esp', '', ''),
(354, 'AffiliatesContractorsViewX', 'esp', '', ''),
(355, 'AffiliatesUsersDoActivate', 'esp', '', ''),
(356, 'AffiliatesUsersDoAddToGroup', 'esp', '', ''),
(357, 'AffiliatesVerifiersList', 'esp', '', ''),
(358, 'AffiliatesUsersLevelsDoDelete', 'esp', '', ''),
(359, 'AffiliatesUsersDoDelete', 'esp', '', ''),
(360, 'AffiliatesContractorsAutocompleteListX', 'esp', '', ''),
(361, 'AffiliatesUsersWelcome', 'esp', '', ''),
(362, 'AffiliatesUsersPasswordResetX', 'esp', '', ''),
(363, 'AffiliatesUsersDoRemoveFromGroup', 'esp', '', ''),
(364, 'AffiliatesUsersGroupsDoDelete', 'esp', '', ''),
(365, 'AffiliatesVerifiersAutocompleteListX', 'esp', '', ''),
(366, 'AffiliatesBranchesList', 'esp', '', ''),
(373, 'BackupDelete', 'esp', 'Eliminar respaldo', 'Elimina respaldo guardado en el servidor'),
(374, 'BackupRestore', 'esp', 'Restaurar respaldo', 'Restaura la información guardada en un archivo de respaldo'),
(375, 'BackupDownload', 'esp', 'Descargar archivo de respaldo', 'Descarga archivo de respaldo a equipo local'),
(376, 'BackupSendByEmail', 'esp', 'Enviar respaldo por mail', 'Enviar archivo de respaldo por correo electrónico'),
(377, 'BackupCreate', 'esp', 'Crear respaldo en servidor', 'Crea archivo de respaldo en servidor'),
(378, 'BackupList', 'esp', 'Listado de respaldos disponibles', 'Muestra el listado de respaldos disponibles en el servidor'),
(380, 'NoPermission', 'esp', 'No se tiene permiso sobre la acción solicitada', 'No se tiene permiso sobre la acción solicitada'),
(381, 'SecurityEditPermissions', 'esp', 'Modificar permisos de usuarios', 'Modifica permisos de usuarios'),
(382, 'SecurityNoPermission', 'esp', 'Notificación de falta de permisos para la acción solicitada', 'Notifica al usuario que no tiene permisos sobre la acción solicitada'),
(514, 'UsersLogin', 'esp', 'Ingresar al sistema', 'Ingreso al sistema'),
(515, 'UsersEdit', 'esp', 'Modificar Información del Usuario', 'Modifica Información del Usuario'),
(516, 'UsersPasswordChange', 'esp', 'Modificar contraseña', 'Modificación de contraseña'),
(517, 'UsersDoLinkToSupplier', 'esp', 'Enlazar usuario a proveedor', 'Asocia usuario a proveedor'),
(518, 'UsersEditInfo', 'esp', 'Modificar Información del Usuario', 'Modifica Información del Usuario'),
(519, 'UsersDoDeleteFromGroupX', 'esp', 'Eliminar usuario de grupo', 'Elimina usuario de grupo'),
(520, 'UsersDoEditInfoX', 'esp', 'Editar información de Usuario', 'Edita información de Usuario'),
(521, 'UsersLoginMaintenance', 'esp', 'Ingresar al sistema en mantenimiento', 'Ingreso al sistema en mantenimiento'),
(522, 'UsersLevelsDoDelete', 'esp', 'Eliminar nivel de usuario', 'Elimina nivel de usuario'),
(523, 'UsersGroupsDoAddCategoryToGroup', 'esp', 'Agregar categoría a grupo', 'Agrega categoría a grupo'),
(524, 'UsersDoLogout', 'esp', 'Salir del sistema', 'Salida del sistema'),
(525, 'UsersLevelsDoEdit', 'esp', 'Editar nivel de usuario', 'Edita nivel de usuario'),
(526, 'UsersDoAddToGroupX', 'esp', 'Agregar usuario a grupo', 'Agrega usuario a grupo'),
(527, 'UsersPasswordDoRecover', 'esp', 'Recuperar contraseña de usuario', 'Recupera contraseña de usuario'),
(528, 'UsersGroupsDoEdit', 'esp', 'Editar grupo de usuarios', 'Edita grupo de usuarios'),
(529, 'UsersLevelsList', 'esp', 'Listar niveles de usuario', 'Listado de niveles de usuario'),
(530, 'UsersDoRemoveFromGroup', 'esp', 'Elimiminar un usuario de un grupo', 'Elimimina un usuario de un grupo'),
(531, 'UsersList', 'esp', 'Listar usuarios', 'Lista de usuarios'),
(532, 'UsersGroupsDoDelete', 'esp', 'Eliminar grupo', 'Elimina grupo'),
(533, 'UsersDoDelete', 'esp', 'Eliminar usuario', 'Elimina usuario'),
(534, 'UsersDoActivateX', 'esp', 'Activar usuario', 'Activa usuario'),
(535, 'UsersValidationPasswordX', 'esp', 'Verificar contraseña actual para su modificación', 'Verifica contraseña actual para su modificación'),
(536, 'UsersValidationUsernameX', 'esp', 'Verificar validez/disponibilidad de nombre de usuario', 'Verifica validez/disponibilidad de nombre de usuario'),
(537, 'UsersPasswordDoChangeForRecovery', 'esp', 'Cambiar contraseña recuperada', 'Cambia contraseña recuperada'),
(538, 'UsersPasswordResetX', 'esp', 'Resetear contraseña de usuarios', 'Resetea contraseña de usuarios'),
(539, 'UsersGroupsList', 'esp', 'Listar grupos de usuarios', 'Lista de grupos de usuarios'),
(540, 'UsersDoActivate', 'esp', 'Activar usuario', 'Activación de usuario'),
(541, 'UsersAutocompleteListX', 'esp', 'Autocompletar usuarios', 'Listado para autocompletar usuarios'),
(542, 'UsersWelcome', 'esp', 'Página de bienvenida al usuario', 'Página de bienvenida al usuario'),
(543, 'UsersPasswordRecoveryDoRequest', 'esp', 'Solicitar recuperación contraseña de usuario', 'Solicita recuperación contraseña de usuario'),
(544, 'UsersPasswordRecovery', 'esp', 'Recuperar contraseña de usuario', 'Recupera contraseña de usuario'),
(545, 'UsersGroupsDoRemoveCatFromGroup', 'esp', 'Eliminar categoría de un grupo', 'Elimina categoría de un grupo'),
(546, 'UsersPasswordRecoveryConfirmation', 'esp', 'Confirmar recupero de contraseña', 'Confirma recupero de contraseña');

-- --------------------------------------------------------

--
-- Table structure for table `security_module`
--

CREATE TABLE IF NOT EXISTS `security_module` (
  `module` varchar(100) NOT NULL COMMENT 'Modulo',
  `access` int(11) default NULL COMMENT 'El acceso a ese modulo',
  `accessAffiliateUser` int(11) default NULL COMMENT 'El acceso a ese modulo para los usuarios por afiliados',
  `accessRegistrationUser` int(11) default NULL COMMENT 'El acceso a ese modulo para los usuarios por registracion',
  `accessClientUser` int(11) default NULL COMMENT 'El acceso a ese action para los usuarios por cliente',
  `noCheckLogin` tinyint(1) default '0' COMMENT 'Si no se chequea login ese modulo',
  PRIMARY KEY  (`module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Modulos del sistema';

--
-- Dumping data for table `security_module`
--

INSERT INTO `security_module` (`module`, `access`, `accessAffiliateUser`, `accessRegistrationUser`, `accessClientUser`, `noCheckLogin`) VALUES
('common', 3, 0, 0, NULL, 0),
('vialidad', 3, 0, 0, NULL, 0),
('affiliates', 3, 0, 0, NULL, 0),
('backup', 3, 0, 0, NULL, 0),
('security', 3, 0, 0, NULL, 0),
('users', 3, 0, 0, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users_group`
--

CREATE TABLE IF NOT EXISTS `users_group` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Group ID',
  `name` varchar(255) NOT NULL COMMENT 'Group Name',
  `created` datetime NOT NULL COMMENT 'Creation date for',
  `updated` datetime NOT NULL COMMENT 'Last update date',
  `bitLevel` int(11) default NULL COMMENT 'Nivel',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `users_group_U_1` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Groups' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users_group`
--

INSERT INTO `users_group` (`id`, `name`, `created`, `updated`, `bitLevel`) VALUES
(1, 'supervisor', '2001-01-01 00:00:00', '2001-01-01 00:00:00', NULL),
(2, 'admin', '2001-01-01 00:00:00', '2001-01-01 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_level`
--

CREATE TABLE IF NOT EXISTS `users_level` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Level ID',
  `name` varchar(255) NOT NULL COMMENT 'Level Name',
  `bitLevel` int(11) default NULL COMMENT 'Bit del nivel',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `users_level_U_1` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Levels' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users_level`
--

INSERT INTO `users_level` (`id`, `name`, `bitLevel`) VALUES
(1, 'Supervisor', 1),
(2, 'Administrador', 2),
(3, 'Usuario Administrativo', 4),
(4, 'Usuario', 8);

-- --------------------------------------------------------

--
-- Table structure for table `users_user`
--

CREATE TABLE IF NOT EXISTS `users_user` (
  `id` int(11) NOT NULL auto_increment COMMENT 'User Id',
  `username` varchar(255) NOT NULL COMMENT 'username',
  `password` varchar(255) NOT NULL COMMENT 'password',
  `passwordUpdated` date default NULL COMMENT 'Fecha de actualizacion de la clave',
  `name` varchar(90) default NULL COMMENT 'Nombre',
  `surname` varchar(90) default NULL COMMENT 'Apellido',
  `active` tinyint(1) NOT NULL COMMENT 'Indica si esta activo',
  `levelId` int(4) default NULL COMMENT 'Id del nivel de usuario',
  `lastLogin` datetime default NULL COMMENT 'Fecha del ultimo login del usuario',
  `timezone` varchar(25) default NULL COMMENT 'Timezone GMT del usuario',
  `recoveryHash` varchar(255) default NULL COMMENT 'Hash enviado para la recuperacion de clave',
  `recoveryHashCreatedOn` datetime default NULL COMMENT 'Momento de la solicitud para la recuperacion de clave',
  `mailAddress` varchar(90) default NULL COMMENT 'Direccion electronica',
  `mailAddressAlt` varchar(90) default NULL COMMENT 'Direccion electronica alternativa',
  `deleted_at` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `created` datetime NOT NULL COMMENT 'Fecha de creacion',
  `updated` datetime NOT NULL COMMENT 'Fecha de actualizacion',
  `documentType` int(2) default NULL COMMENT 'Tipo de documento',
  `document` varchar(15) default NULL COMMENT 'Numero de documento',
  `gender` int(1) default NULL COMMENT 'Genero',
  `birthdate` date default NULL COMMENT 'Fecha de nacimiento',
  `session` varchar(90) default NULL COMMENT 'Nombre de la sesion',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `users_user_U_1` (`username`),
  KEY `users_user_FI_1` (`levelId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Users' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users_user`
--

INSERT INTO `users_user` (`id`, `username`, `password`, `passwordUpdated`, `name`, `surname`, `active`, `levelId`, `lastLogin`, `timezone`, `recoveryHash`, `recoveryHashCreatedOn`, `mailAddress`, `mailAddressAlt`, `deleted_at`, `created_at`, `updated_at`, `created`, `updated`, `documentType`, `document`, `gender`, `birthdate`, `session`) VALUES
(-1, 'system', 'e2c09ea5f00d3a54f103dcfaa4dfbb4e', '2001-01-01', 'System', 'System', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL),
(1, 'supervisor', 'd40a4afe38b91cf04bdecc71bf4db659', '2001-01-01', 'Supervisor', 'Supervisor', 1, 1, '2012-10-18 17:34:13', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2012-10-18 17:34:13', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL),
(2, 'admin', '45c48d97153f26e17d101be744368331', '2001-01-01', 'Admin', 'Admin', 1, 2, '2011-12-01 16:13:15', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2011-12-01 16:13:15', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL),
(3, 'gmorell', '2eaa91d409280d8696c274f89179dde4', '2011-11-10', 'Gustavo', 'Morell', 1, 1, '2011-11-18 12:03:21', NULL, NULL, NULL, 'gmorell@mopc.gov.py', NULL, NULL, '2011-11-10 15:59:46', '2011-11-18 12:03:21', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL),
(4, 'dgroisman', 'efe9f8d50aa632efc0b2d3751f98da0d', '2011-12-07', 'David', 'Groisman', 1, 1, NULL, NULL, NULL, NULL, 'davidgroisman@gmail.com', NULL, NULL, '2011-12-07 14:43:41', '2011-12-07 14:43:41', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_userGroup`
--

CREATE TABLE IF NOT EXISTS `users_userGroup` (
  `userId` int(11) NOT NULL COMMENT 'Group ID',
  `groupId` int(11) NOT NULL COMMENT 'Group ID',
  PRIMARY KEY  (`userId`,`groupId`),
  KEY `users_userGroup_FI_2` (`groupId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Users / Groups';

--
-- Dumping data for table `users_userGroup`
--

INSERT INTO `users_userGroup` (`userId`, `groupId`) VALUES
(1, 1),
(1, 2),
(2, 2),
(3, 1),
(3, 2),
(4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_bulletin`
--

CREATE TABLE IF NOT EXISTS `vialidad_bulletin` (
  `id` int(11) NOT NULL auto_increment,
  `number` varchar(10) NOT NULL,
  `bulletinDate` date default NULL COMMENT 'Fecha del Boletin',
  `comments` mediumtext COMMENT 'Observaciones',
  `published` tinyint(1) default NULL COMMENT 'Indica si esta publicado',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `vialidad_bulletin`
--

INSERT INTO `vialidad_bulletin` (`id`, `number`, `bulletinDate`, `comments`, `published`) VALUES
(1, '1', '2011-10-01', 'Nota 1: Todos los materiales son IVA incluido y en el Depto. Central excepto precio en villa Hayes', 1),
(2, '1', '2011-11-09', 'OBSERVACIONES:\r\nObs.1: (P) Preliminar, sujeto a confirmación\r\nObs.2: Indice porcentual para equipos y maquinarias Setiembre de 2010 igual a 131,1 Confirmado por la U. S. Departament of Labor\r\nVALORES BASE PARA LA APLICACIÓN DE LA FORMULA PARAMETRICA DIVISIÓN DE ESTUDIOS ESPECIALES\r\nAPLICABLE A CERTIFICADOS DEL MES DE ENERO DE 2011 BOLETIN Nº 34\r\nObs.3: El precio de la Emulsión asfáltica RR2C con polímero de los meses de Setiembre y Octubre de 2010 quedan pendiente de\r\nconfirmación.\r\nObs.4: El precio de la Emulsión asfáltica RR2C sin polímero del mes de Diciembre de 2010 queda pendiente de confirmación.', 1),
(3, '23', '2011-12-09', NULL, 0),
(4, '24', '2012-01-09', NULL, 0),
(5, '24', '2011-10-19', NULL, 0),
(6, '24', '2012-02-09', NULL, 0),
(7, '24', '2012-03-09', NULL, 0),
(8, '25', '2012-04-09', NULL, 0),
(9, '49', '2012-05-09', NULL, 0),
(10, '49', '2012-06-11', NULL, 1),
(11, '50', '2012-07-11', NULL, 0),
(12, '51', '2012-08-11', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_certificate`
--

CREATE TABLE IF NOT EXISTS `vialidad_certificate` (
  `id` int(11) NOT NULL auto_increment,
  `measurementRecordId` int(11) NOT NULL,
  `totalPrice` decimal(12,2) default NULL COMMENT 'Precio',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `status` int(11) default NULL COMMENT 'Estado del certificado',
  PRIMARY KEY  (`id`),
  KEY `vialidad_certificate_FI_1` (`measurementRecordId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `vialidad_certificate`
--

INSERT INTO `vialidad_certificate` (`id`, `measurementRecordId`, `totalPrice`, `created_at`, `updated_at`, `status`) VALUES
(1, 3, 13004980.00, '2011-12-06 17:45:42', '2012-10-03 18:04:29', NULL),
(2, 7, 5686860.00, '2011-12-06 17:46:25', '2012-10-17 17:12:02', NULL),
(3, 8, 3952500.00, '2011-12-06 17:46:42', '2012-05-18 12:49:20', NULL),
(4, 11, NULL, '2012-01-25 13:18:28', '2012-01-25 13:18:28', NULL),
(5, 12, NULL, '2012-05-18 11:36:09', '2012-05-18 11:36:09', NULL),
(6, 13, 5160.00, '2012-05-18 11:39:29', '2012-05-18 11:39:48', NULL),
(7, 14, 1800.00, '2012-05-18 11:47:29', '2012-05-18 11:47:39', NULL),
(8, 15, NULL, '2012-10-09 11:34:35', '2012-10-09 11:34:35', NULL),
(9, 17, 0.00, '2012-10-09 11:35:18', '2012-10-09 11:35:39', NULL),
(10, 18, NULL, '2012-10-11 17:39:03', '2012-10-11 17:39:03', NULL),
(11, 19, NULL, '2012-10-11 17:40:12', '2012-10-11 17:40:12', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_construction`
--

CREATE TABLE IF NOT EXISTS `vialidad_construction` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `contractId` int(11) default NULL COMMENT 'Id del contrato',
  `description` text,
  `verifierId` int(5) default NULL COMMENT 'Id del verificador',
  `region` varchar(255) default NULL COMMENT 'Departamentos',
  `length` varchar(5) default NULL COMMENT 'Longitud',
  `startDate` date default NULL COMMENT 'Fecha de inicio',
  `typeId` int(5) default NULL COMMENT 'Tipo de Obra',
  `lengthUnit` int(5) default NULL COMMENT 'Unidad de la obra',
  `validationLength` int(5) default NULL COMMENT 'Plazo de la Obra',
  `validationType` int(2) default NULL COMMENT 'Tipo de longitud de la Obra',
  PRIMARY KEY  (`id`),
  KEY `vialidad_construction_FI_1` (`lengthUnit`),
  KEY `vialidad_construction_FI_2` (`contractId`),
  KEY `vialidad_construction_FI_3` (`verifierId`),
  KEY `vialidad_construction_FI_4` (`typeId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `vialidad_construction`
--

INSERT INTO `vialidad_construction` (`id`, `name`, `contractId`, `description`, `verifierId`, `region`, `length`, `startDate`, `typeId`, `lengthUnit`, `validationLength`, `validationType`) VALUES
(1, 'Obra 1', 1, 'Descripción de la obra 1', 2, NULL, '100', NULL, 1, 10, NULL, NULL),
(2, 'Obra 1 para el contrato 1', 1, 'Descripción larga para la Obra 1 para el contrato 1', 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'Costanera', 2, 'Descripción de obra', 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'Ruta Nº12, tramo Ninfa - General Bruguez', 1, 'El tramo se exitende por 53 kilometros, es un tipo de obra terraplenada, con financiamiento local corresondiente el tramo al departamento de presidente Hayes', 4, NULL, '53', '2008-06-01', 2, NULL, NULL, NULL),
(5, 'Camino de acceso al puerto Trociuk', NULL, 'La obra se inicio hace pocas semanas, el avance es de apensas el 2%. La empresa contratista es Aponte - Latorre SA y se realiza en el departamento de ITAPUA con aportes locales.', 4, NULL, '8', '2011-08-01', 1, NULL, NULL, NULL),
(6, 'Mejoramiento de puente rio Uruguay', NULL, 'La obra se inició en 2009 en el departamento de Itapuá, es financiado con fuente local.', 4, NULL, '0', '2009-11-09', NULL, NULL, NULL, NULL),
(7, 'Puente la noria', 2, 'La obra comienza en el año 2008, ....', 4, NULL, '0', '2012-03-30', 3, NULL, NULL, NULL),
(8, 'Obra para reunión del 18-5', NULL, 'Obra prioritaria para el gobierno', 4, NULL, '34', '2012-05-01', 2, NULL, NULL, NULL),
(9, 'Obra 1 del contrato de roggio', NULL, 'Obra del contrato 1', 6, NULL, '25', '2012-05-09', NULL, NULL, NULL, NULL),
(10, 'rambla norte', 5, 'Esta obra consiste en bla bla bla', 10, NULL, '0', '2012-05-31', 4, NULL, NULL, NULL),
(11, 'qwsqw', 1, 'wqqweqw', NULL, NULL, '12', '2012-06-04', NULL, NULL, NULL, NULL),
(12, 'sqw', 1, 'adsa', 6, NULL, '2', '2012-07-03', 1, 5, NULL, NULL),
(13, 'sad', 1, 'dasdas', NULL, NULL, '55', '2012-07-06', 1, 2, NULL, NULL),
(14, 'asdas', 1, 'dasdas', NULL, NULL, '22', '2012-07-06', 2, 1, NULL, NULL),
(15, 'sada', 1, 'das', 11, NULL, '3', '2012-07-11', NULL, 1, NULL, NULL),
(16, 'fsd', 1, 'fdsfsd', 11, NULL, '2', '2012-07-11', 1, 1, NULL, NULL),
(17, 'Prueba de Items', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 'SA', 9, 'DAD', 11, NULL, '2', '2012-07-12', 1, NULL, NULL, NULL),
(19, '', 10, NULL, NULL, NULL, '2', '2012-07-12', 1, 1, NULL, NULL),
(20, 'ghg', 1, 'jgj', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, '', 1, NULL, NULL, NULL, '6', '2012-09-12', 7, 2, 6, 2);

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_constructionDepartment`
--

CREATE TABLE IF NOT EXISTS `vialidad_constructionDepartment` (
  `constructionId` int(11) NOT NULL COMMENT 'Construction ID',
  `departmentId` int(11) NOT NULL COMMENT 'Department ID',
  PRIMARY KEY  (`constructionId`,`departmentId`),
  KEY `vialidad_constructionDepartment_FI_2` (`departmentId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Construction / Deparment';

--
-- Dumping data for table `vialidad_constructionDepartment`
--

INSERT INTO `vialidad_constructionDepartment` (`constructionId`, `departmentId`) VALUES
(1, 3),
(1, 6),
(1, 18),
(4, 1),
(4, 2),
(4, 3),
(4, 5),
(4, 6),
(4, 7),
(4, 8),
(4, 9),
(4, 10),
(4, 11),
(4, 12),
(4, 13),
(4, 14),
(4, 15),
(4, 16),
(4, 17),
(4, 18),
(5, 13),
(6, 2),
(6, 13),
(7, 3),
(8, 2),
(8, 5),
(9, 14),
(11, 2),
(12, 1),
(12, 3),
(12, 7),
(18, 1),
(21, 2);

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_constructionItem`
--

CREATE TABLE IF NOT EXISTS `vialidad_constructionItem` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `code` varchar(50) default NULL COMMENT 'Codigo',
  `price` decimal(12,2) default NULL COMMENT 'Precio ',
  `unit` varchar(12) default NULL COMMENT 'Unidad',
  `constructionId` int(11) default NULL COMMENT 'Id del construction',
  `quantity` decimal(12,2) default NULL COMMENT 'Cantidad ',
  `description` text,
  `date` date default NULL,
  `class_key` int(11) default NULL,
  `type` tinyint(4) default '1' COMMENT 'Tipo',
  PRIMARY KEY  (`id`),
  KEY `vialidad_constructionItem_FI_1` (`constructionId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `vialidad_constructionItem`
--

INSERT INTO `vialidad_constructionItem` (`id`, `name`, `code`, `price`, `unit`, `constructionId`, `quantity`, `description`, `date`, `class_key`, `type`) VALUES
(1, 'Hormigón 250Kg/cm2', '1.1', NULL, 'm3', 1, 74.00, NULL, NULL, 1, 1),
(2, 'Hormigón Asfaltico', '1.3.', NULL, 'm3', 1, 56.00, NULL, NULL, 1, 1),
(3, 'Excavación estribos de puente', '1.4', NULL, 'm3', 1, 123.00, NULL, NULL, 1, 1),
(4, 'Remosión de escombros líquidos', '1.5', NULL, 'm', 3, 23.08, NULL, NULL, 1, 1),
(8, 'Hormigón Asfaltico', '1.1', NULL, 'm3', 3, 5.00, NULL, NULL, 1, 1),
(7, 'Remosión de escombros', '1.6', NULL, 'm', 3, 3.00, NULL, NULL, 1, 1),
(9, 'Capa final del asfalto', '1.1', NULL, 'Km2', 3, 3.00, NULL, NULL, 1, 1),
(10, '', NULL, 8956000.00, NULL, 1, NULL, 'Traslado torre alta tensión', '2011-10-01', 3, 1),
(23, 'Dragado', '234', NULL, 'm3', 6, 542.00, NULL, NULL, NULL, 1),
(12, 'Desbosque, desbroce, despeje y limpieza', '2.1', NULL, 'm2', 4, 0.00, NULL, NULL, 1, 1),
(13, 'Desbosque, desbroce, despeje y limpieza', '3.3', NULL, 'm2', 4, 3.00, NULL, NULL, 1, 1),
(14, 'Excavacion no clasificada', '3444', NULL, 'm3', 4, 5.00, NULL, NULL, 1, 1),
(15, 'Terraplén', '24', NULL, 'Km', 3, 3.00, NULL, NULL, 1, 1),
(16, 'Prueba', '88', NULL, 'm', 3, 3.00, NULL, NULL, 1, 1),
(17, 'Excavación en roca', '89', NULL, 'm3', 3, 4.00, NULL, NULL, 1, 1),
(18, 'Excavacion', '3.4', NULL, 'm3', 3, 2.00, NULL, NULL, 1, 1),
(20, 'Hormigón Armado 250Kg/cm2', '22', NULL, 'm3', 5, 325.00, NULL, NULL, 1, 1),
(21, '', NULL, 5666.00, NULL, 5, NULL, 'Retraso entrega de planos', '2012-01-01', 2, 1),
(22, 'Remoción de escombros', '5.6.7', NULL, 'T', 3, 34.00, NULL, NULL, 1, 1),
(24, 'jornales', '34', NULL, 'u', 8, 20.00, NULL, NULL, 1, 1),
(25, '', NULL, 25.00, NULL, 9, NULL, 'movimiento de carteles', '2012-05-18', 3, 1),
(26, '', NULL, 20.00, NULL, 9, NULL, 'retraso', '2012-05-20', 2, 1),
(27, 'Jornales', '34', NULL, 'u', 10, 20.00, NULL, NULL, 1, 1),
(28, 'excavación de estribos', NULL, NULL, 'm3', NULL, 10000.00, NULL, NULL, 1, 1),
(29, '', NULL, 20000000.00, NULL, 1, NULL, '100 Computadoras', '2012-01-06', 5, 1),
(30, 'Terraplén', NULL, NULL, 'Km', 11, NULL, NULL, NULL, 1, 1),
(31, 'SDS', '1', NULL, 'm', NULL, 0.00, NULL, NULL, 1, 1),
(32, 'obra1', '1', NULL, 'm2', NULL, 0.99, NULL, NULL, 1, 1),
(33, 'dasdas', '11', NULL, 'm2', NULL, 212.00, NULL, NULL, 1, 1),
(34, 'prueba', '1', NULL, 'm', NULL, 12312.00, NULL, NULL, 1, 1),
(35, 'Hormigón 250Kg/cm2', NULL, NULL, 'm3', 14, NULL, NULL, NULL, 1, 1),
(36, 'gcf', '1', NULL, 'm', NULL, 44.00, NULL, NULL, 1, 1),
(37, 'asdas', '3', NULL, 'm', NULL, 3.00, NULL, NULL, 1, 1),
(38, '', NULL, 9000000.00, NULL, 1, NULL, 'Terraplenado', '2012-07-01', 3, 1),
(39, '', NULL, 2000000.00, NULL, 1, NULL, 'Desmonte', '2012-07-01', 3, 1),
(40, '', NULL, 3000000.00, NULL, 1, NULL, 'Remocion de escombros', '2012-07-01', 4, 1),
(41, '', NULL, 5000000.00, NULL, 1, NULL, 'Contratacion de personal', '2012-07-01', 5, 1),
(42, 'Hormigon armado', 'ha200', NULL, 'm2', 16, 50.00, NULL, NULL, 1, 1),
(44, 'Hormigon armado', NULL, NULL, 'm2', 17, NULL, NULL, NULL, 1, 1),
(45, 'Remosión de escombros líquidos', NULL, NULL, 'm', 17, NULL, NULL, NULL, 1, 1),
(46, 'Hormigon armado', NULL, NULL, 'm2', 1, NULL, NULL, NULL, 1, 1),
(48, 'Hormigón Armado 250Kg/cm2', NULL, NULL, 'm3', 1, NULL, NULL, NULL, 1, 1),
(49, 'ewqew', '1', NULL, 'm2', NULL, 22.00, NULL, NULL, 1, 1),
(50, 'Hormigon armado', NULL, NULL, 'm2', 1, NULL, NULL, NULL, 1, 1),
(51, '', NULL, 5000.00, NULL, 14, NULL, 'Compra de 5 Computadoras', '2012-09-11', 5, 1),
(52, '', NULL, 5000.00, NULL, 14, NULL, 'Compra de 5 Computadoras', '2012-09-25', 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_constructionItemRelation`
--

CREATE TABLE IF NOT EXISTS `vialidad_constructionItemRelation` (
  `itemId` int(11) NOT NULL,
  `supplyId` int(11) NOT NULL,
  `proportion` decimal(12,2) default NULL COMMENT 'Precio definitivo',
  PRIMARY KEY  (`itemId`,`supplyId`),
  KEY `vialidad_constructionItemRelation_FI_2` (`supplyId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vialidad_constructionItemRelation`
--

INSERT INTO `vialidad_constructionItemRelation` (`itemId`, `supplyId`, `proportion`) VALUES
(1, 6, 40.00),
(1, 2, 15.00),
(1, 33, 1.00),
(1, 23, 29.15),
(2, 5, 40.00),
(2, 23, 35.00),
(2, 12, 15.00),
(2, 33, 10.00),
(4, 1, 75.00),
(4, 2, 13.00),
(3, 36, 63.00),
(3, 33, 10.00),
(3, 16, 15.00),
(3, 32, 12.00),
(4, 11, 7.00),
(4, 33, 5.00),
(8, 5, 40.00),
(8, 12, 15.00),
(8, 23, 35.00),
(8, 33, 10.00),
(9, 12, 80.00),
(9, 33, 10.00),
(9, 11, 5.00),
(9, 17, 5.00),
(1, 13, 0.00),
(1, 5, 0.00),
(1, 12, 0.00),
(27, 33, 80.00),
(24, 33, 60.00),
(24, 11, 40.00),
(2, 2, 0.00),
(27, 11, 20.00),
(28, 33, 19.70),
(28, 11, 25.90),
(28, 17, 51.70),
(28, 20, 2.20),
(28, 10, 0.50),
(35, 2, 15.00),
(35, 5, 0.00),
(35, 6, 40.00),
(35, 12, 0.00),
(35, 13, 0.00),
(35, 23, 29.15),
(35, 33, 1.00),
(1, 17, 0.00),
(34, 26, 100.00),
(42, 26, 40.00),
(42, 6, 60.00),
(44, 6, 60.00),
(44, 26, 40.00),
(45, 1, 75.00),
(45, 2, 13.00),
(45, 11, 7.00),
(45, 33, 5.00),
(46, 6, 60.00),
(46, 26, 40.00),
(50, 6, 60.00),
(50, 26, 40.00),
(15, 5, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_constructionType`
--

CREATE TABLE IF NOT EXISTS `vialidad_constructionType` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL COMMENT 'Tipo de Obra',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `vialidad_constructionType`
--

INSERT INTO `vialidad_constructionType` (`id`, `name`) VALUES
(1, 'Pavimentación Tipo Empedrado'),
(2, 'Terraplenado'),
(3, 'Construccion de Puentes'),
(4, 'Construcción Civil'),
(5, 'Pavimentación asfáltica'),
(6, 'Reconstrucción y recapado de concreto asfáltico'),
(7, 'Rehabilitación y pavimentación asfáltica'),
(8, 'Construcción de puentes'),
(9, 'Reconstrucción de banquinas'),
(10, 'Tratamiento superficial triple'),
(11, 'Mantenimiento por niveles de servicio');

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_contract`
--

CREATE TABLE IF NOT EXISTS `vialidad_contract` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `contractorId` int(11) default NULL COMMENT 'Id del contratista',
  `startDate` date default NULL COMMENT 'Fecha de firma',
  `ammount` decimal(15,2) default NULL COMMENT 'Monto del Contrato',
  `ammountModified` decimal(15,2) default NULL COMMENT 'Monto modificado',
  `contractLength` int(5) default NULL COMMENT 'Longitud del contrato en dias',
  `type` int(2) default NULL COMMENT 'Tipo de contrato',
  `termType` int(2) default NULL COMMENT 'Tipo de plazo de longitud del contrato',
  `adjudication` varchar(50) default NULL COMMENT 'Resolucion y/o Decreto de Adjudicacion',
  `adjudicationDate` date default NULL COMMENT 'Fecha de adjudicacion',
  `pacNumber` varchar(10) default NULL COMMENT 'Numero de contrato PAC',
  `tprano` varchar(4) default NULL COMMENT 'Anio del contrato',
  `tprcod` varchar(1) default NULL COMMENT 'Tipo de presupuesto',
  `prgcod` varchar(3) default NULL COMMENT 'Programa',
  `subprgcod` varchar(3) default NULL COMMENT 'subprograma',
  `prycod` varchar(2) default NULL COMMENT 'Proyecto',
  `prydes` varchar(100) default NULL COMMENT 'Descripcion',
  `contractNumber` varchar(20) default NULL COMMENT 'Codigo del Contrato',
  `tenderNumber` varchar(20) default NULL COMMENT 'Numero de Llamado a Licitacion',
  `signDate` date default NULL COMMENT 'Fecha de firma',
  `validationLength` int(5) default NULL COMMENT 'Vigencia del contrato Modificado',
  `validationType` int(2) default NULL COMMENT 'Tipo de plazo de longitud del contrato Modificado',
  `contractLengthModified` int(5) default NULL COMMENT 'Longitud del contrato Modificado',
  `termTypeModified` int(2) default NULL COMMENT 'Tipo de plazo de longitud del contrato Modificado',
  `validationLengthModified` int(5) default NULL COMMENT 'Vigencia del contrato',
  `validationTypeModified` int(2) default NULL COMMENT 'Tipo de plazo de longitud del contrato',
  PRIMARY KEY  (`id`),
  KEY `vialidad_contract_FI_1` (`contractorId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `vialidad_contract`
--

INSERT INTO `vialidad_contract` (`id`, `name`, `contractorId`, `startDate`, `ammount`, `ammountModified`, `contractLength`, `type`, `termType`, `adjudication`, `adjudicationDate`, `pacNumber`, `tprano`, `tprcod`, `prgcod`, `subprgcod`, `prycod`, `prydes`, `contractNumber`, `tenderNumber`, `signDate`, `validationLength`, `validationType`, `contractLengthModified`, `termTypeModified`, `validationLengthModified`, `validationTypeModified`) VALUES
(1, 'Contrato 1', 3, NULL, NULL, NULL, 0, 2, 1, NULL, NULL, '211730', NULL, NULL, NULL, NULL, NULL, NULL, '1', '1', NULL, 0, 1, 0, 1, 0, 1),
(2, 'Contrato 2', 3, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, '211730', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'Contrato Puente Uruguay BID 1822-3435', NULL, '2012-02-01', 58000000.00, NULL, 180, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'Contrato 34', NULL, '2012-05-02', 34555000.00, NULL, 720, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'Contrato general por obras en la costanera', 9, '2012-05-01', 45000000000.00, NULL, 720, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'Restauración, Conservación y Puesta en Valor del Teatro de Villarrica', NULL, '2011-07-25', 1.27, 0.00, 180, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 'sdsad', NULL, '2012-07-06', NULL, NULL, 123, 2, 1, NULL, '2012-07-06', '1', NULL, NULL, NULL, NULL, NULL, NULL, '1', '1', '2012-07-06', NULL, NULL, NULL, NULL, NULL, NULL),
(8, '', NULL, NULL, NULL, NULL, 0, 2, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 1, 0, 1),
(9, 'aA', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, '1', '1', NULL, 0, 1, 0, 1, 0, 1),
(10, 'fisacalizacion1', 6, '2012-07-12', NULL, NULL, 0, 2, 1, NULL, '2012-07-12', '1', NULL, NULL, NULL, NULL, NULL, NULL, '1', '1', NULL, 0, 1, 0, 1, 0, 1),
(11, 'hghfg', NULL, NULL, NULL, NULL, 0, 2, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 1, 0, 1),
(12, 'dsfsdfsd', NULL, NULL, NULL, NULL, 0, 2, 1, NULL, NULL, 'dsfds', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 1, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_contractAmount`
--

CREATE TABLE IF NOT EXISTS `vialidad_contractAmount` (
  `id` int(11) NOT NULL auto_increment,
  `contractId` int(11) NOT NULL,
  `currencyId` int(11) NOT NULL,
  `amount` decimal(15,2) default NULL COMMENT 'Monto',
  `paripassu` decimal(15,2) default NULL COMMENT 'Pari Pasu',
  `date` date default NULL COMMENT 'Fecha',
  `amountType` tinyint(1) default NULL COMMENT 'Monto Original o Modificatorio',
  `exchangeRate` decimal(15,2) default NULL COMMENT 'Tasa de Cambio',
  PRIMARY KEY  (`id`),
  KEY `vialidad_contractAmount_FI_1` (`currencyId`),
  KEY `vialidad_contractAmount_FI_2` (`contractId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Montos Originales y Modificatorios de Contratos' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `vialidad_contractAmount`
--

INSERT INTO `vialidad_contractAmount` (`id`, `contractId`, `currencyId`, `amount`, `paripassu`, `date`, `amountType`, `exchangeRate`) VALUES
(1, 1, 1, 55555000.00, 12555.00, '2010-12-30', 1, 4555.00),
(2, 1, 2, 90000.00, 0.00, '2012-06-26', 1, 0.00),
(3, 1, 1, 0.00, 800.00, '2012-06-26', 1, 0.00),
(4, 7, 1, 12312.00, 2.00, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_contractSource`
--

CREATE TABLE IF NOT EXISTS `vialidad_contractSource` (
  `contractId` int(11) NOT NULL COMMENT 'Contract ID',
  `sourceId` int(11) NOT NULL COMMENT 'Source ID',
  `ammount` decimal(15,2) NOT NULL COMMENT 'Ammount',
  PRIMARY KEY  (`contractId`,`sourceId`),
  KEY `vialidad_contractSource_FI_2` (`sourceId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Contract / Source';

--
-- Dumping data for table `vialidad_contractSource`
--

INSERT INTO `vialidad_contractSource` (`contractId`, `sourceId`, `ammount`) VALUES
(1, 3, 0.00),
(1, 1, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_currency`
--

CREATE TABLE IF NOT EXISTS `vialidad_currency` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(50) default NULL COMMENT 'Codigo de la moneda',
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Base de datos de monedas' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `vialidad_currency`
--

INSERT INTO `vialidad_currency` (`id`, `code`, `name`) VALUES
(1, 'Gs', 'Guaraníes'),
(2, '$', 'Dólares'),
(3, 'E', 'Euros'),
(4, 'Y', 'Yens');

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_department`
--

CREATE TABLE IF NOT EXISTS `vialidad_department` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL COMMENT 'Departamentos',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `vialidad_department`
--

INSERT INTO `vialidad_department` (`id`, `name`) VALUES
(1, 'Alto Paraguay'),
(2, 'Alto Paraná'),
(3, 'Amambay'),
(5, 'Boquerón'),
(6, 'Caaguazú'),
(7, 'Caazapá'),
(8, 'Canindeyú'),
(9, 'Central'),
(10, 'Concepción'),
(11, 'Cordillera'),
(12, 'Guairá'),
(13, 'Itapúa'),
(14, 'Misiones'),
(15, 'Paraguarí'),
(16, 'Presidente Hayes'),
(17, 'San Pedro'),
(18, 'Ñeembucú');

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_measurementRecord`
--

CREATE TABLE IF NOT EXISTS `vialidad_measurementRecord` (
  `id` int(11) NOT NULL auto_increment,
  `measurementDate` date default NULL COMMENT 'Fecha del acta de medicion',
  `constructionId` int(11) default NULL COMMENT 'Id del construction',
  `code` varchar(10) NOT NULL COMMENT 'Numero de Medicion',
  PRIMARY KEY  (`id`),
  KEY `vialidad_measurementRecord_FI_1` (`constructionId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `vialidad_measurementRecord`
--

INSERT INTO `vialidad_measurementRecord` (`id`, `measurementDate`, `constructionId`, `code`) VALUES
(3, '2011-10-17', 1, ''),
(7, '2011-11-15', 1, ''),
(8, '2011-12-07', 1, ''),
(11, '2011-08-01', 1, ''),
(12, '2012-01-25', 2, '23'),
(13, '2012-05-16', 1, '3456'),
(14, '2012-05-09', 8, '1'),
(15, '2012-07-01', 1, '5'),
(16, '2012-09-01', 14, '2'),
(17, '2012-10-09', 1, '12'),
(18, '2012-10-01', 1, '12'),
(19, '2012-10-03', 1, '1'),
(20, '2012-10-01', 1, '5'),
(21, '2012-10-09', 1, '12');

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_measurementRecordComment`
--

CREATE TABLE IF NOT EXISTS `vialidad_measurementRecordComment` (
  `id` int(11) NOT NULL auto_increment,
  `measurementRecordId` int(11) NOT NULL,
  `userId` int(11) NOT NULL COMMENT 'Usuario',
  `userType` varchar(50) NOT NULL COMMENT 'Usuario',
  `content` mediumtext COMMENT 'Contenido del comentario',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `vialidad_measurementRecordComment_FI_1` (`measurementRecordId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `vialidad_measurementRecordComment`
--

INSERT INTO `vialidad_measurementRecordComment` (`id`, `measurementRecordId`, `userId`, `userType`, `content`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 'User', 'Comentarios sobre el acta', '2012-01-06 14:25:17', '2012-01-06 14:25:17'),
(2, 13, 1, 'User', 'El acta fue presentada por mesa de entrada', '2012-05-18 11:35:24', '2012-05-18 11:35:24'),
(3, 18, 1, 'User', 'asdasdasd', '2012-10-11 17:35:12', '2012-10-11 17:35:12');

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_measurementRecordRelation`
--

CREATE TABLE IF NOT EXISTS `vialidad_measurementRecordRelation` (
  `id` int(11) NOT NULL auto_increment,
  `itemId` int(11) NOT NULL,
  `measurementRecordId` int(11) NOT NULL,
  `quantity` decimal(12,2) default NULL COMMENT 'Cantidad ',
  `verified` tinyint(1) default NULL COMMENT 'Indica si esta publicado',
  `documentId` int(11) default NULL COMMENT 'Documento respaldatorio',
  `comments` mediumtext COMMENT 'Observaciones',
  `price` decimal(12,2) default NULL COMMENT 'Precio',
  PRIMARY KEY  (`id`),
  KEY `vialidad_measurementRecordRelation_FI_1` (`itemId`),
  KEY `vialidad_measurementRecordRelation_FI_2` (`measurementRecordId`),
  KEY `vialidad_measurementRecordRelation_FI_3` (`documentId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=82 ;

--
-- Dumping data for table `vialidad_measurementRecordRelation`
--

INSERT INTO `vialidad_measurementRecordRelation` (`id`, `itemId`, `measurementRecordId`, `quantity`, `verified`, `documentId`, `comments`, `price`) VALUES
(7, 1, 3, 45.00, 0, 7, NULL, 3600.00),
(8, 2, 3, 68.00, 0, NULL, NULL, 56235.00),
(9, 3, 3, 14.00, 0, NULL, NULL, 4500.00),
(16, 1, 7, 85.00, 0, NULL, NULL, 8900.00),
(17, 2, 7, 72.00, 0, NULL, NULL, 15005.00),
(18, 3, 7, 154.00, 0, NULL, NULL, 25000.00),
(19, 1, 8, 50.00, 1, NULL, NULL, 8900.00),
(20, 2, 8, 145.00, 0, NULL, NULL, 15500.00),
(21, 3, 8, 28.00, 1, NULL, NULL, 45000.00),
(28, 1, 11, 0.00, 0, NULL, NULL, NULL),
(29, 2, 11, 0.00, 0, NULL, NULL, NULL),
(30, 3, 11, 0.00, 0, NULL, NULL, NULL),
(31, 10, 3, 0.00, 0, NULL, NULL, 0.00),
(32, 1, 13, 54.00, 1, NULL, NULL, 20.00),
(33, 2, 13, 87.00, 0, NULL, NULL, 40.00),
(34, 3, 13, 12.00, 1, NULL, NULL, 50.00),
(35, 24, 14, 40.00, 1, NULL, NULL, 45.00),
(36, 1, 15, 0.00, 0, NULL, NULL, 0.00),
(37, 2, 15, 0.00, 0, NULL, NULL, 0.00),
(38, 3, 15, 0.00, 0, NULL, NULL, 0.00),
(39, 38, 15, 0.00, 0, NULL, NULL, 0.00),
(40, 39, 15, 0.00, 0, NULL, NULL, 0.00),
(41, 40, 15, 0.00, 0, NULL, NULL, 0.00),
(42, 46, 3, 0.00, 0, NULL, NULL, 0.00),
(43, 48, 3, 0.00, 0, NULL, NULL, 0.00),
(44, 35, 16, 10.00, 1, NULL, NULL, NULL),
(45, 51, 16, 0.00, 0, NULL, NULL, NULL),
(46, 52, 16, 0.00, 0, NULL, NULL, NULL),
(47, 50, 3, 0.00, 0, NULL, NULL, 0.00),
(48, 1, 17, 0.00, 1, NULL, NULL, 0.00),
(49, 2, 17, 0.00, 0, NULL, NULL, NULL),
(50, 3, 17, 0.00, 0, NULL, NULL, NULL),
(51, 46, 17, 0.00, 0, NULL, NULL, NULL),
(52, 48, 17, 0.00, 0, NULL, NULL, NULL),
(53, 50, 17, 0.00, 0, NULL, NULL, NULL),
(54, 46, 15, 0.00, 0, NULL, NULL, 0.00),
(55, 1, 18, 0.00, 0, NULL, NULL, NULL),
(56, 2, 18, 0.00, 0, NULL, NULL, NULL),
(57, 3, 18, 0.00, 0, NULL, NULL, NULL),
(58, 46, 18, 0.00, 0, NULL, NULL, NULL),
(59, 48, 18, 0.00, 0, NULL, NULL, NULL),
(60, 50, 18, 0.00, 0, NULL, NULL, NULL),
(61, 1, 19, 0.00, 0, NULL, NULL, NULL),
(62, 2, 19, 0.00, 0, NULL, NULL, NULL),
(63, 3, 19, 0.00, 0, NULL, NULL, NULL),
(64, 46, 19, 0.00, 0, NULL, NULL, NULL),
(65, 48, 19, 0.00, 0, NULL, NULL, NULL),
(66, 50, 19, 0.00, 0, NULL, NULL, NULL),
(67, 46, 7, 0.00, 0, NULL, NULL, 0.00),
(68, 48, 7, 0.00, 0, NULL, NULL, 0.00),
(69, 50, 7, 0.00, 0, NULL, NULL, 0.00),
(70, 1, 20, 0.00, 0, NULL, NULL, NULL),
(71, 2, 20, 0.00, 0, NULL, NULL, NULL),
(72, 3, 20, 0.00, 0, NULL, NULL, NULL),
(73, 46, 20, 0.00, 0, NULL, NULL, NULL),
(74, 48, 20, 0.00, 0, NULL, NULL, NULL),
(75, 50, 20, 0.00, 0, NULL, NULL, NULL),
(76, 1, 21, 0.00, 0, NULL, NULL, NULL),
(77, 2, 21, 0.00, 0, NULL, NULL, NULL),
(78, 3, 21, 0.00, 0, NULL, NULL, NULL),
(79, 46, 21, 0.00, 0, NULL, NULL, NULL),
(80, 48, 21, 0.00, 0, NULL, NULL, NULL),
(81, 50, 21, 0.00, 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_measureUnit`
--

CREATE TABLE IF NOT EXISTS `vialidad_measureUnit` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(50) default NULL COMMENT 'Codigo de la unidad',
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Base de datos de unidades de medida' AUTO_INCREMENT=16 ;

--
-- Dumping data for table `vialidad_measureUnit`
--

INSERT INTO `vialidad_measureUnit` (`id`, `code`, `name`) VALUES
(1, 'm', 'Metro'),
(2, 'm2', 'metro cuadrado'),
(3, 'm3', 'metro cúbico'),
(4, 'Kg', 'Kilogramo'),
(5, 'T', 'Tonelada'),
(6, 'l', 'litro'),
(7, 'a', 'área'),
(8, 'Ha', 'Hectárea'),
(9, 'u', 'unidad'),
(10, 'Km', 'Kilómetro'),
(11, 'Km2', 'Kilómetro cuadrado'),
(12, 'pulg2m', 'Pulgada por metro cuadrado'),
(13, 'Gs', 'Guaraní'),
(14, 'Gs/h', 'Guaraníes por hora'),
(15, '%', 'Porcentaje');

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_priceBulletin`
--

CREATE TABLE IF NOT EXISTS `vialidad_priceBulletin` (
  `id` int(11) NOT NULL auto_increment,
  `bulletinId` int(11) NOT NULL,
  `supplyId` int(11) NOT NULL,
  `averagePrice` decimal(12,2) default NULL COMMENT 'Precio provisorio',
  `publish` tinyint(1) default '1' COMMENT 'Indica si el precio se publica o no',
  `definitive` tinyint(1) default NULL COMMENT 'Indica si el precio es definitivo o no',
  `supplierId1` int(11) NOT NULL,
  `price1` decimal(12,2) default NULL COMMENT 'Precio provisorio, proveedor 1',
  `definitive1` tinyint(1) default NULL COMMENT 'Indica si el precio es definitivo o no, proveedor 1',
  `supplierDocument1` int(11) default NULL COMMENT 'Documento respaldatorio, proveedor 1',
  `supplierId2` int(11) NOT NULL,
  `price2` decimal(12,2) default NULL COMMENT 'Precio provisorio, proveedor 2',
  `definitive2` tinyint(1) default NULL COMMENT 'Indica si el precio es definitivo o no, proveedor 2',
  `supplierDocument2` int(11) default NULL COMMENT 'Documento respaldatorio, proveedor 2',
  `supplierId3` int(11) NOT NULL,
  `price3` decimal(12,2) default NULL COMMENT 'Precio provisorio, proveedor 3',
  `definitive3` tinyint(1) default NULL COMMENT 'Indica si el precio es definitivo o no, proveedor 3',
  `supplierDocument3` int(11) default NULL COMMENT 'Documento respaldatorio, proveedor 3',
  `definitiveOn` date default NULL COMMENT 'Fecha que se marco definitivo',
  `modifiedPrice` decimal(12,2) default NULL COMMENT 'Precio modificado',
  `modifiedOn` date default NULL COMMENT 'Fecha que se marco modificado',
  `lastPrice1` decimal(12,2) default NULL COMMENT 'Precio anterior proveedor 1',
  `lastPrice2` decimal(12,2) default NULL COMMENT 'Precio anterior proveedor 2',
  `lastPrice3` decimal(12,2) default NULL COMMENT 'Precio anterior proveedor 3',
  PRIMARY KEY  (`id`),
  KEY `vialidad_priceBulletin_FI_1` (`bulletinId`),
  KEY `vialidad_priceBulletin_FI_2` (`supplyId`),
  KEY `vialidad_priceBulletin_FI_3` (`supplierId1`),
  KEY `vialidad_priceBulletin_FI_4` (`supplierId2`),
  KEY `vialidad_priceBulletin_FI_5` (`supplierId3`),
  KEY `vialidad_priceBulletin_FI_6` (`supplierDocument1`),
  KEY `vialidad_priceBulletin_FI_7` (`supplierDocument2`),
  KEY `vialidad_priceBulletin_FI_8` (`supplierDocument3`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=445 ;

--
-- Dumping data for table `vialidad_priceBulletin`
--

INSERT INTO `vialidad_priceBulletin` (`id`, `bulletinId`, `supplyId`, `averagePrice`, `publish`, `definitive`, `supplierId1`, `price1`, `definitive1`, `supplierDocument1`, `supplierId2`, `price2`, `definitive2`, `supplierDocument2`, `supplierId3`, `price3`, `definitive3`, `supplierDocument3`, `definitiveOn`, `modifiedPrice`, `modifiedOn`, `lastPrice1`, `lastPrice2`, `lastPrice3`) VALUES
(1, 1, 1, 66735.00, 1, 0, 1, 200000.00, 1, 1, 0, 104.00, 0, NULL, 0, 103.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 1, 2, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 1, 3, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 1, 4, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 1, 5, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 1, 6, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 1, 7, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 1, 8, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 1, 9, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 1, 10, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 1, 11, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, 1, 12, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, 1, 13, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 1, 14, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, 1, 15, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, 1, 16, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(17, 1, 17, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 1, 18, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19, 1, 19, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20, 1, 20, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, 1, 21, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(22, 1, 22, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(23, 1, 23, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(24, 1, 24, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(25, 1, 25, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(26, 1, 26, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(27, 1, 27, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(28, 1, 28, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(29, 1, 29, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(30, 1, 30, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(31, 1, 31, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(32, 1, 32, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(33, 1, 33, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(34, 1, 34, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(35, 1, 35, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(36, 1, 36, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(37, 2, 1, 33.00, 1, 1, 0, 34.00, 1, NULL, 0, 43.00, 1, NULL, 0, 22.00, 1, NULL, NULL, 35.00, '2011-11-02', NULL, NULL, NULL),
(38, 2, 2, 115000.00, 1, 1, 1, 100000.00, 1, 4, 0, 120000.00, 1, NULL, 0, 125000.00, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(39, 2, 3, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2011-11-14', 5000.00, '2011-11-14', NULL, NULL, NULL),
(40, 2, 4, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2011-11-01', 0.00, NULL, NULL, NULL, NULL),
(41, 2, 5, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(42, 2, 6, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(43, 2, 7, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(44, 2, 8, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(45, 2, 9, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(46, 2, 10, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(47, 2, 11, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(48, 2, 12, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(49, 2, 13, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(50, 2, 14, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(51, 2, 15, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(52, 2, 16, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(53, 2, 17, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(54, 2, 18, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(55, 2, 19, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(56, 2, 20, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(57, 2, 21, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(58, 2, 22, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(59, 2, 23, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(60, 2, 24, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(61, 2, 25, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(62, 2, 26, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(63, 2, 27, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(64, 2, 28, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(65, 2, 29, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(66, 2, 30, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(67, 2, 31, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(68, 2, 32, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(69, 2, 33, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(70, 2, 34, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(71, 2, 35, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(72, 2, 36, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(73, 3, 1, 1324.00, 1, 1, 1, 1500.25, 1, NULL, 0, 1250.30, 1, NULL, 0, 1222.22, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(74, 3, 2, 115000.00, 1, 1, 1, 100000.00, 1, NULL, 0, 120000.00, 1, NULL, 0, 125000.00, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(75, 3, 3, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, '2011-11-14', 5000.00, '2011-11-14', NULL, NULL, NULL),
(76, 3, 4, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(77, 3, 5, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(78, 3, 6, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(79, 3, 7, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(80, 3, 8, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(81, 3, 9, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(82, 3, 10, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(83, 3, 11, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(84, 3, 12, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(85, 3, 13, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(86, 3, 14, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(87, 3, 15, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(88, 3, 16, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(89, 3, 17, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(90, 3, 18, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(91, 3, 19, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(92, 3, 20, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(93, 3, 21, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(94, 3, 22, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(95, 3, 23, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(96, 3, 24, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(97, 3, 25, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(98, 3, 26, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(99, 3, 27, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(100, 3, 28, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(101, 3, 29, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(102, 3, 30, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(103, 3, 31, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(104, 3, 32, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(105, 3, 33, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(106, 3, 34, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(107, 3, 35, 117111.00, 1, 1, 0, 117111.00, 1, NULL, 0, NULL, 1, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(108, 3, 36, 0.00, 1, 0, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(109, 4, 1, 0.00, 0, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 1500.25, 1250.30, 1222.22),
(110, 4, 2, 0.00, 0, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 100000.00, 120000.00, 125000.00),
(111, 4, 3, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, '2011-11-14', 5000.00, '2011-11-14', NULL, NULL, NULL),
(112, 4, 4, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(113, 4, 5, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(114, 4, 6, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(115, 4, 7, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(116, 4, 8, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(117, 4, 9, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(118, 4, 10, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(119, 4, 11, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(120, 4, 12, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(121, 4, 13, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(122, 4, 14, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(123, 4, 15, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(124, 4, 16, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(125, 4, 17, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(126, 4, 18, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(127, 4, 19, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(128, 4, 20, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(129, 4, 21, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(130, 4, 22, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(131, 4, 23, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(132, 4, 24, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(133, 4, 25, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(134, 4, 26, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(135, 4, 27, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(136, 4, 28, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(137, 4, 29, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(138, 4, 30, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(139, 4, 31, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(140, 4, 32, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(141, 4, 33, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(142, 4, 34, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(143, 4, 35, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(144, 4, 36, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(198, 6, 9, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(195, 6, 6, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(192, 6, 3, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, '2011-11-14', 5000.00, '2011-11-14', 0.00, 0.00, 0.00),
(148, 5, 1, 47.00, 1, 1, 1, 100.00, 1, NULL, 4, 40.00, 1, NULL, 5, 20.00, 1, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(149, 5, 2, 33.00, 0, 0, 1, 100.00, 1, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(150, 5, 3, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, '2011-11-14', 5000.00, '2011-11-14', 0.00, 0.00, 0.00),
(151, 5, 4, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(152, 5, 5, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(153, 5, 6, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(154, 5, 7, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(155, 5, 8, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(156, 5, 9, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(157, 5, 10, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(158, 5, 11, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(159, 5, 12, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(160, 5, 13, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(161, 5, 14, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(162, 5, 15, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(163, 5, 16, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(164, 5, 17, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(165, 5, 18, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(166, 5, 19, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(167, 5, 20, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(168, 5, 21, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(169, 5, 22, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(170, 5, 23, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(171, 5, 24, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(172, 5, 25, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(173, 5, 26, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(174, 5, 27, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(175, 5, 28, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(176, 5, 29, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(177, 5, 30, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(178, 5, 31, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(179, 5, 32, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(180, 5, 33, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(181, 5, 34, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(182, 5, 35, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(183, 5, 36, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(197, 6, 8, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(194, 6, 5, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(191, 6, 2, 0.00, 0, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(196, 6, 7, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(193, 6, 4, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(190, 6, 1, 0.00, 0, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(199, 6, 10, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(200, 6, 11, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(201, 6, 12, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(202, 6, 13, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(203, 6, 14, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(204, 6, 15, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(205, 6, 16, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(206, 6, 17, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(207, 6, 18, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(208, 6, 19, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(209, 6, 20, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(210, 6, 21, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(211, 6, 22, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(212, 6, 23, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(213, 6, 24, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(214, 6, 25, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(215, 6, 26, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(216, 6, 27, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(217, 6, 28, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(218, 6, 29, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(219, 6, 30, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(220, 6, 31, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(221, 6, 32, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(222, 6, 33, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(223, 6, 34, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(224, 6, 35, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(225, 6, 36, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(226, 7, 9, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(227, 7, 6, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(228, 7, 3, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, '2011-11-14', 5000.00, '2011-11-14', 0.00, 0.00, 0.00),
(229, 7, 8, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(230, 7, 5, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(231, 7, 2, 0.00, 0, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(232, 7, 7, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(233, 7, 4, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(234, 7, 1, 0.00, 0, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(235, 7, 10, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(236, 7, 11, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(237, 7, 12, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(238, 7, 13, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(239, 7, 14, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(240, 7, 15, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(241, 7, 16, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(242, 7, 17, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(243, 7, 18, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(244, 7, 19, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(245, 7, 20, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(246, 7, 21, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(247, 7, 22, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(248, 7, 23, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(249, 7, 24, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(250, 7, 25, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(251, 7, 26, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(252, 7, 27, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(253, 7, 28, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(254, 7, 29, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(255, 7, 30, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(256, 7, 31, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(257, 7, 32, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(258, 7, 33, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(259, 7, 34, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(260, 7, 35, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(261, 7, 36, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(262, 8, 9, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(263, 8, 6, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(264, 8, 3, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, '2011-11-14', 5000.00, '2011-11-14', 0.00, 0.00, 0.00),
(265, 8, 8, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(266, 8, 5, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(267, 8, 2, 0.00, 0, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(268, 8, 7, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(269, 8, 4, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(270, 8, 1, 0.00, 0, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(271, 8, 10, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(272, 8, 11, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(273, 8, 12, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(274, 8, 13, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(275, 8, 14, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(276, 8, 15, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(277, 8, 16, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(278, 8, 17, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(279, 8, 18, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(280, 8, 19, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(281, 8, 20, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(282, 8, 21, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(283, 8, 22, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(284, 8, 23, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(285, 8, 24, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(286, 8, 25, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(287, 8, 26, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(288, 8, 27, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(289, 8, 28, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(290, 8, 29, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(291, 8, 30, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(292, 8, 31, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(293, 8, 32, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(294, 8, 33, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(295, 8, 34, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(296, 8, 35, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(297, 8, 36, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(298, 9, 9, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(299, 9, 6, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(300, 9, 3, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, '2011-11-14', 5000.00, '2011-11-14', 0.00, 0.00, 0.00),
(301, 9, 8, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(302, 9, 5, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(303, 9, 2, 0.00, 0, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(304, 9, 7, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(305, 9, 4, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(306, 9, 1, 0.00, 0, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(307, 9, 10, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(308, 9, 11, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(309, 9, 12, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(310, 9, 13, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(311, 9, 14, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(312, 9, 15, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(313, 9, 16, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(314, 9, 17, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(315, 9, 18, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(316, 9, 19, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(317, 9, 20, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(318, 9, 21, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(319, 9, 22, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(320, 9, 23, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(321, 9, 24, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(322, 9, 25, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(323, 9, 26, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(324, 9, 27, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(325, 9, 28, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(326, 9, 29, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(327, 9, 30, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(328, 9, 31, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(329, 9, 32, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(330, 9, 33, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(331, 9, 34, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(332, 9, 35, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(333, 9, 36, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(334, 10, 9, 1000.00, 0, 0, 1, 1000.00, 1, NULL, 0, 1000.00, 0, NULL, 0, 1000.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(335, 10, 6, 116666.00, 0, 0, 1, 350000.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(336, 10, 3, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, '2011-11-14', 5000.00, '2011-11-14', 0.00, 0.00, 0.00),
(337, 10, 8, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(338, 10, 5, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(339, 10, 2, 0.00, 0, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(340, 10, 7, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(341, 10, 4, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(342, 10, 1, 66666.00, 0, 0, 1, 200000.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(343, 10, 10, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(344, 10, 11, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(345, 10, 12, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(346, 10, 13, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(347, 10, 14, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(348, 10, 15, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(349, 10, 16, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(350, 10, 17, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(351, 10, 18, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(352, 10, 19, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(353, 10, 20, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(354, 10, 21, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(355, 10, 22, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(356, 10, 23, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(357, 10, 24, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(358, 10, 25, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(359, 10, 26, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(360, 10, 27, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(361, 10, 28, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(362, 10, 29, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(363, 10, 30, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(364, 10, 31, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(365, 10, 32, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(366, 10, 33, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(367, 10, 34, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(368, 10, 35, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(369, 10, 36, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(370, 11, 9, 0.00, 0, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 1000.00, 1000.00, 1000.00),
(371, 11, 6, 0.00, 0, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 350000.00, 0.00, 0.00),
(372, 11, 3, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, '2011-11-14', 5000.00, '2011-11-14', 0.00, 0.00, 0.00),
(373, 11, 8, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(374, 11, 5, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(375, 11, 2, 0.00, 0, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(376, 11, 7, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(377, 11, 4, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(378, 11, 1, 0.00, 0, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 200000.00, 0.00, 0.00),
(379, 11, 10, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(380, 11, 11, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(381, 11, 12, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(382, 11, 13, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(383, 11, 14, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(384, 11, 15, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(385, 11, 16, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(386, 11, 17, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(387, 11, 18, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(388, 11, 19, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(389, 11, 20, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(390, 11, 21, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(391, 11, 22, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(392, 11, 23, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(393, 11, 24, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(394, 11, 25, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(395, 11, 26, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(396, 11, 27, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(397, 11, 28, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(398, 11, 29, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(399, 11, 30, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(400, 11, 31, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(401, 11, 32, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(402, 11, 33, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(403, 11, 34, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(404, 11, 35, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(405, 11, 36, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(406, 11, 46, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(407, 12, 9, 0.00, 1, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(408, 12, 6, 0.00, 0, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(409, 12, 3, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, '2011-11-14', 5000.00, '2011-11-14', 0.00, 0.00, 0.00),
(410, 12, 8, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(411, 12, 5, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(412, 12, 2, 0.00, 0, 0, 1, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(413, 12, 7, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(414, 12, 4, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(415, 12, 1, 1666666.00, 0, 0, 1, 5000000.00, 1, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(416, 12, 10, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(417, 12, 11, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(418, 12, 12, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(419, 12, 13, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(420, 12, 14, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(421, 12, 15, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(422, 12, 16, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(423, 12, 17, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(424, 12, 18, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(425, 12, 19, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(426, 12, 20, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(427, 12, 21, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(428, 12, 22, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(429, 12, 23, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(430, 12, 24, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(431, 12, 25, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(432, 12, 26, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(433, 12, 27, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(434, 12, 28, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(435, 12, 29, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(436, 12, 30, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00);
INSERT INTO `vialidad_priceBulletin` (`id`, `bulletinId`, `supplyId`, `averagePrice`, `publish`, `definitive`, `supplierId1`, `price1`, `definitive1`, `supplierDocument1`, `supplierId2`, `price2`, `definitive2`, `supplierDocument2`, `supplierId3`, `price3`, `definitive3`, `supplierDocument3`, `definitiveOn`, `modifiedPrice`, `modifiedOn`, `lastPrice1`, `lastPrice2`, `lastPrice3`) VALUES
(437, 12, 31, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(438, 12, 32, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(439, 12, 33, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(440, 12, 34, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(441, 12, 35, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(442, 12, 36, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, 0.00, 0.00, 0.00),
(443, 12, 46, 0.00, 0, 0, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, 0, 0.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(444, 1, 46, NULL, 1, 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_source`
--

CREATE TABLE IF NOT EXISTS `vialidad_source` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(50) default NULL COMMENT 'Codigo de la fuente',
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `vialidad_source`
--

INSERT INTO `vialidad_source` (`id`, `code`, `name`) VALUES
(1, '10', 'Recursos del Tesoro'),
(2, '20', 'Fondo Externo'),
(3, '30', 'Recursos Propios'),
(4, '20.401', 'BID');

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_supplier`
--

CREATE TABLE IF NOT EXISTS `vialidad_supplier` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id proveedor',
  `name` varchar(255) NOT NULL COMMENT 'nombre proveedor',
  `address` varchar(255) default NULL COMMENT 'Direccion proveedor',
  `phone` varchar(50) default NULL COMMENT 'Telefono proveedor',
  `email` varchar(50) default NULL COMMENT 'Email proveedor',
  `contact` varchar(50) default NULL COMMENT 'Nombre de persona de contacto',
  `contactEmail` varchar(100) default NULL COMMENT 'Email de persona de contacto',
  `web` varchar(255) default NULL COMMENT 'Direccion web del proveedor',
  `memo` text COMMENT 'Informacion adicional del proveedor',
  `ruc` varchar(50) default NULL COMMENT 'RUC',
  `contact1` varchar(100) default NULL COMMENT 'Nombre de persona de contacto 1',
  `position1` varchar(75) default NULL COMMENT 'Cargo de persona de contacto 1',
  `phone1` varchar(75) default NULL COMMENT 'Telefono de persona de contacto 1',
  `contactEmail1` varchar(100) default NULL COMMENT 'Email de persona de contacto 1',
  `contact2` varchar(100) default NULL COMMENT 'Nombre de persona de contacto 2',
  `position2` varchar(75) default NULL COMMENT 'Cargo de persona de contacto 2',
  `phone2` varchar(75) default NULL COMMENT 'Telefono de persona de contacto 2',
  `contactEmail2` varchar(100) default NULL COMMENT 'Email de persona de contacto 2',
  `contact3` varchar(100) default NULL COMMENT 'Nombre de persona de contacto 3',
  `position3` varchar(75) default NULL COMMENT 'Cargo de persona de contacto 3',
  `phone3` varchar(75) default NULL COMMENT 'Telefono de persona de contacto 3',
  `contactEmail3` varchar(100) default NULL COMMENT 'Email de persona de contacto 3',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Proveedores' AUTO_INCREMENT=7 ;

--
-- Dumping data for table `vialidad_supplier`
--

INSERT INTO `vialidad_supplier` (`id`, `name`, `address`, `phone`, `email`, `contact`, `contactEmail`, `web`, `memo`, `ruc`, `contact1`, `position1`, `phone1`, `contactEmail1`, `contact2`, `position2`, `phone2`, `contactEmail2`, `contact3`, `position3`, `phone3`, `contactEmail3`) VALUES
(1, 'Los areneros', 'oliva', '334445', 'pepe@juan.com.py', 'Juan Manuel', NULL, 'www.arenas.com', NULL, '34343434', 'Pedro', 'supervisor', '34444', 'dd', 'Pablo', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'Proveedor 2 SA', 'Estrella 65', '455444', NULL, 'Contacto 1', 'contacto@gmail.com', 'www.prov.com.py', 'Muy buenos insumos', '123456789', 'Contacto 2', 'Encargado de ventas', '3444-22-1', 'contacto@proveedor.com.py', 'Contacto 3', 'Encargado de contacto 3', '1234', 'contacto3@proveedor.com.py', 'Contacto 4', 'Encargado 4', '1112', NULL),
(3, 'Aceros la estrella', 'Estrella y Oliva', '4545', NULL, NULL, NULL, NULL, NULL, '12345678', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'Acerotecnia', 'Oliva 3344', NULL, NULL, NULL, NULL, NULL, NULL, '445444444', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'Puentes colgantes SA', 'Estrella y Oliva', '34343434', 'puentes@puentes.com.py', 'Pepe', NULL, NULL, NULL, '12345566', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'Juancito SRL', 'General Paz 3223', '3443', 'pp@gmail.com', 'Pepe', NULL, NULL, NULL, '33434', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vialidad_supply`
--

CREATE TABLE IF NOT EXISTS `vialidad_supply` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `unit` varchar(12) default NULL COMMENT 'Unidad',
  `type` tinyint(4) default '1' COMMENT 'Tipo',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `vialidad_supply`
--

INSERT INTO `vialidad_supply` (`id`, `name`, `unit`, `type`) VALUES
(1, 'Acero para refuerzos AP 420 DN', 'T', 1),
(2, 'Arena lavada', 'm3', 1),
(3, 'Cal hidratada', 'Kg', 1),
(4, 'Cable de 4x16 mm2', 'm', 1),
(5, 'Cemento asfáltico', 'T', 1),
(6, 'Cemento Portland (CPII - F32 Compuesto)', 'T', 1),
(7, 'Cemento Artigas del Uruguay', 'T', 1),
(8, 'Cemento Puzolánico', 'T', 1),
(9, 'Columna de H° A° - 12/300', 'u', 1),
(10, 'Cubiertas 900 * 20 de 14 telas', 'u', 1),
(11, 'Dólar', 'u', 1),
(12, 'Asfalto Diluido CM 30', 'T', 1),
(13, 'Emulsión asfáltica RR1C', 'T', 1),
(14, 'Emulsión asfáltica RR2C sin polímeros', 'T', 1),
(15, 'Flex Beam (longitud de referencia igual a 320m)', 'm', 1),
(16, 'Fuel Oil', 'l', 1),
(17, 'Gas Oil', 'l', 1),
(18, 'Lámina reflectante', 'm2', 1),
(19, 'Luminaria de 400W', 'u', 1),
(20, 'Lubricante SAE 15W40', 'l', 1),
(21, 'Madera para encofrado', 'pulg2m', 1),
(22, 'Piedra triturada', 'T', 1),
(23, 'Piedra triturada de cantera', 'T', 1),
(24, 'Pintura para madera en general', 'l', 1),
(25, 'Pintura para pavimento en frío (Blanca)', 'l', 1),
(26, 'Postes de hormigón armado, longitud 2,5m', 'u', 1),
(27, 'Tachas reflectivas bidireccionales', 'u', 1),
(28, 'Tubos de hormigón Ø 0800 mm', 'm', 1),
(29, 'Tubos de hormigón Ø 1000 mm', 'm', 1),
(30, 'Tubos de hormigón Ø 1200 mm', '-', 1),
(31, 'Tubos de PVC LIB. BL100mm-6m', NULL, 1),
(32, 'Coeficiente de cargas sociales', '%', 1),
(33, 'Jornalero', 'Gs/h', 1),
(34, 'Salario mínimo vigente desde el 24 de Octubre del 2007', '-', 1),
(35, 'IPC', '%', 1),
(36, 'Indice porcentual para equipos y maquinarias SERIE ID: WPU11', NULL, 1),
(46, '', NULL, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
